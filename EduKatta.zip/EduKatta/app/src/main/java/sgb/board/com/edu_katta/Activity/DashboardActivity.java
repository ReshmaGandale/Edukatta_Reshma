package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import ru.nikartm.support.ImageBadgeView;
import sgb.board.com.edu_katta.Adapter.TabAdapter;

import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class DashboardActivity extends AppCompatActivity {

    TabLayout tabLayout;
    TabAdapter adapter;
    ViewPager viewPager;
    private int[] tabIcons = {R.drawable.home_icon2, R.drawable.dashboard_icon,
            R.drawable.sessions_icon, R.drawable.library_icon, R.drawable.dpp_icon};

    private String selectedItem;
    Toolbar mToolbar;

    ListView mDrawerList;
    RelativeLayout mDrawerPane;
    private DrawerLayout mDrawerLayout;

    ArrayList<NavItem> mNavItems = new ArrayList<NavItem>();

    LinearLayout lay_edit;

    public static String StudentId="",MobNo="",StudentName="",Stu_photo="",Stu_address="";
    SessionManager sessionManager;

    public static int TabPos=-1,TabPos_Second=-1;

    Bundle bundle;

    ImageBadgeView notification_Iv;
    ImageView Iv_pic;
    TextView tv_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        TabPos = -1;
        TabPos_Second = -1;
        Init();
    }


    public void Init()
    {
        Iv_pic = (ImageView) findViewById(R.id.Iv_pic);
        tv_name = (TextView) findViewById(R.id.tv_name);
        sessionManager = new SessionManager(DashboardActivity.this);
        if(sessionManager!=null)
        {
            String stid= sessionManager.getStudentId();
            String mob= sessionManager.getStuMobileno();
            String stnm= sessionManager.getStuName();
            String stp= sessionManager.getStuStuphoto();
            String stadd= sessionManager.getStuStuaddress();
            if(stid!=null)
            {
                StudentId = stid;
            }
            if(mob!=null)
            {
                MobNo = mob;
            }
            if(stnm!=null)
            {
                StudentName = stnm;
                tv_name.setText(stnm);
            }
            if(stp!=null)
            {
                Stu_photo = stp;
                Glide.with(DashboardActivity.this).load(Stu_photo).into(Iv_pic);
            }
            if(stadd!=null)
            {
                Stu_address = stadd;
            }
        }


        bundle = getIntent().getExtras();
        if(bundle!=null)
        {
//            Log.e("hel..Tab..",".."+bundle.getString("tabpos"));
            if(bundle.getString("tabpos").equalsIgnoreCase(""))
            {
                TabPos = -1;
            }
            else
            {
                TabPos = Integer.parseInt(bundle.getString("tabpos"));
            }
            if(bundle.getString("tabpos_second").equalsIgnoreCase(""))
            {
                TabPos_Second = -1;
            }
            else
            {
                TabPos_Second = Integer.parseInt(bundle.getString("tabpos_second"));
            }
        }

        notification_Iv = (ImageBadgeView) findViewById(R.id.notification_Iv);
        tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        lay_edit = (LinearLayout) findViewById(R.id.lay_edit);

        lay_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this,MyProfileActivity.class);
                startActivity(intent);
            }
        });

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Home");
        int red = Color.parseColor("#212121");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        tabLayout.addTab(tabLayout.newTab().setText("Home"));
        tabLayout.addTab(tabLayout.newTab().setText("Dashboard"));
        tabLayout.addTab(tabLayout.newTab().setText("Sessions"));
        tabLayout.addTab(tabLayout.newTab().setText("Library"));
        tabLayout.addTab(tabLayout.newTab().setText("DPP"));

        tabLayout.getTabAt(0).setIcon(tabIcons[0]);
        tabLayout.getTabAt(1).setIcon(tabIcons[1]);
        tabLayout.getTabAt(2).setIcon(tabIcons[2]);
        tabLayout.getTabAt(3).setIcon(tabIcons[3]);
        tabLayout.getTabAt(4).setIcon(tabIcons[4]);

        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        viewPager = (ViewPager) findViewById(R.id.pager);

        adapter = new TabAdapter(getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);



        if(TabPos!=-1)
        {
            TabPos = TabPos-1;
            new Handler().postDelayed(
                    new Runnable(){
                        @Override
                        public void run() {
                            tabLayout.getTabAt(TabPos).select();
                        }
                    }, 50);

        }
        else
        {
            tabLayout.getTabAt(0).getIcon().setColorFilter(Color.parseColor("#007DD6"), PorterDuff.Mode.SRC_IN);
        }

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                Log.e("tab..",".."+String.valueOf(TabPos));
                if(TabPos!=-1)
                {
                    TabPos = TabPos-1;
                    new Handler().postDelayed(
                            new Runnable(){
                                @Override
                                public void run() {
                                    viewPager.setCurrentItem(TabPos);
                                    tabLayout.getTabAt(TabPos).getIcon().setColorFilter(Color.parseColor("#007DD6"), PorterDuff.Mode.SRC_IN);
                                    tabLayout.getTabAt(TabPos).select();
                                    tabLayout.setScrollPosition(TabPos, 0, true);
                                }
                            }, 50);
                }
                else
                {
                    viewPager.setCurrentItem(tab.getPosition());
                    tabLayout.getTabAt(tab.getPosition()).getIcon().setColorFilter(Color.parseColor("#007DD6"), PorterDuff.Mode.SRC_IN);
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                //tab.getIcon().setTint(R.color.white);
                Log.e("tab..unselect..",".."+String.valueOf(TabPos));
                TabPos = -1;
                //tabLayout.getTabAt(3);
                tabLayout.getTabAt(tab.getPosition()).getIcon().setColorFilter(Color.parseColor("#007DD6"), PorterDuff.Mode.SRC_IN);

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                //tab.getIcon().setTint(R.color.white);
               // tabLayout.getTabAt(3);
//                TabPos = -1;
//                TabPos_Second=-1;
                Log.e("tab..reselect..",".."+String.valueOf(TabPos));
                tabLayout.getTabAt(tab.getPosition()).getIcon().setColorFilter(Color.parseColor("#d28800"), PorterDuff.Mode.SRC_IN);

            }
        });


        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        // Populate the Navigtion Drawer with options
        mDrawerPane = (RelativeLayout) findViewById(R.id.drawerPane);
        mDrawerList = (ListView) findViewById(R.id.navList);
        // Drawer Item click listeners
        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectItemFromDrawer(position);
            }
        });

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,mDrawerLayout,mToolbar,R.string.drawer_open,R.string.drawer_close){
            @Override
            public void onDrawerClosed(View v){
                super.onDrawerClosed(v);
            }

            @Override
            public void onDrawerOpened(View v) {
                super.onDrawerOpened(v);
            }
        };
        mDrawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();


        mNavItems.add(new NavItem(getResources().getString(R.string.home), getResources().getString(R.string.home_1),R.drawable.dashboard_icon2,"home"));

//        mNavItems.add(new NavItem(getResources().getString(R.string.myprofile), getResources().getString(R.string.myprofile_1),R.drawable.profile__icon5,"profile"));

        mNavItems.add(new NavItem(getResources().getString(R.string.mypayslip), getResources().getString(R.string.mypayslip_1),R.drawable.practicetest_icon,"practicetest"));


        mNavItems.add(new NavItem(getResources().getString(R.string.jeemocktest), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"jeemocktest"));

        mNavItems.add(new NavItem(getResources().getString(R.string.neetmocktest), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"neetmocktest"));


        mNavItems.add(new NavItem(getResources().getString(R.string.pfloanadvance), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"testresult"));

        mNavItems.add(new NavItem(getResources().getString(R.string.specialempreq), getResources().getString(R.string.specialempreq_1),R.drawable.practicetest_icon,"test"));

       // mNavItems.add(new NavItem(getResources().getString(R.string.providentfund), getResources().getString(R.string.providentfund_1),R.drawable.feedback_img,"feedback"));

        mNavItems.add(new NavItem(getResources().getString(R.string.uniform), getResources().getString(R.string.uniform_1),R.drawable.dpp_answer_icon,"submitted_dpp_ans"));

        mNavItems.add(new NavItem(getResources().getString(R.string.form16req), getResources().getString(R.string.form16req_1),R.drawable.report_icon,"report"));

        mNavItems.add(new NavItem(getResources().getString(R.string.logout), getResources().getString(R.string.form16req_1),R.drawable.logout,"logout"));

        DrawerListAdapter adapter = new DrawerListAdapter(DashboardActivity.this, mNavItems);
        mDrawerList.setAdapter(adapter);


        notification_Iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this,NotificationActivity.class);
                startActivity(intent);
            }
        });

        if (CheckConnection.haveNetworkConnection(DashboardActivity.this))
        {
            getNotiCount();
        }
        else {
            Toast.makeText(DashboardActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }
    }


    private void selectItemFromDrawer(int position)
    {
        mDrawerList.setItemChecked(position, true);

        if(mNavItems.get(position).mAction_name.equalsIgnoreCase("home"))
        {
            Intent intent = new Intent(DashboardActivity.this, DashboardActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("practicetest"))
        {
            Intent intent = new Intent(DashboardActivity.this,RecordedSessionActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("jeemocktest"))
        {
            Intent intent = new Intent(DashboardActivity.this,JeeMockTestActivity.class);
            intent.putExtra("Type","JEE");
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("neetmocktest"))
        {
            Intent intent = new Intent(DashboardActivity.this,JeeMockTestActivity.class);
            intent.putExtra("Type","NEET");
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("testresult"))
        {
            Intent intent = new Intent(DashboardActivity.this,TestResultActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("test"))
        {
            Intent intent = new Intent(DashboardActivity.this,TestActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("feedback"))
        {
            Intent intent = new Intent(DashboardActivity.this,FeedbackActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("submitted_dpp_ans"))
        {
            Intent intent = new Intent(DashboardActivity.this,HelpDeskListActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("report"))
        {
            Intent intent = new Intent(DashboardActivity.this,AskDoubtActivity.class);
            startActivity(intent);
//            Intent intent = new Intent(DashboardActivity.this,LibraryChapterWiseActivity.class);
//            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("logout"))
        {
            logoutpopup();

        }
        // Close the drawer
        mDrawerLayout.closeDrawer(mDrawerPane);
    }


    class NavItem {
        String mTitle;
        String mSubtitle,mAction_name;
        int mIcon;

        public NavItem(String title, String subtitle, int icon ,String action_name) {
            mTitle = title;
            mSubtitle = subtitle;
            mIcon = icon;
            mAction_name = action_name;
        }
    }

    class DrawerListAdapter extends BaseAdapter {

        Context mContext;
        ArrayList<NavItem> mNavItems;

        public DrawerListAdapter(Context context, ArrayList<NavItem> navItems) {
            mContext = context;
            mNavItems = navItems;
        }

        @Override
        public int getCount() {
            return mNavItems.size();
        }

        @Override
        public Object getItem(int position) {
            return mNavItems.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view;

            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.drawer_item, null);
            }
            else {
                view = convertView;
            }

            TextView titleView = (TextView) view.findViewById(R.id.title);
//            TextView subtitleView = (TextView) view.findViewById(R.id.subTitle);
            TextView actionname = (TextView) view.findViewById(R.id.actionname);
            ImageView iconView = (ImageView) view.findViewById(R.id.icon);

            titleView.setText( mNavItems.get(position).mTitle );
//            subtitleView.setText( mNavItems.get(position).mSubtitle );
            actionname.setText( mNavItems.get(position).mAction_name );

            iconView.setColorFilter(ContextCompat.getColor(DashboardActivity.this, R.color.black), PorterDuff.Mode.SRC_IN);
            Glide.with(DashboardActivity.this).load(mNavItems.get(position).mIcon).into(iconView);


            return view;
        }
    }



    public void getNotiCount() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(DashboardActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", MobNo);
            jsonParams.put("limit", 20);
            jsonParams.put("page_no", 1);
            jsonParams.put("count", true);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(DashboardActivity.this,"",entity,"Data/notificationlistmaster", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, String response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

//                    try
//                    {
//                        if(response.length()>0)
//                        {
//                            progressDialog.dismiss();
//
//                            if(response.length()>0)
//                            {
//                                String st="";
//                                for(int i=0 ; i<response.length(); i++)
//                                {
//                                    JSONObject jsonObject = response.getJSONObject(i);
//
//                                    if (jsonObject.getString("message")==null || jsonObject.getString("message").equalsIgnoreCase("null")||jsonObject.getString("message").equalsIgnoreCase(""))
//                                    {
////                                        noticeDAO.setName("");
//                                    }
//                                    else
//                                    {
//                                        st = st.concat(jsonObject.getString("message"));
//                                        st = st.concat("    |    ");
//                                    }
//                                }
//
//                                txt_noticemarquee.setText(st);
//                            }
//
//                        }
//                        else {
//                            progressDialog.dismiss();
//                            // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
//                        }
//
//                    }
//                    catch (Exception e)
//                    {
//                        e.printStackTrace();
//                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString() +"..."+String.valueOf(statusCode));
                    if(statusCode==200)
                    {
                        notification_Iv.setBadgeValue(Integer.parseInt(responseString));
                    }
                    else
                    {
                        Toast.makeText(DashboardActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                    }
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }








    private void logoutpopup() {
        LayoutInflater li = LayoutInflater.from(DashboardActivity.this);
        View prmotsview = li.inflate(R.layout.logout_popup, null);
        final CardView btn_no = (CardView) prmotsview.findViewById(R.id.notButton);
        final CardView btn_yes = (CardView) prmotsview.findViewById(R.id.yesButton);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DashboardActivity.this);
        alertDialogBuilder.setView(prmotsview);

        final AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        btn_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.Logout();
                ActivityCompat.finishAffinity(DashboardActivity.this);
                alertDialog.dismiss();
            }
        });

        btn_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.dismiss();
            }
        });
        alertDialog.show();
    }
}