package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;

public class ForgetPasswordActivity extends AppCompatActivity implements View.OnClickListener {

    EditText username_Et;
    CardView login_cart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }

        init();
    }

    public void init()
    {
        username_Et = (EditText) findViewById(R.id.username_Et);
        login_cart = (CardView) findViewById(R.id.login_cart);

        login_cart.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (v == login_cart) {
            if (CheckConnection.haveNetworkConnection(getApplicationContext())) {

                sendData();
            } else {
                Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
            }
        }
    }


    public void sendData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(ForgetPasswordActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("emp_code",username_Et.getText().toString());
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Server.post(ForgetPasswordActivity.this,"",entity,"Establishment/Forgot_password/send_otp", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    try {
                        if (response.has("status") && Boolean.parseBoolean(response.getString("status")) ==true )
                        {
                            progressDialog.dismiss();

                            Toast.makeText(ForgetPasswordActivity.this, response.getString("message"), Toast.LENGTH_LONG).show();

                            Intent intent = new Intent(ForgetPasswordActivity.this,ForgotPassOtpActivity.class);
                            intent.putExtra("empcode",username_Et.getText().toString());
                            startActivity(intent);
                        }
                        else {
                            progressDialog.dismiss();
                            Toast.makeText(ForgetPasswordActivity.this, response.getString("message"), Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        progressDialog.dismiss();
                        Toast.makeText(ForgetPasswordActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(ForgetPasswordActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}