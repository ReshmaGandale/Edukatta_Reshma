package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.chaos.view.PinView;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;

public class ForgotPassOtpActivity extends AppCompatActivity {

    PinView pinView;

    Bundle bundle;
    String empCode="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pass_otp);

        init();
    }

    public void init()
    {
        CardView verify_button = findViewById(R.id.verify_button);
        pinView = findViewById(R.id.pinView);

        bundle = getIntent().getExtras();
        if(bundle!=null)
        {
            empCode = bundle.getString("empcode");
        }

        verify_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (CheckConnection.haveNetworkConnection(getApplicationContext()))
                {
                    verify();
                }
                else {
                    Toast.makeText(ForgotPassOtpActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    public void verify()
    {
        //Log.e("data..",".."+empCode+"...."+pinView.getText().toString());
        try {
            final ProgressDialog progressDialog = new ProgressDialog(ForgotPassOtpActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("emp_code",empCode);
            jsonParams.put("otp",pinView.getText().toString());
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Server.post(ForgotPassOtpActivity.this,"",entity,"Establishment/Forgot_password/verify_otp", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    try {
                        if (response.has("status") && Boolean.parseBoolean(response.getString("status")) ==true )
                        {
                            progressDialog.dismiss();

                            Toast.makeText(ForgotPassOtpActivity.this, response.getString("message"), Toast.LENGTH_LONG).show();

                            Intent intent = new Intent(ForgotPassOtpActivity.this,PasswardConfirmActivity.class);
                            intent.putExtra("empcode",empCode);
                            startActivity(intent);
                        }
                        else {
                            progressDialog.dismiss();
                            Toast.makeText(ForgotPassOtpActivity.this, response.getString("message"), Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        progressDialog.dismiss();
                        Toast.makeText(ForgotPassOtpActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(ForgotPassOtpActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}