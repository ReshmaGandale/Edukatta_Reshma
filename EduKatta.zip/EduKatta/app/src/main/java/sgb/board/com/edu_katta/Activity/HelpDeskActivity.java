package sgb.board.com.edu_katta.Activity;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;
import com.bumptech.glide.Glide;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import ru.nikartm.support.ImageBadgeView;
import sgb.board.com.edu_katta.Adapter.CategoryAdapter;
import sgb.board.com.edu_katta.BuildConfig;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Custom.FilePath;
import sgb.board.com.edu_katta.Dao.CategoryDAO;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class HelpDeskActivity extends AppCompatActivity {

    Toolbar mToolbar;

    Spinner cat_spinner,subcat_spinner,teacher_spinner;

    CategoryDAO categoryDAO;
    CategoryAdapter categoryAdapter;
    ArrayList<CategoryDAO> categoryDAOS;
    String catName="",catId="0";

    CategoryDAO subcategoryDAO;
    CategoryAdapter subcategoryAdapter;
    ArrayList<CategoryDAO> subcategoryDAOS;
    String subcatName="",subcatId="0",qtypeId="0";

    CategoryDAO teacherDAO;
    CategoryAdapter teacherAdapter;
    ArrayList<CategoryDAO> teacherDAOS;
    String teacherName="",teacherId="0";


    String MobNo="",Student_Id="";
    SessionManager sessionManager;

    LinearLayout lay_teacherlabal,lay_teacherSpinner,lay_upload;

    private Bitmap bitmap = null;
    private String userChoosenTask="";
    String currentImagePath;

    Uri filePathuri;
    String imageType="",mainpath="";
    String imgName_1="";

    LinearLayout lay_save;
    EditText et_desc;
    ImageBadgeView notification_Iv;

    private String selectedItem;
    ListView mDrawerList;
    RelativeLayout mDrawerPane;
    private DrawerLayout mDrawerLayout;
    ArrayList<NavItem> mNavItems = new ArrayList<NavItem>();

    ImageView Iv_pic;
    TextView tv_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_desk);


        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Help Desk");
        int red = Color.parseColor("#212121");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        notification_Iv = (ImageBadgeView) findViewById(R.id.notification_Iv);

        Iv_pic = (ImageView) findViewById(R.id.Iv_pic);
        tv_name = (TextView) findViewById(R.id.tv_name);
        sessionManager = new SessionManager(HelpDeskActivity.this);
        if(sessionManager!=null)
        {
            String mob= sessionManager.getStuMobileno();
            String stid = sessionManager.getStudentId();
            String stnm= sessionManager.getStuName();
            String stp= sessionManager.getStuStuphoto();
            if(mob!=null)
            {
                MobNo = mob;
            }
            if(stid!=null)
            {
                Student_Id = stid;
            }
            if(stnm!=null)
            {
                tv_name.setText(stnm);
            }
            if(stp!=null)
            {
                Glide.with(HelpDeskActivity.this).load(stp).into(Iv_pic);
            }
        }

        cat_spinner = (Spinner) findViewById(R.id.cat_spinner);
        subcat_spinner = (Spinner) findViewById(R.id.subcat_spinner);
        teacher_spinner = (Spinner) findViewById(R.id.teacher_spinner);

        lay_teacherlabal = (LinearLayout) findViewById(R.id.lay_teacherlabal);
        lay_teacherSpinner = (LinearLayout) findViewById(R.id.lay_teacherSpinner);
        lay_upload = (LinearLayout) findViewById(R.id.lay_upload);
        lay_save = (LinearLayout) findViewById(R.id.lay_save);

        et_desc = (EditText) findViewById(R.id.et_desc);

        categoryDAOS = new ArrayList<>();
        subcategoryDAOS = new ArrayList<>();
        teacherDAOS = new ArrayList<>();

        categoryAdapter = new CategoryAdapter(HelpDeskActivity.this,categoryDAOS);
        teacherAdapter = new CategoryAdapter(HelpDeskActivity.this,teacherDAOS);
        subcategoryAdapter = new CategoryAdapter(HelpDeskActivity.this,subcategoryDAOS);

        cat_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                catName = String.valueOf(categoryDAOS.get(position).getName());
                catId = String.valueOf(categoryDAOS.get(position).getId());

                if(catId.equalsIgnoreCase("") || catId.equalsIgnoreCase("0") ||catId ==null)
                {
                    //lay_doctype.setVisibility(View.GONE);
                }
                else
                {
                    if (CheckConnection.haveNetworkConnection(getApplicationContext()))
                    {
                       // lay_doctype.setVisibility(View.VISIBLE);
                        subcategoryDAOS.clear();
                        getsubcatData();
                        if(catId.equalsIgnoreCase("8"))
                        {
                            lay_teacherlabal.setVisibility(View.VISIBLE);
                            lay_teacherSpinner.setVisibility(View.VISIBLE);
                            teacherDAOS.clear();
                            getteacherData();
                        }
                        else
                        {
                            lay_teacherlabal.setVisibility(View.GONE);
                            lay_teacherSpinner.setVisibility(View.GONE);
                        }
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
                    }
                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
            }
        });



        subcat_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                subcatName = String.valueOf(subcategoryDAOS.get(position).getName());
                subcatId = String.valueOf(subcategoryDAOS.get(position).getId());
                qtypeId = String.valueOf(subcategoryDAOS.get(position).getQtypE_ID());

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
            }
        });

        teacher_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                teacherName = String.valueOf(teacherDAOS.get(position).getName());
                teacherId = String.valueOf(teacherDAOS.get(position).getCode());

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
            }
        });




        if (CheckConnection.haveNetworkConnection(getApplicationContext()))
        {
            getcatData();
        }
        else
        {
            Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
        }

        notification_Iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HelpDeskActivity.this,NotificationActivity.class);
                startActivity(intent);
            }
        });

        if (CheckConnection.haveNetworkConnection(HelpDeskActivity.this))
        {
            getNotiCount();
        }
        else {
            Toast.makeText(HelpDeskActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }



        lay_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setProfilePic();
            }
        });


        lay_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(catId.equalsIgnoreCase("") || catId.equalsIgnoreCase("0"))
                {
                    Toast.makeText(HelpDeskActivity.this, "Select Category Name", Toast.LENGTH_LONG).show();
                }
                else if(subcatId.equalsIgnoreCase("") || subcatId.equalsIgnoreCase("0"))
                {
                    Toast.makeText(HelpDeskActivity.this, "Select Sub Category Name", Toast.LENGTH_LONG).show();
                }
                else if(et_desc.getText().toString().equalsIgnoreCase(""))
                {
                    Toast.makeText(HelpDeskActivity.this, "Select Stream Name", Toast.LENGTH_LONG).show();
                }
                else
                {
                    if(catId.equalsIgnoreCase("2"))
                    {
                        if(teacherId.equalsIgnoreCase("") || teacherId.equalsIgnoreCase("0"))
                        {
                            Toast.makeText(HelpDeskActivity.this, "Select Teacher Name", Toast.LENGTH_LONG).show();
                        }
                        else
                        {
                            if (CheckConnection.haveNetworkConnection(getApplicationContext()))
                            {
                                saveData();
                            }
                            else {
                                Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                    else
                    {
                        if (CheckConnection.haveNetworkConnection(getApplicationContext()))
                        {
                            teacherId="0";
                            saveData();
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
        });




        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        // Populate the Navigtion Drawer with options
        mDrawerPane = (RelativeLayout) findViewById(R.id.drawerPane);
        mDrawerList = (ListView) findViewById(R.id.navList);
        // Drawer Item click listeners
        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectItemFromDrawer(position);
            }
        });

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,mDrawerLayout,mToolbar,R.string.drawer_open,R.string.drawer_close){
            @Override
            public void onDrawerClosed(View v){
                super.onDrawerClosed(v);
            }

            @Override
            public void onDrawerOpened(View v) {
                super.onDrawerOpened(v);
            }
        };
        mDrawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();


        mNavItems.add(new NavItem(getResources().getString(R.string.home), getResources().getString(R.string.home_1),R.drawable.dashboard_icon2,"home"));

//        mNavItems.add(new NavItem(getResources().getString(R.string.myprofile), getResources().getString(R.string.myprofile_1),R.drawable.profile__icon5,"profile"));

        mNavItems.add(new NavItem(getResources().getString(R.string.mypayslip), getResources().getString(R.string.mypayslip_1),R.drawable.practicetest_icon,"practicetest"));


        mNavItems.add(new NavItem(getResources().getString(R.string.jeemocktest), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"jeemocktest"));

        mNavItems.add(new NavItem(getResources().getString(R.string.neetmocktest), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"neetmocktest"));


        mNavItems.add(new NavItem(getResources().getString(R.string.pfloanadvance), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"testresult"));

        mNavItems.add(new NavItem(getResources().getString(R.string.specialempreq), getResources().getString(R.string.specialempreq_1),R.drawable.practicetest_icon,"test"));

        // mNavItems.add(new NavItem(getResources().getString(R.string.providentfund), getResources().getString(R.string.providentfund_1),R.drawable.feedback_img,"feedback"));

        mNavItems.add(new NavItem(getResources().getString(R.string.uniform), getResources().getString(R.string.uniform_1),R.drawable.dpp_answer_icon,"submitted_dpp_ans"));

        mNavItems.add(new NavItem(getResources().getString(R.string.form16req), getResources().getString(R.string.form16req_1),R.drawable.report_icon,"report"));

        // mNavItems.add(new NavItem(getResources().getString(R.string.logout), getResources().getString(R.string.form16req_1),R.drawable.logout,"logout"));

        DrawerListAdapter adapter = new DrawerListAdapter(HelpDeskActivity.this, mNavItems);
        mDrawerList.setAdapter(adapter);
    }


    private void selectItemFromDrawer(int position)
    {
        mDrawerList.setItemChecked(position, true);

        if(mNavItems.get(position).mAction_name.equalsIgnoreCase("home"))
        {
            Intent intent = new Intent(HelpDeskActivity.this, DashboardActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("practicetest"))
        {
            Intent intent = new Intent(HelpDeskActivity.this,RecordedSessionActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("jeemocktest"))
        {
            Intent intent = new Intent(HelpDeskActivity.this,JeeMockTestActivity.class);
            intent.putExtra("Type","JEE");
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("neetmocktest"))
        {
            Intent intent = new Intent(HelpDeskActivity.this,JeeMockTestActivity.class);
            intent.putExtra("Type","NEET");
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("testresult"))
        {
            Intent intent = new Intent(HelpDeskActivity.this,TestResultActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("test"))
        {
            Intent intent = new Intent(HelpDeskActivity.this,TestActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("feedback"))
        {
            Intent intent = new Intent(HelpDeskActivity.this,FeedbackActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("submitted_dpp_ans"))
        {
            Intent intent = new Intent(HelpDeskActivity.this,HelpDeskListActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("report"))
        {
            Intent intent = new Intent(HelpDeskActivity.this,AskDoubtActivity.class);
            startActivity(intent);
//            Intent intent = new Intent(DashboardActivity.this,LibraryChapterWiseActivity.class);
//            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("logout"))
        {
            // logoutpopup();
        }
        // Close the drawer
        mDrawerLayout.closeDrawer(mDrawerPane);
    }


    class NavItem {
        String mTitle;
        String mSubtitle,mAction_name;
        int mIcon;

        public NavItem(String title, String subtitle, int icon ,String action_name) {
            mTitle = title;
            mSubtitle = subtitle;
            mIcon = icon;
            mAction_name = action_name;
        }
    }

    class DrawerListAdapter extends BaseAdapter {

        Context mContext;
        ArrayList<NavItem> mNavItems;

        public DrawerListAdapter(Context context, ArrayList<NavItem> navItems) {
            mContext = context;
            mNavItems = navItems;
        }

        @Override
        public int getCount() {
            return mNavItems.size();
        }

        @Override
        public Object getItem(int position) {
            return mNavItems.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view;

            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.drawer_item, null);
            }
            else {
                view = convertView;
            }

            TextView titleView = (TextView) view.findViewById(R.id.title);
//            TextView subtitleView = (TextView) view.findViewById(R.id.subTitle);
            TextView actionname = (TextView) view.findViewById(R.id.actionname);
            ImageView iconView = (ImageView) view.findViewById(R.id.icon);

            titleView.setText( mNavItems.get(position).mTitle );
//            subtitleView.setText( mNavItems.get(position).mSubtitle );
            actionname.setText( mNavItems.get(position).mAction_name );

            Glide.with(HelpDeskActivity.this).load(mNavItems.get(position).mIcon).into(iconView);


            return view;
        }
    }


    public void setProfilePic()
    {
        final CharSequence[] items = { "Camera", "Choose from Gallery", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(HelpDeskActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Camera")) {
                    userChoosenTask="Camera";
                    takeCameraImage();
                } else if (items[item].equals("Choose from Gallery")) {
                    userChoosenTask="Choose from Gallery";
                    takeGalleryImage();
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    public void takeCameraImage()
    {
        if (!checkIfAlreadyhavePermission()) {
            requestForSpecificPermission();
        } else {

            try {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(HelpDeskActivity.this, BuildConfig.APPLICATION_ID + ".fileprovider_mahajyoti", createImageFile()));
                startActivityForResult(intent, 1);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    public void takeGalleryImage()
    {
        Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 2);
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (resultCode) {

            case Activity.RESULT_OK: {

                switch (requestCode) {
                    case 1: {

                        try {

                            Bitmap bm = BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(currentImagePath)));

                            ExifInterface ei = new ExifInterface(getContentResolver().openInputStream(Uri.parse(currentImagePath)));
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bm, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bm, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bm, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bm;
                            }

                            //  picIv.setImageBitmap(rotatedBitmap);

                            String img = getStringImage(rotatedBitmap);

                            if (CheckConnection.haveNetworkConnection(HelpDeskActivity.this)) {

                                Uri file = Uri.fromFile(new File(currentImagePath));
                                filePathuri = Uri.fromFile(new File(currentImagePath));

                                Uri filePath = Uri.parse(currentImagePath);
                                String path = FilePath.getPath(this, filePath);

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());
                                //Log.e("path",".."+fileExt);

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                Log.e("name..", ".." + currentImagePath);


                                saveImageService(imageType, Student_Id +"_"+ ts + "." + imageType, new File(path));


                            }
                            else {
                                Toast.makeText(HelpDeskActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }catch (IOException e)
                        {
                            e.printStackTrace();
                        }

                    }

                    break;

                    case 2: {

                        try {

                            Uri selectedImage = data.getData();
                            String[] filePath = {MediaStore.Images.Media.DATA};
                            Cursor c = getContentResolver().query(selectedImage, filePath, null, null, null);
                            c.moveToFirst();
                            int columnIndex = c.getColumnIndex(filePath[0]);
                            String picturePath = c.getString(columnIndex);
                            c.close();
                            bitmap = (BitmapFactory.decodeFile(picturePath));


                            ExifInterface ei = new ExifInterface(picturePath);
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bitmap, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bitmap, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bitmap, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bitmap;
                            }


                            //  picIv.setImageBitmap(rotatedBitmap);

                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                            byte[] imageBytes = baos.toByteArray();
                            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);

                            if (CheckConnection.haveNetworkConnection(HelpDeskActivity.this)) {

                                Uri file = Uri.fromFile(new File(picturePath));

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                saveImageService(imageType,Student_Id +"_"+ts+"."+imageType,new File(picturePath));


                            } else {
                                Toast.makeText(HelpDeskActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }
                        }
                        catch (IOException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    break;

                }
            }
        }

    }

    public static Bitmap rotateImage(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(),
                matrix, true);
    }

    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        Log.e("hiiiii",encodedImage);
        return encodedImage;
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Camera");
        File image = File.createTempFile(imageFileName,".jpg",storageDir);
        // Save a file: path for using again
        currentImagePath = "file://" + image.getAbsolutePath();
        return image;
    }

    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
    }

    private boolean checkIfAlreadyhavePermission() {
        int fine = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int read = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int write = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (fine == PackageManager.PERMISSION_GRANTED) {
            Log.e("permission1", "fine");
            return true;
        }
        if (read == PackageManager.PERMISSION_GRANTED) {
            Log.e("permission2", "coarse");
            return true;
        }
        if (write == PackageManager.PERMISSION_GRANTED) {
            Log.e("permission2", "coarse");
            return true;
        } else {
            return false;
        }
    }



    public void saveImageService(final String imageType , final String filename, final File filep)
    {
        mainpath ="helpdesk_master/"+filename;

        imgName_1 = mainpath;

        Log.e("mainpath...","..."+mainpath);

        uploadAWSFile(filep,mainpath);

    }


    public void uploadAWSFile(final File myfile,String mainpath)
    {

        final ProgressDialog progressDialog = new ProgressDialog(HelpDeskActivity.this);
        progressDialog.setCancelable(false);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        File UPLOADING_IMAGE;
        String  ACCESS_KEY=getString(R.string.ACCESS_KEY),
                SECRET_KEY=getString(R.string.SECRET_KEY),
                MY_BUCKET=getString(R.string.MY_BUCKET),
                OBJECT_KEY=getString(R.string.OBJECT_KEY);
        AWSCredentials credentials = new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);
        AmazonS3 s3 = new AmazonS3Client(credentials);
        java.security.Security.setProperty("networkaddress.cache.ttl" , "60");
        //s3.setRegion(Region.getRegion(Regions.AP_SOUTHEAST_1));
        s3.setRegion(Region.getRegion(Regions.AP_SOUTH_1));
        //s3.setEndpoint("https://s3-ap-southeast-1.amazonaws.com/");
        s3.setEndpoint("https://s3.ap-south-1.amazonaws.com/");
        List<Bucket> buckets=s3.listBuckets();
        for(Bucket bucket:buckets){
            Log.e("Bucket ","Name "+bucket.getName()+" Owner "+bucket.getOwner()+ " Date " + bucket.getCreationDate());
        }
        Log.e("Size ", "" + s3.listBuckets().size());
        TransferUtility transferUtility = new TransferUtility(s3, getApplicationContext());
        // UPLOADING_IMAGE=new File(Environment.getExternalStorageDirectory().getPath()+"/Screenshot.png");
        UPLOADING_IMAGE=myfile;


        Log.e("Size ", "" + myfile.toString());
        //OBJECT_KEY = myfile.getName();
        OBJECT_KEY = mainpath;

        TransferObserver observer = transferUtility.upload(MY_BUCKET,OBJECT_KEY,UPLOADING_IMAGE);
        observer.setTransferListener(new TransferListener() {
            @Override
            public void onStateChanged(int id, TransferState state) {

                progressDialog.dismiss();
                // do something
                //progress.hide();
                // path.setText("ID "+id+"\nState "+state.name()+"\nImage ID "+OBJECT_KEY);
                Log.e("...","ID "+id+"\nState "+state.name()+"\nImage ID "+myfile.getName());
            }

            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                int percentage = (int) (bytesCurrent / bytesTotal * 100);
                //progress.setProgress(percentage);
                //Display percentage transfered to user
                if (!progressDialog.isShowing()) {
                    progressDialog.show();
                    //progressDialog.setProgress(percentage);
                    progressDialog.setMessage("Uploading...  "+String.valueOf(percentage)+"%");
                }
                Log.e("percentage....","...."+String.valueOf(percentage));
                if(percentage==100)
                {
                    Toast.makeText(HelpDeskActivity.this, "Uploaded Successfully",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(int id, Exception ex) {
                // do something
                Log.e("Error  ",""+ex );
            }

        });
    }


    public void getcatData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(HelpDeskActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("USER_ID",MobNo);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(HelpDeskActivity.this,"",entity,"Data/getQueryTypes", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                if (i==0)
                                {
                                    categoryDAO = new CategoryDAO();
                                    categoryDAO.setName("Select Category");
                                    categoryDAO.setId("0");
                                    categoryDAO.setStatus("");
                                    categoryDAOS.add(categoryDAO);
                                }

                                categoryDAO = new CategoryDAO();

                                if (jsonObject.getString("id")==null || jsonObject.getString("id").equalsIgnoreCase("null")||jsonObject.getString("id").equalsIgnoreCase(""))
                                {
                                    categoryDAO.setId("0");
                                }
                                else
                                {
                                    categoryDAO.setId(jsonObject.getString("id"));
                                }
                                if (jsonObject.getString("name")==null || jsonObject.getString("name").equalsIgnoreCase("null")||jsonObject.getString("name").equalsIgnoreCase(""))
                                {
                                    categoryDAO.setName("");
                                }
                                else
                                {
                                    categoryDAO.setName(jsonObject.getString("name"));
                                }
                                if (jsonObject.getString("status")==null || jsonObject.getString("status").equalsIgnoreCase("null")||jsonObject.getString("status").equalsIgnoreCase(""))
                                {
                                    categoryDAO.setStatus("");
                                }
                                else
                                {
                                    categoryDAO.setStatus(jsonObject.getString("status"));
                                }

                                categoryDAOS.add(categoryDAO);
                            }

                            categoryAdapter.notifyDataSetChanged();
                            cat_spinner.setAdapter(categoryAdapter);

                        }
                        else {
                            categoryAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            Toast.makeText(HelpDeskActivity.this, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(HelpDeskActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }





    public void getsubcatData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(HelpDeskActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("QTYPE_ID",Integer.parseInt(catId));
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(HelpDeskActivity.this,"",entity,"Data/getQuerySubTypes", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                if (i==0)
                                {
                                    subcategoryDAO = new CategoryDAO();
                                    subcategoryDAO.setName("Select Category");
                                    subcategoryDAO.setId("0");
                                    subcategoryDAO.setStatus("");
                                    subcategoryDAOS.add(subcategoryDAO);
                                }

                                subcategoryDAO = new CategoryDAO();

                                if (jsonObject.getString("id")==null || jsonObject.getString("id").equalsIgnoreCase("null")||jsonObject.getString("id").equalsIgnoreCase(""))
                                {
                                    subcategoryDAO.setId("0");
                                }
                                else
                                {
                                    subcategoryDAO.setId(jsonObject.getString("id"));
                                }
                                if (jsonObject.getString("name")==null || jsonObject.getString("name").equalsIgnoreCase("null")||jsonObject.getString("name").equalsIgnoreCase(""))
                                {
                                    subcategoryDAO.setName("");
                                }
                                else
                                {
                                    subcategoryDAO.setName(jsonObject.getString("name"));
                                }
                                if (jsonObject.getString("status")==null || jsonObject.getString("status").equalsIgnoreCase("null")||jsonObject.getString("status").equalsIgnoreCase(""))
                                {
                                    subcategoryDAO.setStatus("");
                                }
                                else
                                {
                                    subcategoryDAO.setStatus(jsonObject.getString("status"));
                                }
                                if (jsonObject.getString("qtypE_ID")==null || jsonObject.getString("qtypE_ID").equalsIgnoreCase("null")||jsonObject.getString("qtypE_ID").equalsIgnoreCase(""))
                                {
                                    subcategoryDAO.setQtypE_ID("0");
                                }
                                else
                                {
                                    subcategoryDAO.setQtypE_ID(jsonObject.getString("qtypE_ID"));
                                }

                                subcategoryDAOS.add(subcategoryDAO);
                            }

                            subcategoryAdapter.notifyDataSetChanged();
                            subcat_spinner.setAdapter(subcategoryAdapter);

                        }
                        else {
                            subcategoryAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            Toast.makeText(HelpDeskActivity.this, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(HelpDeskActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getteacherData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(HelpDeskActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            //jsonParams.put("","");
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(HelpDeskActivity.this,"",entity,"Data/teacherlistdropdown", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                if (i==0)
                                {
                                    teacherDAO = new CategoryDAO();
                                    teacherDAO.setName("Select Teacher");
                                    teacherDAO.setCode("0");
                                    teacherDAOS.add(teacherDAO);
                                }

                                teacherDAO = new CategoryDAO();

                                if (jsonObject.getString("code")==null || jsonObject.getString("code").equalsIgnoreCase("null")||jsonObject.getString("code").equalsIgnoreCase(""))
                                {
                                    teacherDAO.setCode("0");
                                }
                                else
                                {
                                    teacherDAO.setCode(jsonObject.getString("code"));
                                }
                                if (jsonObject.getString("name")==null || jsonObject.getString("name").equalsIgnoreCase("null")||jsonObject.getString("name").equalsIgnoreCase(""))
                                {
                                    teacherDAO.setName("");
                                }
                                else
                                {
                                    teacherDAO.setName(jsonObject.getString("name"));
                                }

                                teacherDAOS.add(teacherDAO);
                            }

                            teacherAdapter.notifyDataSetChanged();
                            teacher_spinner.setAdapter(teacherAdapter);

                        }
                        else {
                            teacherAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            Toast.makeText(HelpDeskActivity.this, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(HelpDeskActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }



    public void saveData()
    {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(HelpDeskActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("USER_ID",MobNo);
            jsonParams.put("QUERY_TYPE",Integer.parseInt(catId));
            jsonParams.put("SUBQUERY_TYPE",Integer.parseInt(subcatId));
            jsonParams.put("QUERY",et_desc.getText().toString());
            jsonParams.put("TEACHER_ID",Integer.parseInt(teacherId));
            jsonParams.put("FILE_PATH",imgName_1);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(HelpDeskActivity.this,"",entity,"Data/saveUserQuery", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());

                    progressDialog.dismiss();

                    if (String.valueOf(statusCode).equalsIgnoreCase("200"))
                    {
                        Intent intent = new Intent(HelpDeskActivity.this,HelpDeskActivity.class);
                        startActivity(intent);
                    }
                    else {
                        progressDialog.dismiss();
                        Toast.makeText(HelpDeskActivity.this, "Somthing went wrong", Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(HelpDeskActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }



    public void getNotiCount() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(HelpDeskActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", MobNo);
            jsonParams.put("limit", 20);
            jsonParams.put("page_no", 1);
            jsonParams.put("count", true);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(HelpDeskActivity.this,"",entity,"Data/notificationlistmaster", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, String response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

//                    try
//                    {
//                        if(response.length()>0)
//                        {
//                            progressDialog.dismiss();
//
//                            if(response.length()>0)
//                            {
//                                String st="";
//                                for(int i=0 ; i<response.length(); i++)
//                                {
//                                    JSONObject jsonObject = response.getJSONObject(i);
//
//                                    if (jsonObject.getString("message")==null || jsonObject.getString("message").equalsIgnoreCase("null")||jsonObject.getString("message").equalsIgnoreCase(""))
//                                    {
////                                        noticeDAO.setName("");
//                                    }
//                                    else
//                                    {
//                                        st = st.concat(jsonObject.getString("message"));
//                                        st = st.concat("    |    ");
//                                    }
//                                }
//
//                                txt_noticemarquee.setText(st);
//                            }
//
//                        }
//                        else {
//                            progressDialog.dismiss();
//                            // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
//                        }
//
//                    }
//                    catch (Exception e)
//                    {
//                        e.printStackTrace();
//                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString() +"..."+String.valueOf(statusCode));
                    if(statusCode==200)
                    {
                        notification_Iv.setBadgeValue(Integer.parseInt(responseString));
                    }
                    else
                    {
                        Toast.makeText(HelpDeskActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                    }
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }




    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }

}