package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Adapter.HelpDeskListAdapter;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.HelpDeskListDAO;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class HelpDeskListActivity extends AppCompatActivity {

    Toolbar mToolbar;

    String StudentId="",MobNo="";
    SessionManager sessionManager;

    private RecyclerView rv_list1;
    private ArrayList<HelpDeskListDAO> studentDAOS;
    private HelpDeskListAdapter studentAdapter;
    HelpDeskListDAO studentDAO;

    FloatingActionButton fab_add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_desk_list);


        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Help Desk");
        int red = Color.parseColor("#212121");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        sessionManager = new SessionManager(HelpDeskListActivity.this);
        if(sessionManager!=null)
        {
            String stid= sessionManager.getStudentId();
            String mob= sessionManager.getStuMobileno();
            if(stid!=null)
            {
                StudentId = stid;
            }
            if(mob!=null)
            {
                MobNo = mob;
            }
        }

        fab_add = findViewById(R.id.fab_add);

        fab_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HelpDeskListActivity.this,HelpDeskActivity.class);
                startActivity(intent);
            }
        });

        rv_list1 = findViewById(R.id.rv_list1);
        studentDAOS = new ArrayList<>();
        studentAdapter = new HelpDeskListAdapter(HelpDeskListActivity.this,studentDAOS);

        final LinearLayoutManager linearLayoutManager3 = new LinearLayoutManager(HelpDeskListActivity.this, LinearLayoutManager.VERTICAL, false);
        rv_list1.setLayoutManager(linearLayoutManager3);
        rv_list1.setItemAnimator(new DefaultItemAnimator());
        rv_list1.setNestedScrollingEnabled(false);
        rv_list1.setAdapter(studentAdapter);

        if (CheckConnection.haveNetworkConnection(HelpDeskListActivity.this))
        {
            studentDAOS.clear();
            studentAdapter.notifyDataSetChanged();
            getStudent();
        }
        else {
            Toast.makeText(HelpDeskListActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }

    }




    public void getStudent() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(HelpDeskListActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("USER_ID", MobNo);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(HelpDeskListActivity.this,"",entity,"Data/getUserQueries", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());
                    progressDialog.dismiss();
                    try
                    {
                        if(response.length()>0)
                        {
                            for(int i=0 ; i<response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                studentDAO = new HelpDeskListDAO();

                                if (String.valueOf(jsonObject.getString("id"))==null || String.valueOf(jsonObject.getString("id")).equalsIgnoreCase("null")||String.valueOf(jsonObject.getString("id")).equalsIgnoreCase(""))
                                {
                                    studentDAO.setId("");
                                }
                                else
                                {
                                    studentDAO.setId(String.valueOf(jsonObject.getString("id")));
                                }
                                if (jsonObject.getString("querY_TYPE")==null || jsonObject.getString("querY_TYPE").equalsIgnoreCase("null")||jsonObject.getString("querY_TYPE").equalsIgnoreCase(""))
                                {
                                    studentDAO.setQuerY_TYPE("");
                                }
                                else
                                {
                                    studentDAO.setQuerY_TYPE(jsonObject.getString("querY_TYPE"));
                                }
                                if (jsonObject.getString("subquerY_TYPE")==null || jsonObject.getString("subquerY_TYPE").equalsIgnoreCase("null")||jsonObject.getString("subquerY_TYPE").equalsIgnoreCase(""))
                                {
                                    studentDAO.setSubquerY_TYPE("");
                                }
                                else
                                {
                                    studentDAO.setSubquerY_TYPE(jsonObject.getString("subquerY_TYPE"));
                                }
                                if (jsonObject.getString("filE_PATH")==null || jsonObject.getString("filE_PATH").equalsIgnoreCase("null")||jsonObject.getString("filE_PATH").equalsIgnoreCase(""))
                                {
                                    studentDAO.setFilE_PATH("");
                                }
                                else
                                {
                                    studentDAO.setFilE_PATH(jsonObject.getString("filE_PATH"));
                                }
                                if (jsonObject.getString("query")==null || jsonObject.getString("query").equalsIgnoreCase("null")||jsonObject.getString("query").equalsIgnoreCase(""))
                                {
                                    studentDAO.setQuery("");
                                }
                                else
                                {
                                    studentDAO.setQuery(jsonObject.getString("query"));
                                }
                                if (jsonObject.getString("status")==null || jsonObject.getString("status").equalsIgnoreCase("null")||jsonObject.getString("status").equalsIgnoreCase(""))
                                {
                                    studentDAO.setStatus("");
                                }
                                else
                                {
                                    studentDAO.setStatus(jsonObject.getString("status"));
                                }


                                if (jsonObject.getString("querY_TYPE_NAME")==null || jsonObject.getString("querY_TYPE_NAME").equalsIgnoreCase("null")||jsonObject.getString("querY_TYPE_NAME").equalsIgnoreCase(""))
                                {
                                    studentDAO.setQuerY_TYPE_NAME("");
                                }
                                else
                                {
                                    studentDAO.setQuerY_TYPE_NAME(jsonObject.getString("querY_TYPE_NAME"));
                                }
                                if (jsonObject.getString("subquerY_TYPE_NAME")==null || jsonObject.getString("subquerY_TYPE_NAME").equalsIgnoreCase("null")||jsonObject.getString("subquerY_TYPE_NAME").equalsIgnoreCase(""))
                                {
                                    studentDAO.setSubquerY_TYPE_NAME("");
                                }
                                else
                                {
                                    studentDAO.setSubquerY_TYPE_NAME(jsonObject.getString("subquerY_TYPE_NAME"));
                                }


                                studentDAOS.add(studentDAO);
                            }

                            studentAdapter.notifyDataSetChanged();
                        }
                        else {
                            studentAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            Toast.makeText(HelpDeskListActivity.this, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(HelpDeskListActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }






    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}