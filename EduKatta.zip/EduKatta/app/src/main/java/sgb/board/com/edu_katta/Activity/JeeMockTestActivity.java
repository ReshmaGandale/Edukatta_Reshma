package sgb.board.com.edu_katta.Activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Adapter.JeeMockTestAdapter;
import sgb.board.com.edu_katta.Adapter.TestTypeSpinnerAdapter;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.JeeMockTestDAO;
import sgb.board.com.edu_katta.Dao.TestTypeSpinnerDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class JeeMockTestActivity extends AppCompatActivity implements View.OnClickListener {

    private RecyclerView rv_list1;
    private ArrayList<JeeMockTestDAO> studyMaterialSubDAOS;
    private JeeMockTestAdapter studyMaterialSubAdapter;
    JeeMockTestDAO studyMaterialSubDAO;

    private int index1 = 0,end = 20;
    private int count1=1;

    Bundle bundle;

    Toolbar mToolbar;

    SessionManager sessionManager;
    String MobNo="";
    String type ="";

    EditText dropdown_Et;

    TestTypeSpinnerAdapter testTypeSpinnerAdapter;
    TestTypeSpinnerDAO testTypeSpinnerDAO;
    ArrayList<TestTypeSpinnerDAO> testTypeSpinnerDAOS = new ArrayList<>();
    String test_name="",test_id="";

    private AlertDialog alertDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jee_mock_test);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        int red = Color.parseColor("#212121");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        dropdown_Et = (EditText) findViewById(R.id.dropdown_Et);
        dropdown_Et.setFocusable(false);
        dropdown_Et.setEnabled(true);
        dropdown_Et.setOnClickListener(this);

        sessionManager = new SessionManager(JeeMockTestActivity.this);
        if(sessionManager!=null)
        {
            String mob= sessionManager.getStuMobileno();

            if(mob!=null)
            {
                MobNo = mob;
            }
        }

        bundle = getIntent().getExtras();
        if(bundle!=null)
        {
            type = bundle.getString("Type");
            if(type.equalsIgnoreCase("JEE"))
            {
                getSupportActionBar().setTitle("JEE-Mock Test");
            }
            else if(type.equalsIgnoreCase("NEET"))
            {
                getSupportActionBar().setTitle("NEET-Mock Test");
            }
        }
        else
        {
            getSupportActionBar().setTitle("Mock Test");
        }


        rv_list1 = findViewById(R.id.rv_list1);
        studyMaterialSubDAOS = new ArrayList<>();
        //studyMaterialSubAdapter = new PendingPaperListAdapter(rv_list1, studyMaterialSubDAOS,PendingPaperListActivity.this);

        rv_list1.setLayoutManager(new GridLayoutManager(JeeMockTestActivity.this,1));
        rv_list1.setItemAnimator(new DefaultItemAnimator());
        rv_list1.setNestedScrollingEnabled(false);

        studyMaterialSubAdapter = new JeeMockTestAdapter(rv_list1, studyMaterialSubDAOS,JeeMockTestActivity.this);
        studyMaterialSubAdapter.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                studyMaterialSubDAOS.add(null);
                studyMaterialSubAdapter.notifyItemInserted(studyMaterialSubDAOS.size() - 1);
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        index1 = studyMaterialSubDAOS.size();
                        end = index1 + 20;
                        count1 = count1 + 1;
                        if (CheckConnection.haveNetworkConnection(JeeMockTestActivity.this))
                        {
                            getData(count1,Integer.parseInt(test_id));
                        }
                        else {
                            Toast.makeText(JeeMockTestActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });

    }

    public void getData(int count,int id) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(JeeMockTestActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE",MobNo);
            jsonParams.put("MockId",id);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(JeeMockTestActivity.this,"",entity,"Data/MockTestStudentDetails", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if (index1 != 0) {
                            studyMaterialSubDAOS.remove(studyMaterialSubDAOS.size() - 1);
                            studyMaterialSubAdapter.notifyItemRemoved(studyMaterialSubDAOS.size());
                        }

                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                studyMaterialSubDAO = new JeeMockTestDAO();


                                if(jsonObject.getString("id")==null || jsonObject.getString("id").equalsIgnoreCase("null")||jsonObject.getString("id").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setId("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setId(String.valueOf(jsonObject.getString("id")));
                                }
                                if (jsonObject.getString("tesT_TOPIC")==null || jsonObject.getString("tesT_TOPIC").equalsIgnoreCase("null")||jsonObject.getString("tesT_TOPIC").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setTesT_TOPIC("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setTesT_TOPIC(jsonObject.getString("tesT_TOPIC"));
                                }
                                if (jsonObject.getString("test_DATE")==null || jsonObject.getString("test_DATE").equalsIgnoreCase("null")||jsonObject.getString("test_DATE").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setTest_DATE("");
                                }
                                else
                                {
//                                    studyMaterialSubDAO.setTest_DATE(jsonObject.getString("test_DATE"));

                                    DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy");
                                    DateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                                    Date date = outputFormat.parse(jsonObject.getString("test_DATE"));
                                    String a_date = inputFormat.format(date);
                                    studyMaterialSubDAO.setTest_DATE(a_date);
                                }
                                if (jsonObject.getString("year")==null || jsonObject.getString("year").equalsIgnoreCase("null")||jsonObject.getString("year").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setYear("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setYear(jsonObject.getString("year"));
                                }
                                if (jsonObject.getString("submitteD_STUDENT_ID")==null || jsonObject.getString("submitteD_STUDENT_ID").equalsIgnoreCase("null")||jsonObject.getString("submitteD_STUDENT_ID").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setSubmitteD_STUDENT_ID("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setSubmitteD_STUDENT_ID(jsonObject.getString("submitteD_STUDENT_ID"));
                                }
                                if (jsonObject.getString("remark")==null || jsonObject.getString("remark").equalsIgnoreCase("null")||jsonObject.getString("remark").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setRemark("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setRemark(jsonObject.getString("remark"));
                                }
                                if (jsonObject.getString("mocK_STD_ID")==null || jsonObject.getString("mocK_STD_ID").equalsIgnoreCase("null")||jsonObject.getString("mocK_STD_ID").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setMocK_STD_ID("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setMocK_STD_ID(jsonObject.getString("mocK_STD_ID"));
                                }
                                if (jsonObject.getString("studenT_ID")==null || jsonObject.getString("studenT_ID").equalsIgnoreCase("null")||jsonObject.getString("studenT_ID").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setStudenT_ID("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setStudenT_ID(jsonObject.getString("studenT_ID"));
                                }
                                if (jsonObject.getString("questions")==null || jsonObject.getString("questions").equalsIgnoreCase("null")||jsonObject.getString("questions").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setQuestions("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setQuestions(jsonObject.getString("questions"));
                                }
                                if (jsonObject.getString("answers")==null || jsonObject.getString("answers").equalsIgnoreCase("null")||jsonObject.getString("answers").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setAnswers("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setAnswers(jsonObject.getString("answers"));
                                }
                                if (jsonObject.getString("submit")==null || jsonObject.getString("submit").equalsIgnoreCase("null")||jsonObject.getString("submit").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setSubmit("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setSubmit(jsonObject.getString("submit"));
                                }


                                studyMaterialSubDAOS.add(studyMaterialSubDAO);
                            }


                            if (index1 == 0 && end == 20)
                            {
                                rv_list1.setAdapter(studyMaterialSubAdapter);
                            }else{
                                Log.e("index and end",index1+","+end);
                            }
                            studyMaterialSubAdapter.notifyDataSetChanged();
                            studyMaterialSubAdapter.setLoaded();

                        }
                        else {
                            studyMaterialSubAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            Toast.makeText(JeeMockTestActivity.this, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(JeeMockTestActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {

        if(v == dropdown_Et)
        {
            if (CheckConnection.haveNetworkConnection(JeeMockTestActivity.this)) {
                testTypeSpinnerDAOS = new ArrayList<>();
                testTypeSpinnerAdapter = new TestTypeSpinnerAdapter(JeeMockTestActivity.this,testTypeSpinnerDAOS);
                testTypeSpinnerDAOS.clear();
                testTypeSpinnerAdapter.notifyDataSetChanged();
                showDataPopup();
            } else {
                Toast.makeText(JeeMockTestActivity.this, "Network is not available", Toast.LENGTH_SHORT).show();
            }
        }
    }



    public void showDataPopup()
    {
        LayoutInflater li = LayoutInflater.from(JeeMockTestActivity.this);
        View prmotsview = li.inflate(R.layout.dropdown_search_popup, null);
        ImageView img_close = (ImageView) prmotsview.findViewById(R.id.img_close);
        EditText searchEt = (EditText) prmotsview.findViewById(R.id.searchEt);
        TextView headtitle = (TextView) prmotsview.findViewById(R.id.headtitle);
        headtitle.setText("Select Test");

        final RecyclerView rv_list = (RecyclerView) prmotsview.findViewById(R.id.rv_list);
        RecyclerView.LayoutManager mLayoutManager;
        mLayoutManager = new LinearLayoutManager(this);
        rv_list.setLayoutManager(mLayoutManager);
        rv_list.setItemAnimator(new DefaultItemAnimator());
        rv_list.setAdapter(testTypeSpinnerAdapter);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(JeeMockTestActivity.this);
        alertDialogBuilder.setView(prmotsview);
        alertDialog = alertDialogBuilder.create();
        alertDialog.setCanceledOnTouchOutside(false);

        try {
            final ProgressDialog progressDialog = new ProgressDialog(JeeMockTestActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("YEAR",2021);
            jsonParams.put("Type",type);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(JeeMockTestActivity.this,"",entity,"Data/MockTestDropdown", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());
                    progressDialog.dismiss();
                    try
                    {
                        if(response.length()>0)
                        {
                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                testTypeSpinnerDAO = new TestTypeSpinnerDAO();
                                testTypeSpinnerDAO.setMocK_ID(jsonObject.getString("mocK_ID"));
                                testTypeSpinnerDAO.setTesT_TOPIC(jsonObject.getString("tesT_TOPIC"));
                                testTypeSpinnerDAOS.add(testTypeSpinnerDAO);
                            }
                            testTypeSpinnerAdapter = new TestTypeSpinnerAdapter(JeeMockTestActivity.this,testTypeSpinnerDAOS);
                            rv_list.setAdapter(testTypeSpinnerAdapter);

                        }
                        else {
                            progressDialog.dismiss();
                            Toast.makeText(JeeMockTestActivity.this, "Data Not Available", Toast.LENGTH_LONG).show();
                        }
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(JeeMockTestActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }

        img_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        searchEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (testTypeSpinnerAdapter != null) testTypeSpinnerAdapter.getFilter().filter(s);
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        alertDialog.show();
    }

    public void onTesttypePopupClick(String cId,String cname) {
        test_id = cId;
        Log.e("name..is..",".."+cname);
        dropdown_Et.setText(cname);

        if (CheckConnection.haveNetworkConnection(JeeMockTestActivity.this))
        {
            index1 = 0;
            count1=1;
            studyMaterialSubDAOS.clear();
            rv_list1.setAdapter(studyMaterialSubAdapter);
            getData(count1 ,Integer.parseInt(cId));

            alertDialog.dismiss();
        }
        else {
            Toast.makeText(JeeMockTestActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }
    }



    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
    }
    @Override
    public boolean onSupportNavigateUp() {
        //progressDialog.dismiss();
        onBackPressed();
        return false;
    }
}