package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Adapter.LibraryChapterWiseAdapter;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.LibraryChapterWiseDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class LibraryChapterWiseActivity extends AppCompatActivity {

    private RecyclerView rv_list1;
    private ArrayList<LibraryChapterWiseDAO> libraryChapterWiseDAOS;
    private LibraryChapterWiseAdapter libraryChapterWiseAdapter;
    LibraryChapterWiseDAO libraryChapterWiseDAO;

    private int index1 = 0,end = 20;
    private int count1=1;

    Toolbar mToolbar;

    Bundle bundle;
    TextView txt_subject;

    String SubId="0",StudentId="",MobNo="";
    SessionManager sessionManager;
    EditText search_Et;
    ImageView img_cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library_chapter_wise);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Recorded Material");
        int red = Color.parseColor("#212121");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        txt_subject = (TextView) findViewById(R.id.txt_subject);
        img_cancel = (ImageView) findViewById(R.id.img_cancel);
        search_Et = (EditText) findViewById(R.id.search_Et);

        sessionManager = new SessionManager(LibraryChapterWiseActivity.this);
        if(sessionManager!=null)
        {
            String stid= sessionManager.getStudentId();
            String mob= sessionManager.getStuMobileno();
            if(stid!=null)
            {
                StudentId = stid;
            }
            if(mob!=null)
            {
                MobNo = mob;
            }
        }

        bundle = getIntent().getExtras();
        if(bundle!=null)
        {
            txt_subject.setText(bundle.getString("subject") +" - ");
            if(bundle.getString("subject_id").equalsIgnoreCase(""))
            {
                SubId = "0";
            }
            else
            {
                SubId = bundle.getString("subject_id");
            }
//            if(bundle.getString("video_count").equalsIgnoreCase(""))
//            {
//                txt_video_count.setText("0");
//            }
//            else
//            {
//                txt_video_count.setText(bundle.getString("video_count"));
//            }
        }
        else
        {
            txt_subject.setText(" - ");
            SubId = "0";
           // txt_video_count.setText("0");
        }

        img_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                search_Et.setText("");
            }
        });


        rv_list1 = findViewById(R.id.rv_list1);
        libraryChapterWiseDAOS = new ArrayList<>();

        rv_list1.setLayoutManager(new GridLayoutManager(LibraryChapterWiseActivity.this,1));
        rv_list1.setItemAnimator(new DefaultItemAnimator());
        rv_list1.setNestedScrollingEnabled(false);

        libraryChapterWiseAdapter = new LibraryChapterWiseAdapter(rv_list1, libraryChapterWiseDAOS,LibraryChapterWiseActivity.this);
        libraryChapterWiseAdapter.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                libraryChapterWiseDAOS.add(null);
                libraryChapterWiseAdapter.notifyItemInserted(libraryChapterWiseDAOS.size() - 1);
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        index1 = libraryChapterWiseDAOS.size();
                        end = index1 + 20;
                        count1 = count1 + 1;
                        if (CheckConnection.haveNetworkConnection(LibraryChapterWiseActivity.this))
                        {
                            getData(count1);
                        }
                        else {
                            Toast.makeText(LibraryChapterWiseActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });


        final long delay = 1000;
        final long[] last_text_edit = {0};
        final Handler handler = new Handler();

        final Runnable input_finish_checker = new Runnable() {
            public void run() {
                if (System.currentTimeMillis() > (last_text_edit[0] + delay - 500)) {

                    libraryChapterWiseDAOS.clear();
                    index1 = 0;
                    count1 = 1;
                    rv_list1.setAdapter(libraryChapterWiseAdapter);
                    getData(count1);
                }
            }
        };

        search_Et.addTextChangedListener(new TextWatcher()
             {
                 @Override
                 public void beforeTextChanged (CharSequence s,int start, int count,
                                                int after){
                 }
                 @Override
                 public void onTextChanged ( final CharSequence s, int start, int before,
                                             int count){
                     //You need to remove this to run only once
                     handler.removeCallbacks(input_finish_checker);

                 }
                 @Override
                 public void afterTextChanged ( final Editable s){
                     //avoid triggering event when text is empty
                     if (s.length() > 0) {
                         last_text_edit[0] = System.currentTimeMillis();
                         handler.postDelayed(input_finish_checker, delay);
                     }
                     else if(s.length() == 0)
                     {
                         last_text_edit[0] = System.currentTimeMillis();
                         handler.postDelayed(input_finish_checker, delay);
                     }
                     else {

                     }
                 }
             }
        );


        if (CheckConnection.haveNetworkConnection(LibraryChapterWiseActivity.this))
        {
            index1 = 0;
            count1=1;
            libraryChapterWiseDAOS.clear();
            libraryChapterWiseAdapter.notifyDataSetChanged();

            getData(count1);
        }
        else {
            Toast.makeText(LibraryChapterWiseActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }
    }



    public void getData(int count) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(LibraryChapterWiseActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE",MobNo);
            jsonParams.put("SUBJECT",Integer.parseInt(SubId));
            jsonParams.put("limit",20);
            jsonParams.put("page_no",count);
            jsonParams.put("searchText",search_Et.getText().toString().trim());
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(LibraryChapterWiseActivity.this,"",entity,"Data/librarygroup", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if (index1 != 0) {
                            libraryChapterWiseDAOS.remove(libraryChapterWiseDAOS.size() - 1);
                            libraryChapterWiseAdapter.notifyItemRemoved(libraryChapterWiseDAOS.size());
                        }

                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                libraryChapterWiseDAO = new LibraryChapterWiseDAO();

                                if (jsonObject.getString("chapter")==null || jsonObject.getString("chapter").equalsIgnoreCase("null")||jsonObject.getString("chapter").equalsIgnoreCase(""))
                                {
                                    libraryChapterWiseDAO.setChapter("");
                                }
                                else
                                {
                                    libraryChapterWiseDAO.setChapter(jsonObject.getString("chapter"));
                                }
                                if (jsonObject.getString("video_count")==null || jsonObject.getString("video_count").equalsIgnoreCase("null")||jsonObject.getString("video_count").equalsIgnoreCase(""))
                                {
                                    libraryChapterWiseDAO.setVideo_count("");
                                }
                                else
                                {
                                    libraryChapterWiseDAO.setVideo_count(jsonObject.getString("video_count"));
                                }
                                if (jsonObject.getString("videoList")==null || jsonObject.getString("videoList").equalsIgnoreCase("null")||jsonObject.getString("videoList").equalsIgnoreCase(""))
                                {
                                    libraryChapterWiseDAO.setVideoList("");
                                }
                                else
                                {
                                    libraryChapterWiseDAO.setVideoList(jsonObject.getString("videoList"));
                                }

                                libraryChapterWiseDAOS.add(libraryChapterWiseDAO);
                            }


                            if (index1 == 0 && end == 20)
                            {
                                rv_list1.setAdapter(libraryChapterWiseAdapter);
                            }else{
                                Log.e("index and end",index1+","+end);
                            }
                            libraryChapterWiseAdapter.notifyDataSetChanged();
                            libraryChapterWiseAdapter.setLoaded();

                        }
                        else {
                            libraryChapterWiseAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            //Toast.makeText(LibraryChapterWiseActivity.this, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(LibraryChapterWiseActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}