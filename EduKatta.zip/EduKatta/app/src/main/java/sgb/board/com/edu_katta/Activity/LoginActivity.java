package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

import com.bumptech.glide.Glide;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import cz.msebera.android.httpclient.Header;
import sgb.board.com.edu_katta.Utils.SharePrefarence2;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    EditText username_Et,password_Et;
//    CardView login_cart;
    SessionManager sessionManager;
    TextView reset_txt,forgetpass_txt;
    LinearLayout lay_login;

    String DeviceId="";
    ImageView img_eye;

    boolean isPasswordVisible = false;

    TextView txt_notice_1,txt_notice_2,txt_notice_3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }

        init();
    }


    public void init()
    {
        username_Et = (EditText) findViewById(R.id.username_Et);
        password_Et = (EditText) findViewById(R.id.password_Et);
        lay_login = (LinearLayout) findViewById(R.id.lay_login);
        lay_login.setOnClickListener(this);

        txt_notice_1 = (TextView) findViewById(R.id.txt_notice_1);
        txt_notice_2 = (TextView) findViewById(R.id.txt_notice_2);
        txt_notice_3 = (TextView) findViewById(R.id.txt_notice_3);


        sessionManager=new SessionManager(LoginActivity.this);
        if(sessionManager!=null)
        {
            String id = sessionManager.getDeviceid();
            if(id!=null)
            {
                DeviceId = id;
                Log.e("device..Data..",".."+DeviceId);
            }
        }
        img_eye = (ImageView) findViewById(R.id.img_eye);

        img_eye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(isPasswordVisible)
                {
                    img_eye.setColorFilter(ContextCompat.getColor(LoginActivity.this, R.color.colorPrimaryDark), PorterDuff.Mode.SRC_IN);
                    Glide.with(LoginActivity.this).load(R.drawable.hide_password).into(img_eye);
                    isPasswordVisible = false;
                    password_Et.setTransformationMethod(new PasswordTransformationMethod());
                }
                else
                {
                    img_eye.setColorFilter(ContextCompat.getColor(LoginActivity.this, R.color.colorPrimaryDark), PorterDuff.Mode.SRC_IN);
                    Glide.with(LoginActivity.this).load(R.drawable.password_show).into(img_eye);
                    isPasswordVisible = true;
                    password_Et.setTransformationMethod(null);
                }

            }
        });


        if (CheckConnection.haveNetworkConnection(LoginActivity.this))
        {
            getNoticeData();
        }
        else {
            Toast.makeText(LoginActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onClick(View v) {

        if(v==lay_login)
        {
            if (CheckConnection.haveNetworkConnection(getApplicationContext())) {
                login();
            }
            else {
                Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
            }
        }

    }


    public void login() {
        try {
        final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);
        progressDialog.setMessage("Loading.....");
        progressDialog.setCancelable(true);
        JSONObject jsonParams = new JSONObject();
        jsonParams.put("username",username_Et.getText().toString());
        jsonParams.put("password",password_Et.getText().toString());
        StringEntity entity = new StringEntity(jsonParams.toString());
        Log.e("para",entity.toString());
        Log.e("para....",jsonParams.toString());
        Server.post(LoginActivity.this,"",entity,"Data/studentlogin", new JsonHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                if (!progressDialog.isShowing()) {
                    progressDialog.show();
                }
            }
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                super.onSuccess(statusCode, headers, response);
                Log.d("success", response.toString());
                try {

                    progressDialog.dismiss();

                    if (response.has("studentdata") && response.getString("token")!=null)
                    {

                        JSONObject jsonObject = response.getJSONObject("studentdata");

                        sessionManager.createLoginSession(response.getString("token"),jsonObject.getString("studenT_ID"),
                                jsonObject.getString("firsT_NAME"),jsonObject.getString("middeL_NAME"),jsonObject.getString("surname"),
                                jsonObject.getString("mobile"),jsonObject.getString("status"),response.getString("profileimage"),jsonObject.getString("address"));

                        Toast.makeText(LoginActivity.this, "Login Successfully", Toast.LENGTH_LONG).show();
                        SharePrefarence2.getmInstance(LoginActivity.this).Saveid("1");

                        Intent intent = new Intent(LoginActivity.this,DashboardActivity.class);
                        startActivity(intent);

                    }
                    else {
                        progressDialog.dismiss();
                        Toast.makeText(LoginActivity.this, response.getString("message"), Toast.LENGTH_LONG).show();
                    }


                } catch (JSONException e) {
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                super.onFailure(statusCode, headers, responseString, throwable);
                progressDialog.dismiss();
                Log.e("error..is",".."+responseString.toString());
                Toast.makeText(LoginActivity.this, responseString,Toast.LENGTH_LONG).show();
            }
        });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }



    public void forgetPassword() {

        Intent intent = new Intent(LoginActivity.this,ForgetPasswordActivity.class);
        startActivity(intent);

//        final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);
//        progressDialog.setMessage("Loading.....");
//        progressDialog.setCancelable(true);
//        RequestParams jsonParams = new RequestParams();
//        jsonParams.put("sgb_board_id",SGB_Board_Id);
//        jsonParams.put("employee_code",UserCode);
//
//        Log.e("para",jsonParams.toString());
//        Server.get(JWT_Token,jsonParams,"Establishment/Employee/retrieve_employee_details", new JsonHttpResponseHandler() {
//            @Override
//            public void onStart() {
//                super.onStart();
//                if (!progressDialog.isShowing()) {
//                    progressDialog.show();
//                }
//            }
//            @Override
//            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
//                super.onSuccess(statusCode, headers, response);
//                Log.d("success", response.toString());
//                try {
//                    progressDialog.dismiss();
//                    Toast.makeText(LoginActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
////
//                }catch (Exception e)
//                {
//                    e.printStackTrace();
//                }
//            }
//            @Override
//            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
//                super.onFailure(statusCode, headers, responseString, throwable);
//                progressDialog.dismiss();
//                Log.e("error..is",".."+responseString.toString());
//                Toast.makeText(LoginActivity.this, "Something went wrong",Toast.LENGTH_LONG).show();
//            }
//        });
    }


    public void getNoticeData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("limit", 3);
            jsonParams.put("page_no", 1);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(LoginActivity.this,"",entity,"Data/mjnoticelist", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            if(response.length()>0)
                            {
                                for(int i=0 ; i<response.length(); i++)
                                {
                                    JSONObject jsonObject = response.getJSONObject(i);

                                    if (jsonObject.getString("message")==null || jsonObject.getString("message").equalsIgnoreCase("null")||jsonObject.getString("message").equalsIgnoreCase(""))
                                    {
//                                        noticeDAO.setName("");
                                    }
                                    else
                                    {
                                        if(i==0)
                                        {
                                            txt_notice_1.setText(jsonObject.getString("message"));
                                        }
                                        else  if(i==1)
                                        {
                                            txt_notice_2.setText(jsonObject.getString("message"));
                                        }
                                        else  if(i==2)
                                        {
                                            txt_notice_3.setText(jsonObject.getString("message"));
                                        }
                                    }
                                }

                            }

                        }
                        else {
                            progressDialog.dismiss();
                            // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(LoginActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }



    @Override
    public void onBackPressed() {

        close_Activity();
    }

    private void close_Activity() {
        LayoutInflater li = LayoutInflater.from(LoginActivity.this);
        View prmotsview = li.inflate(R.layout.close_app_popup, null);
        final TextView btn_no = (TextView) prmotsview.findViewById(R.id.notButton);
        final CardView btn_yes = (CardView) prmotsview.findViewById(R.id.yesButton);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(LoginActivity.this);
        alertDialogBuilder.setView(prmotsview);

        final AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        btn_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, LoginActivity.class);
                startActivity(intent);
                ActivityCompat.finishAffinity(LoginActivity.this);
                alertDialog.dismiss();

            }
        });

        btn_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.dismiss();
            }
        });
        alertDialog.show();
    }
}
