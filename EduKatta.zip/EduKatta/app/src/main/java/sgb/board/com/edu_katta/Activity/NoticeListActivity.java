package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Adapter.NoticeListAdapter;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.NoticeListDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class NoticeListActivity extends AppCompatActivity {

    private RecyclerView rv_list1;
    private ArrayList<NoticeListDAO> noticeListDAOS;
    private NoticeListAdapter noticeListAdapter;
    NoticeListDAO noticeListDAO;

    private int index1 = 0,end = 20;
    private int count1=1;

    String MobNo="";
    SessionManager sessionManager;

    Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_list);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Notice");
        int red = Color.parseColor("#212121");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        sessionManager = new SessionManager(NoticeListActivity.this);
        if(sessionManager!=null)
        {
            String mob= sessionManager.getStuMobileno();
            if(mob!=null)
            {
                MobNo = mob;
            }
        }


        rv_list1 = findViewById(R.id.rv_list1);
        noticeListDAOS = new ArrayList<>();

        rv_list1.setLayoutManager(new GridLayoutManager(NoticeListActivity.this,1));
        rv_list1.setItemAnimator(new DefaultItemAnimator());
        rv_list1.setNestedScrollingEnabled(false);

        noticeListAdapter = new NoticeListAdapter(rv_list1, noticeListDAOS,NoticeListActivity.this);
        noticeListAdapter.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                noticeListDAOS.add(null);
                noticeListAdapter.notifyItemInserted(noticeListDAOS.size() - 1);
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        index1 = noticeListDAOS.size();
                        end = index1 + 20;
                        count1 = count1 + 1;
                        if (CheckConnection.haveNetworkConnection(NoticeListActivity.this))
                        {
                            getData(count1);
                        }
                        else {
                            Toast.makeText(NoticeListActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });

        if (CheckConnection.haveNetworkConnection(NoticeListActivity.this))
        {
            index1 = 0;
            count1=1;
            noticeListDAOS.clear();
            noticeListAdapter.notifyDataSetChanged();

            getData(count1);
        }
        else {
            Toast.makeText(NoticeListActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }
    }


    public void getData(int count) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(NoticeListActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("limit",20);
            jsonParams.put("page_no",count);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(NoticeListActivity.this,"",entity,"Data/mjnoticelist", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if (index1 != 0) {
                            noticeListDAOS.remove(noticeListDAOS.size() - 1);
                            noticeListAdapter.notifyItemRemoved(noticeListDAOS.size());
                        }

                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                noticeListDAO = new NoticeListDAO();

                                if (jsonObject.getString("mjnB_ID")==null || jsonObject.getString("mjnB_ID").equalsIgnoreCase("null")||jsonObject.getString("mjnB_ID").equalsIgnoreCase(""))
                                {
                                    noticeListDAO.setMjnB_ID("");
                                }
                                else
                                {
                                    noticeListDAO.setMjnB_ID(jsonObject.getString("mjnB_ID"));
                                }
                                if (jsonObject.getString("message")==null || jsonObject.getString("message").equalsIgnoreCase("null")||jsonObject.getString("message").equalsIgnoreCase(""))
                                {
                                    noticeListDAO.setMessage("");
                                }
                                else
                                {
                                    noticeListDAO.setMessage(jsonObject.getString("message"));
                                }
                                if (jsonObject.getString("noticE_DATE")==null || jsonObject.getString("noticE_DATE").equalsIgnoreCase("null")||jsonObject.getString("noticE_DATE").equalsIgnoreCase(""))
                                {
                                    noticeListDAO.setNoticE_DATE("");
                                }
                                else
                                {
                                    noticeListDAO.setNoticE_DATE(jsonObject.getString("noticE_DATE"));
                                }

                                noticeListDAOS.add(noticeListDAO);
                            }

                            if (index1 == 0 && end == 20)
                            {
                                rv_list1.setAdapter(noticeListAdapter);
                            }else{
                                Log.e("index and end",index1+","+end);
                            }
                            noticeListAdapter.notifyDataSetChanged();
                            noticeListAdapter.setLoaded();

                        }
                        else {
                            noticeListAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            Toast.makeText(NoticeListActivity.this, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(NoticeListActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}