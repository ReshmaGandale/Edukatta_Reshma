package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Adapter.NotificationAdapter;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.NotificationDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class NotificationActivity extends AppCompatActivity {
    Toolbar mToolbar;

    SessionManager sessionManager;
    public String MobNo="";

    private RecyclerView rv_notificationlist;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<NotificationDAO> notificationDAOS;
    private NotificationAdapter notificationAdapter;
    NotificationDAO notificationDAO;

    private int index1 = 0,end = 20;
    private int count1=1;

    LinearLayout lay_emptynoti;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        Init();
    }

    public void Init()
    {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Notifications");
        int red = Color.parseColor("#FFFFFF");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        sessionManager = new SessionManager(NotificationActivity.this);

        if (sessionManager != null) {
            String ses_mno = sessionManager.getStuMobileno();
            if (ses_mno != null)
            {
                MobNo = ses_mno;
            }
        }
        lay_emptynoti = (LinearLayout) findViewById(R.id.lay_emptynoti);
        lay_emptynoti.setVisibility(View.GONE);


        rv_notificationlist= findViewById(R.id.rv_notificationlist);
        layoutManager=new LinearLayoutManager(this);
        rv_notificationlist.setLayoutManager(layoutManager);

        notificationDAOS=new ArrayList<>();

        notificationAdapter = new NotificationAdapter(rv_notificationlist,notificationDAOS,NotificationActivity.this);
        notificationAdapter.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                notificationDAOS.add(null);
                notificationAdapter.notifyItemInserted(notificationDAOS.size() - 1);
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        index1 = notificationDAOS.size();
                        end = index1 + 20;
                        count1 = count1 + 1;
                        if (CheckConnection.haveNetworkConnection(getApplicationContext()))
                        {
                            getData(count1);
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });

        if (CheckConnection.haveNetworkConnection(getApplicationContext()))
        {
            index1 = 0;
            count1=1;
            notificationDAOS.clear();
            notificationAdapter.notifyDataSetChanged();
            getData(count1);
        } else {
            Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
        }
    }


    public void getData(int count) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(NotificationActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE",MobNo);
            jsonParams.put("limit",20);
            jsonParams.put("page_no",count);
            jsonParams.put("count",false);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(NotificationActivity.this,"",entity,"Data/notificationlistmaster", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if (index1 != 0) {
                            notificationDAOS.remove(notificationDAOS.size() - 1);
                            notificationAdapter.notifyItemRemoved(notificationDAOS.size());
                        }

                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                notificationDAO = new NotificationDAO();

                                if (jsonObject.getString("notification")==null || jsonObject.getString("notification").equalsIgnoreCase("null")||jsonObject.getString("notification").equalsIgnoreCase(""))
                                {
                                    notificationDAO.setMessage("");
                                }
                                else
                                {
                                    notificationDAO.setMessage(jsonObject.getString("notification"));
                                }
                                if (jsonObject.getString("datE_TIME")==null || jsonObject.getString("datE_TIME").equalsIgnoreCase("null")||jsonObject.getString("datE_TIME").equalsIgnoreCase(""))
                                {
                                    notificationDAO.setSend_date("");
                                }
                                else
                                {
                                    notificationDAO.setSend_date(jsonObject.getString("datE_TIME"));
//                                    DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy");
//                                    DateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
//                                    Date date = outputFormat.parse(jsonObject.getString("datE_TIME"));
//                                    String a_date = inputFormat.format(date);
//                                    notificationDAO.setSend_date(a_date);
                                }

                                notificationDAOS.add(notificationDAO);
                            }


                            if (index1 == 0 && end == 20)
                            {
                                rv_notificationlist.setAdapter(notificationAdapter);
                            }else{
                                Log.e("index and end",index1+","+end);
                            }
                            notificationAdapter.notifyDataSetChanged();
                            notificationAdapter.setLoaded();

                        }
                        else {
                            notificationAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            //Toast.makeText(NotificationActivity.this, "Data Not Available", Toast.LENGTH_LONG).show();
                        }
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(NotificationActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onBackPressed() {

        Intent intent = new Intent(NotificationActivity.this, DashboardActivity.class);
        startActivity(intent);
        ActivityCompat.finishAffinity(NotificationActivity.this);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}
