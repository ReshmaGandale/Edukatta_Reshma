package sgb.board.com.edu_katta.Activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.hmdm.MDMPushHandler;
import com.hmdm.MDMPushMessage;

public class NotificationGetActivity extends Activity {

    private MDMPushHandler pushHandler = new MDMPushHandler() {
        public void onMessageReceived(MDMPushMessage message) {
            Log.d("MyApp", "MDM Push received: type " + message.getType());
            // Do something with message.getData() which is a JSONObject object.
            Toast.makeText(NotificationGetActivity.this,"messege received", Toast.LENGTH_SHORT).show();

            Toast.makeText(NotificationGetActivity.this, message.getData().toString(), Toast.LENGTH_SHORT).show();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pushHandler.register("myMessageType", this);
    }

    @Override
    protected void onDestroy() {
        pushHandler.unregister(this);
        super.onDestroy();
    }
}
