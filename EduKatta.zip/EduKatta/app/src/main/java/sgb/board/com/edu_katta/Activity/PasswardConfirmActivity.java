package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class PasswardConfirmActivity extends AppCompatActivity {

    Bundle bundle;
    String empCode="";

    LinearLayout lay_submit,lay_cancel;
    EditText et_empcode,et_newpass,et_confirmpass;

    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passward_confirm);

        init();
    }


    public void init()
    {
        lay_submit = findViewById(R.id.lay_submit);
        lay_cancel = findViewById(R.id.lay_cancel);
        et_empcode = findViewById(R.id.et_empcode);
        et_empcode.setEnabled(true);
        et_empcode.setFocusable(false);
        et_newpass = findViewById(R.id.et_newpass);
        et_confirmpass = findViewById(R.id.et_confirmpass);

        sessionManager=new SessionManager(PasswardConfirmActivity.this);

        bundle = getIntent().getExtras();
        if(bundle!=null)
        {
            empCode = bundle.getString("empcode");
            et_empcode.setText(bundle.getString("empcode"));
        }

        lay_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ActivityCompat.finishAffinity(PasswardConfirmActivity.this);
            }
        });

        lay_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(et_newpass.getText().toString().trim().equals(et_confirmpass.getText().toString().trim()))
                {
                    if (CheckConnection.haveNetworkConnection(getApplicationContext()))
                    {
                        verify();
                    }
                    else {
                        Toast.makeText(PasswardConfirmActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                    }
                }
                else
                {
                    Toast.makeText(PasswardConfirmActivity.this, "Password Not Matched !", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void verify()
    {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(PasswardConfirmActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("emp_code",empCode);
            jsonParams.put("password",et_confirmpass.getText().toString().trim());
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Server.post(PasswardConfirmActivity.this,"",entity,"Establishment/Forgot_password/reset_password", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    try {
                        if (response.has("status") && Boolean.parseBoolean(response.getString("status")) ==true )
                        {
                            progressDialog.dismiss();
                            Toast.makeText(PasswardConfirmActivity.this, response.getString("message"), Toast.LENGTH_SHORT).show();

                            login(empCode,et_confirmpass.getText().toString().trim());
                        }
                        else {
                            progressDialog.dismiss();
                            Toast.makeText(PasswardConfirmActivity.this, response.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        progressDialog.dismiss();
                        Toast.makeText(PasswardConfirmActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(PasswardConfirmActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }





    public void login(String empcod , final String pass) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(PasswardConfirmActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("password",pass);
            jsonParams.put("username",empcod);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Server.post(PasswardConfirmActivity.this,"",entity,"Login/Login_now", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    try {
                        if (response.has("status_code") && response.getString("status_code").equalsIgnoreCase("200") &&
                                response.getString("jwtToken")!=null)
                        {
                            progressDialog.dismiss();

//                            sessionManager.createLoginSession(response.getString("user_type_id"),response.getString("user_code"),
//                                    response.getString("sgb_board_id"),response.getString("user_role_id"),response.getString("user_role_name"),
//                                    response.getString("user_key"),response.getString("user_name"),response.getString("jwtToken"),pass,response.getString("user_unique_key"),response.getString("category"));
                            Toast.makeText(PasswardConfirmActivity.this, response.getString("message"), Toast.LENGTH_SHORT).show();


                        } else {
                            progressDialog.dismiss();
                            Toast.makeText(PasswardConfirmActivity.this, response.getString("message"), Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        progressDialog.dismiss();
                        Toast.makeText(PasswardConfirmActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(PasswardConfirmActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }




    @Override
    public void onBackPressed()
    {
        ActivityCompat.finishAffinity(PasswardConfirmActivity.this);
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}