package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import ru.nikartm.support.ImageBadgeView;
import sgb.board.com.edu_katta.Adapter.PendingPaperListAdapter;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.PendingPaperListDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class PendingPaperListActivity extends AppCompatActivity {

    private RecyclerView rv_list1;
    private ArrayList<PendingPaperListDAO> studyMaterialSubDAOS;
    private PendingPaperListAdapter studyMaterialSubAdapter;
    PendingPaperListDAO studyMaterialSubDAO;

    private int index1 = 0,end = 20;
    private int count1=1;

    private String selectedItem;
    Toolbar mToolbar;

    ListView mDrawerList;
    RelativeLayout mDrawerPane;
    private DrawerLayout mDrawerLayout;

    ArrayList<NavItem> mNavItems = new ArrayList<NavItem>();

    Bundle bundle;
    TextView txt_subject,txt_count;

    String SubId="0",StudentId="",MobNo="";
    SessionManager sessionManager;

    ImageBadgeView notification_Iv;
    EditText search_Et;

    ImageView Iv_pic;
    TextView tv_name;
    ImageView img_cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_paper_list);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Daily Practice Paper");
        int red = Color.parseColor("#212121");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        img_cancel = (ImageView) findViewById(R.id.img_cancel);
        Iv_pic = (ImageView) findViewById(R.id.Iv_pic);
        tv_name = (TextView) findViewById(R.id.tv_name);
        sessionManager = new SessionManager(PendingPaperListActivity.this);
        if(sessionManager!=null)
        {
            String stid= sessionManager.getStudentId();
            String mob= sessionManager.getStuMobileno();
            String stnm= sessionManager.getStuName();
            String stp= sessionManager.getStuStuphoto();
            if(stid!=null)
            {
                StudentId = stid;
            }
            if(mob!=null)
            {
                MobNo = mob;
            }
            if(stnm!=null)
            {
                tv_name.setText(stnm);
            }
            if(stp!=null)
            {
                Glide.with(PendingPaperListActivity.this).load(stp).into(Iv_pic);
            }
        }
        notification_Iv = (ImageBadgeView) findViewById(R.id.notification_Iv);
        txt_subject = (TextView) findViewById(R.id.txt_subject);
        txt_count = (TextView) findViewById(R.id.txt_count);
        search_Et = (EditText) findViewById(R.id.search_Et);

        bundle = getIntent().getExtras();
        if(bundle!=null)
        {
            txt_subject.setText(bundle.getString("subject") +" - ");
            txt_count.setText(bundle.getString("video_count"));
            if(bundle.getString("subject_id").equalsIgnoreCase(""))
            {
                SubId = "0";
            }
            else
            {
                SubId = bundle.getString("subject_id");
            }

        }
        else
        {
            txt_subject.setText(" - ");
            txt_count.setText("0");
            SubId = "0";

        }

        img_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                search_Et.setText("");
            }
        });



        rv_list1 = findViewById(R.id.rv_list1);
        studyMaterialSubDAOS = new ArrayList<>();
        //studyMaterialSubAdapter = new PendingPaperListAdapter(rv_list1, studyMaterialSubDAOS,PendingPaperListActivity.this);

        rv_list1.setLayoutManager(new GridLayoutManager(PendingPaperListActivity.this,1));
        rv_list1.setItemAnimator(new DefaultItemAnimator());
        rv_list1.setNestedScrollingEnabled(false);

        studyMaterialSubAdapter = new PendingPaperListAdapter(rv_list1, studyMaterialSubDAOS,PendingPaperListActivity.this);
        studyMaterialSubAdapter.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                studyMaterialSubDAOS.add(null);
                studyMaterialSubAdapter.notifyItemInserted(studyMaterialSubDAOS.size() - 1);
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        index1 = studyMaterialSubDAOS.size();
                        end = index1 + 20;
                        count1 = count1 + 1;
                        if (CheckConnection.haveNetworkConnection(PendingPaperListActivity.this))
                        {
                            getData(count1);
                        }
                        else {
                            Toast.makeText(PendingPaperListActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });


        final long delay = 1000;
        final long[] last_text_edit = {0};
        final Handler handler = new Handler();

        final Runnable input_finish_checker = new Runnable() {
            public void run() {
                if (System.currentTimeMillis() > (last_text_edit[0] + delay - 500)) {

                    studyMaterialSubDAOS.clear();
                    index1 = 0;
                    count1 = 1;
                    rv_list1.setAdapter(studyMaterialSubAdapter);
                    getData(count1);
                }
            }
        };

        search_Et.addTextChangedListener(new TextWatcher()
             {
                 @Override
                 public void beforeTextChanged (CharSequence s,int start, int count,
                                                int after){
                 }
                 @Override
                 public void onTextChanged ( final CharSequence s, int start, int before,
                                             int count){
                     //You need to remove this to run only once
                     handler.removeCallbacks(input_finish_checker);

                 }
                 @Override
                 public void afterTextChanged ( final Editable s){
                     //avoid triggering event when text is empty
                     if (s.length() > 0) {
                         last_text_edit[0] = System.currentTimeMillis();
                         handler.postDelayed(input_finish_checker, delay);
                     }
                     else if(s.length() == 0)
                     {
                         last_text_edit[0] = System.currentTimeMillis();
                         handler.postDelayed(input_finish_checker, delay);
                     }
                     else {

                     }
                 }
             }
        );



        if (CheckConnection.haveNetworkConnection(PendingPaperListActivity.this))
        {
            index1 = 0;
            count1=1;
            studyMaterialSubDAOS.clear();
            studyMaterialSubAdapter.notifyDataSetChanged();

            getData(count1);
        }
        else {
            Toast.makeText(PendingPaperListActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }



        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        // Populate the Navigtion Drawer with options
        mDrawerPane = (RelativeLayout) findViewById(R.id.drawerPane);
        mDrawerList = (ListView) findViewById(R.id.navList);
        // Drawer Item click listeners
        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectItemFromDrawer(position);
            }
        });

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,mDrawerLayout,mToolbar,R.string.drawer_open,R.string.drawer_close){
            @Override
            public void onDrawerClosed(View v){
                super.onDrawerClosed(v);
            }

            @Override
            public void onDrawerOpened(View v) {
                super.onDrawerOpened(v);
            }
        };
        mDrawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();


        mNavItems.add(new NavItem(getResources().getString(R.string.home), getResources().getString(R.string.home_1),R.drawable.dashboard_icon2,"home"));

//        mNavItems.add(new NavItem(getResources().getString(R.string.myprofile), getResources().getString(R.string.myprofile_1),R.drawable.profile__icon5,"profile"));

        mNavItems.add(new NavItem(getResources().getString(R.string.mypayslip), getResources().getString(R.string.mypayslip_1),R.drawable.practicetest_icon,"practicetest"));


        mNavItems.add(new NavItem(getResources().getString(R.string.jeemocktest), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"jeemocktest"));

        mNavItems.add(new NavItem(getResources().getString(R.string.neetmocktest), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"neetmocktest"));


        mNavItems.add(new NavItem(getResources().getString(R.string.pfloanadvance), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"testresult"));

        mNavItems.add(new NavItem(getResources().getString(R.string.specialempreq), getResources().getString(R.string.specialempreq_1),R.drawable.practicetest_icon,"test"));

        // mNavItems.add(new NavItem(getResources().getString(R.string.providentfund), getResources().getString(R.string.providentfund_1),R.drawable.feedback_img,"feedback"));

        mNavItems.add(new NavItem(getResources().getString(R.string.uniform), getResources().getString(R.string.uniform_1),R.drawable.dpp_answer_icon,"submitted_dpp_ans"));

        mNavItems.add(new NavItem(getResources().getString(R.string.form16req), getResources().getString(R.string.form16req_1),R.drawable.report_icon,"report"));

       // mNavItems.add(new NavItem(getResources().getString(R.string.logout), getResources().getString(R.string.form16req_1),R.drawable.logout,"logout"));

        DrawerListAdapter adapter = new DrawerListAdapter(PendingPaperListActivity.this, mNavItems);
        mDrawerList.setAdapter(adapter);


        notification_Iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PendingPaperListActivity.this,NotificationActivity.class);
                startActivity(intent);
            }
        });

        if (CheckConnection.haveNetworkConnection(PendingPaperListActivity.this))
        {
            getNotiCount();
        }
        else {
            Toast.makeText(PendingPaperListActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }

    }


    private void selectItemFromDrawer(int position)
    {
        mDrawerList.setItemChecked(position, true);

        if(mNavItems.get(position).mAction_name.equalsIgnoreCase("home"))
        {
            Intent intent = new Intent(PendingPaperListActivity.this, DashboardActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("practicetest"))
        {
            Intent intent = new Intent(PendingPaperListActivity.this,RecordedSessionActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("jeemocktest"))
        {
            Intent intent = new Intent(PendingPaperListActivity.this,JeeMockTestActivity.class);
            intent.putExtra("Type","JEE");
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("neetmocktest"))
        {
            Intent intent = new Intent(PendingPaperListActivity.this,JeeMockTestActivity.class);
            intent.putExtra("Type","NEET");
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("testresult"))
        {
            Intent intent = new Intent(PendingPaperListActivity.this,TestResultActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("test"))
        {
            Intent intent = new Intent(PendingPaperListActivity.this,TestActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("feedback"))
        {
            Intent intent = new Intent(PendingPaperListActivity.this,FeedbackActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("submitted_dpp_ans"))
        {
            Intent intent = new Intent(PendingPaperListActivity.this,HelpDeskListActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("report"))
        {
            Intent intent = new Intent(PendingPaperListActivity.this,AskDoubtActivity.class);
            startActivity(intent);
//            Intent intent = new Intent(DashboardActivity.this,LibraryChapterWiseActivity.class);
//            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("logout"))
        {
           // logoutpopup();
        }
        // Close the drawer
        mDrawerLayout.closeDrawer(mDrawerPane);
    }


    class NavItem {
        String mTitle;
        String mSubtitle,mAction_name;
        int mIcon;

        public NavItem(String title, String subtitle, int icon ,String action_name) {
            mTitle = title;
            mSubtitle = subtitle;
            mIcon = icon;
            mAction_name = action_name;
        }
    }

    class DrawerListAdapter extends BaseAdapter {

        Context mContext;
        ArrayList<NavItem> mNavItems;

        public DrawerListAdapter(Context context, ArrayList<NavItem> navItems) {
            mContext = context;
            mNavItems = navItems;
        }

        @Override
        public int getCount() {
            return mNavItems.size();
        }

        @Override
        public Object getItem(int position) {
            return mNavItems.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view;

            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.drawer_item, null);
            }
            else {
                view = convertView;
            }

            TextView titleView = (TextView) view.findViewById(R.id.title);
//            TextView subtitleView = (TextView) view.findViewById(R.id.subTitle);
            TextView actionname = (TextView) view.findViewById(R.id.actionname);
            ImageView iconView = (ImageView) view.findViewById(R.id.icon);

            titleView.setText( mNavItems.get(position).mTitle );
//            subtitleView.setText( mNavItems.get(position).mSubtitle );
            actionname.setText( mNavItems.get(position).mAction_name );

            Glide.with(PendingPaperListActivity.this).load(mNavItems.get(position).mIcon).into(iconView);


            return view;
        }
    }


    public void getNotiCount() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(PendingPaperListActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", MobNo);
            jsonParams.put("limit", 20);
            jsonParams.put("page_no", 1);
            jsonParams.put("count", true);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(PendingPaperListActivity.this,"",entity,"Data/notificationlistmaster", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, String response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

//                    try
//                    {
//                        if(response.length()>0)
//                        {
//                            progressDialog.dismiss();
//
//                            if(response.length()>0)
//                            {
//                                String st="";
//                                for(int i=0 ; i<response.length(); i++)
//                                {
//                                    JSONObject jsonObject = response.getJSONObject(i);
//
//                                    if (jsonObject.getString("message")==null || jsonObject.getString("message").equalsIgnoreCase("null")||jsonObject.getString("message").equalsIgnoreCase(""))
//                                    {
////                                        noticeDAO.setName("");
//                                    }
//                                    else
//                                    {
//                                        st = st.concat(jsonObject.getString("message"));
//                                        st = st.concat("    |    ");
//                                    }
//                                }
//
//                                txt_noticemarquee.setText(st);
//                            }
//
//                        }
//                        else {
//                            progressDialog.dismiss();
//                            // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
//                        }
//
//                    }
//                    catch (Exception e)
//                    {
//                        e.printStackTrace();
//                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString() +"..."+String.valueOf(statusCode));
                    if(statusCode==200)
                    {
                        notification_Iv.setBadgeValue(Integer.parseInt(responseString));
                    }
                    else
                    {
                        Toast.makeText(PendingPaperListActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                    }
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }



    public void getData(int count) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(PendingPaperListActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE",MobNo);
            jsonParams.put("SUBJECT",Integer.parseInt(SubId));
            jsonParams.put("limit",20);
            jsonParams.put("page_no",count);
            jsonParams.put("searchText",search_Et.getText().toString().trim());
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(PendingPaperListActivity.this,"",entity,"Data/getdpp", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if (index1 != 0) {
                            studyMaterialSubDAOS.remove(studyMaterialSubDAOS.size() - 1);
                            studyMaterialSubAdapter.notifyItemRemoved(studyMaterialSubDAOS.size());
                        }

                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                studyMaterialSubDAO = new PendingPaperListDAO();


                                if (jsonObject.getString("teacheR_NAME")==null || jsonObject.getString("teacheR_NAME").equalsIgnoreCase("null")||jsonObject.getString("teacheR_NAME").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setTeacheR_NAME("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setTeacheR_NAME(jsonObject.getString("teacheR_NAME"));
                                }
                                if (jsonObject.getString("schedule")==null || jsonObject.getString("schedule").equalsIgnoreCase("null")||jsonObject.getString("schedule").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setSchedule("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setSchedule(jsonObject.getString("schedule"));
                                }
                                if (jsonObject.getString("course")==null || jsonObject.getString("course").equalsIgnoreCase("null")||jsonObject.getString("course").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setCourse("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setCourse(jsonObject.getString("course"));
                                }
                                if (jsonObject.getString("subject")==null || jsonObject.getString("subject").equalsIgnoreCase("null")||jsonObject.getString("subject").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setSubject("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setSubject(jsonObject.getString("subject"));
                                }
                                if (jsonObject.getString("topic")==null || jsonObject.getString("topic").equalsIgnoreCase("null")||jsonObject.getString("topic").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setTopic("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setTopic(jsonObject.getString("topic"));
                                }
                                if (jsonObject.getString("storeD_LINK")==null || jsonObject.getString("storeD_LINK").equalsIgnoreCase("null")||jsonObject.getString("storeD_LINK").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setStoreD_LINK("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setStoreD_LINK(jsonObject.getString("storeD_LINK"));
                                }

                                if (jsonObject.getString("uploadeD_ASSIGNMENT")==null || jsonObject.getString("uploadeD_ASSIGNMENT").equalsIgnoreCase("null")||jsonObject.getString("uploadeD_ASSIGNMENT").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setUploadeD_ASSIGNMENT("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setUploadeD_ASSIGNMENT(jsonObject.getString("uploadeD_ASSIGNMENT"));
                                }
                                if (jsonObject.getString("uploadeD_ANSWER")==null || jsonObject.getString("uploadeD_ANSWER").equalsIgnoreCase("null")||jsonObject.getString("uploadeD_ANSWER").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setUploadeD_ANSWER("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setUploadeD_ANSWER(jsonObject.getString("uploadeD_ANSWER"));
                                }
                                if (jsonObject.getString("studenT_ID")==null || jsonObject.getString("studenT_ID").equalsIgnoreCase("null")||jsonObject.getString("studenT_ID").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setStudenT_ID("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setStudenT_ID(jsonObject.getString("studenT_ID"));
                                }
                                if (jsonObject.getString("submitteD_ANSWER")==null || jsonObject.getString("submitteD_ANSWER").equalsIgnoreCase("null")||jsonObject.getString("submitteD_ANSWER").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setSubmitteD_ANSWER("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setSubmitteD_ANSWER(jsonObject.getString("submitteD_ANSWER"));
                                }
                                if (jsonObject.getString("vieW_ANSWER")==null || jsonObject.getString("vieW_ANSWER").equalsIgnoreCase("null")||jsonObject.getString("vieW_ANSWER").equalsIgnoreCase(""))
                                {
                                    studyMaterialSubDAO.setVieW_ANSWER("");
                                }
                                else
                                {
                                    studyMaterialSubDAO.setVieW_ANSWER(jsonObject.getString("vieW_ANSWER"));
                                }


                                studyMaterialSubDAOS.add(studyMaterialSubDAO);
                            }


                            if (index1 == 0 && end == 20)
                            {
                                rv_list1.setAdapter(studyMaterialSubAdapter);
                            }else{
                                Log.e("index and end",index1+","+end);
                            }
                            studyMaterialSubAdapter.notifyDataSetChanged();
                            studyMaterialSubAdapter.setLoaded();

                        }
                        else {
                            studyMaterialSubAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            Toast.makeText(PendingPaperListActivity.this, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(PendingPaperListActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }
}