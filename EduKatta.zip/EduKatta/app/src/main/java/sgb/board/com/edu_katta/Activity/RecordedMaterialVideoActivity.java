package sgb.board.com.edu_katta.Activity;

import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerFragment;

import sgb.board.com.edu_katta.Custom.Config;
import sgb.board.com.edu_katta.R;

public class RecordedMaterialVideoActivity extends AppCompatActivity {
    Toolbar mToolbar;
    YouTubePlayerFragment youtubeFragment;
    private String videoCode="";
    private Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recorded_material_video);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("");
        int red = Color.parseColor("#FFFFFF");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        init();
    }

    private void init() {

        youtubeFragment = (YouTubePlayerFragment) getFragmentManager().findFragmentById(R.id.youtubeFragment);

        bundle = getIntent().getExtras();
        if(bundle!=null) {
            //String[] splitArray = bundle.getString("news_url").split("v=");

            String[] splitArray = bundle.getString("url").split("\\/");
            String st2 = splitArray[4];
            String[] splitArray2 = st2.split("\\?");
            String st3 = splitArray2[0];
            //Log.e("data..","..."+splitArray2[0]);
            videoCode = st3;

        }

        Handler mHandler = new Handler(getMainLooper());
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                youtubeFragment.initialize(String.valueOf(Config.DEVELOPER_KEY), new YouTubePlayer.OnInitializedListener()
                {
                    @Override
                    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b)
                    {
                        youTubePlayer.cueVideo(videoCode);
                        youTubePlayer.play();
                    }
                    @Override
                    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult)
                    {
                    }
                });
            }
        });


    }


    @Override
    public void onBackPressed() {

        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}