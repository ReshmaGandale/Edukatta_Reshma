package sgb.board.com.edu_katta.Activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.Toast;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;
import com.google.firebase.iid.FirebaseInstanceId;
import com.hmdm.HeadwindMDM;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.readystatesoftware.chuck.ChuckInterceptor;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.UnsupportedEncodingException;

import sgb.board.com.edu_katta.R;
import sgb.thebrownarrow.permissionhelper.ActivityManagePermission;
import sgb.thebrownarrow.permissionhelper.PermissionResult;
import sgb.thebrownarrow.permissionhelper.PermissionUtils;

public class SplashActivity extends ActivityManagePermission implements HeadwindMDM.EventHandler{
    public static ChuckInterceptor mChuckInterceptor;
    public static String BRAND="";
    public static String DETAILS="";
    public static String MODEL="";
    public static  String PRODUCT="";
    public static  String PRODUCT_ID="";
    public static String myNetwork="";
    public String Device_ID="",Device_Token="";
    public static SessionManager sessionManager;
   // String android_id ="";
   private HeadwindMDM headwindMDM;

    String permissionAsk[] = { PermissionUtils.Manifest_WRITE_EXTERNAL_STORAGE, PermissionUtils.Manifest_READ_EXTERNAL_STORAGE,
            PermissionUtils.Manifest_CAMERA,PermissionUtils.Manifest_READ_PHONE_STATE };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        headwindMDM = HeadwindMDM.getInstance();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }
        setContentView(R.layout.activity_splash);

        Device_Token = FirebaseInstanceId.getInstance().getToken();
//        android_id = Secure.getString(getApplicationContext().getContentResolver(), Secure.ANDROID_ID);
//        Log.e("Android..id..",".."+android_id);

        Animation anim = AnimationUtils.loadAnimation(this, R.anim.alpha);
        anim.reset();
        LinearLayout l=(LinearLayout) findViewById(R.id.lin_lay);
        l.clearAnimation();
        l.startAnimation(anim);


        int SPLASH_TIME_OUT = 5000;
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
//                sessionManager.setStuMobileno("9096799390");
//                sessionManager.setDeviceid("R9PT417X3PP");
                mChuckInterceptor = new ChuckInterceptor(SplashActivity.this);
                Device_Token = FirebaseInstanceId.getInstance().getToken();

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    System.out.println("MYSERVICE_IF");
                    askCompactPermissions(permissionAsk, new PermissionResult() {
                        @Override
                        public void permissionGranted() {
                            show();
                        }
                        @Override
                        public void permissionDenied() {

                            show();
                        }
                        @Override
                        public void permissionForeverDenied() {

                            show();
                        }
                    });
                } else {
                    show();
                }
            }
        }, SPLASH_TIME_OUT);

        bindView();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1000) {
            if (resultCode == Activity.RESULT_OK) {
                String result = data.getStringExtra("result");
                show();
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
            }
        }
    }

    public void bindView() {

        sessionManager =new SessionManager(SplashActivity.this);
        if(sessionManager!=null)
        {
            String dvid = sessionManager.getDeviceid();
            if(dvid!=null)
            {
                Device_ID = dvid;
            }
        }
    }



    public void show(){

        Log.e("jay","shoecall");
//        TelephonyManager manager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
//        DETAILS = Build.VERSION.RELEASE;
//        BRAND= Build.BRAND;
//        MODEL = Build.MODEL;
//        PRODUCT = Build.PRODUCT;

        System.out.println("My_Device id firebase "+Device_Token);

        //System.out.println("jay_My_Devi "+sessionManager.getDeviceid());


//        Intent i = new Intent(SplashActivity.this, DashboardActivity.class);
//        sessionManager.setStuMobileno("9096799390");
//        startActivity(i);

        if (Device_ID==null || Device_ID.equalsIgnoreCase(""))
        {
            boolean val = CheckConnection.haveNetworkConnection(getApplicationContext());
            Log.e("Connection",String.valueOf(val));
            if (val==false)
            {
                Toast.makeText(SplashActivity.this,"Network Not Available",Toast.LENGTH_LONG).show();
            }
            else{
               // Devicereg(BRAND, MODEL, PRODUCT, myNetwork, Device_ID,DETAILS);
                //Devicereg(Device_Token,android_ID);
                Log.e("Dev_Tokan",".."+Device_ID);
                //Log.e("Dev_id",".."+android_id);
               // sessionManager.setDeviceid(Device_Token);
                //sessionManager.setAndroidId(android_id);

//                if (sessionManager.isLoggedIn())
//                {
//                    Intent i = new Intent(SplashActivity.this, StartActivity.class);
//                    startActivity(i);
//                    finish();
//                }
//                else {

                    if (CheckConnection.haveNetworkConnection(getApplicationContext()))
                    {
                        checkStudent();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
                    }
//                }
            }

        }
        else
        {
            Log.e("Dev_Tokan",".."+sessionManager.getDeviceid());
//            if (sessionManager.isLoggedIn())
//            {
//                Intent i = new Intent(SplashActivity.this, StartActivity.class);
//                startActivity(i);
//                finish();
//            }
//            else {

                if (CheckConnection.haveNetworkConnection(getApplicationContext()))
                {
                    checkStudent();
                }
                else {
                    Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
                }
//            }
        }
    }


    public void checkStudent() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(SplashActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("DEVICE_ID",Device_ID);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(SplashActivity.this,"",entity,"Data/getStudentDeviceRegistration", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());

                    progressDialog.dismiss();

                    if (String.valueOf(statusCode).equalsIgnoreCase("200"))
                    {
                        Intent intent = new Intent(SplashActivity.this,StartActivity.class);
                        startActivity(intent);
                    }
                    else {
                        progressDialog.dismiss();
                        Intent intent = new Intent(SplashActivity.this,StudentDetailFormActivity.class);
                        startActivity(intent);
                        //Toast.makeText(SplashActivity.this, "Somthing went wrong", Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();

                    if(String.valueOf(statusCode).equalsIgnoreCase("300"))
                    {
                        Intent intent = new Intent(SplashActivity.this,DashboardActivity.class); //StudentDetailFormActivity
                        startActivity(intent);
                    }
                    else {
                        Log.e("error..is", ".." + responseString.toString());
                        Toast.makeText(SplashActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                    }

                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (!headwindMDM.isConnected()) {
            if (!headwindMDM.connect(this, this)) {
                // Your application is running outside Headwind MDM
            }
        } else {
            // Already connected, but settings may have changed
            // when our app was in the background, so reload them
            loadSettings();
        }
    }

    @Override
    protected void onDestroy() {
        headwindMDM.disconnect(this);
        super.onDestroy();
    }

    @Override
    public void onHeadwindMDMConnected() {
        loadSettings();
    }

    @Override
    public void onHeadwindMDMDisconnected() {

    }

    @Override
    public void onHeadwindMDMConfigChanged() {
        loadSettings();
    }

    private void loadSettings() {

        Device_ID = headwindMDM.getDeviceId();
        sessionManager.setDeviceid(Device_ID);
    }

}
