package sgb.board.com.edu_katta.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import sgb.board.com.edu_katta.R;

public class StartActivity extends AppCompatActivity implements View.OnClickListener{

    LinearLayout lay_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        init();
    }

    public void init()
    {
        lay_login = (LinearLayout) findViewById(R.id.lay_login);
        lay_login.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if(v==lay_login)
        {
            Intent intent = new Intent(StartActivity.this,LoginActivity.class);
            startActivity(intent);
        }
    }


    @Override
    public void onBackPressed() {
        finishAffinity();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}