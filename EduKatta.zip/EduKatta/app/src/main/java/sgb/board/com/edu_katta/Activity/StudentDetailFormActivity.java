package sgb.board.com.edu_katta.Activity;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.BuildConfig;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Custom.FilePath;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class StudentDetailFormActivity extends AppCompatActivity {

    Toolbar mToolbar;

    EditText et_studentname,et_collegename,et_bookaddress,et_address,et_city,et_pincode,
            et_10thcertificate,et_bonafiedcertificate,et_noncreamycertificate,et_aadharcard,et_contactno,et_mobileno,et_otp,et_parentname,et_parentmob;

    private Bitmap bitmap = null;
    private String userChoosenTask="";
    String currentImagePath;

    CardView crd_save,crd_sendotp,crd_verify,crd_reset;
    Spinner class_spinner,entranceexam_spinner,provider_spinner;

    SessionManager sessionManager;
    String DeviceId="",MobileNo="",Student_Id="";
    String Clssname="",EntrancName="",Provider="";
    TextView deviceid_txt;

    Uri filePathuri;
    String imageType="",mainpath="";
    String imgName_1="",imgName_2="",imgName_3="",imgName_4="";


   // String tabDevid="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_detail_form);


        init();
    }

    public void init()
    {


        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Student Details Form");
        int red = Color.parseColor("#212121");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        deviceid_txt = findViewById(R.id.deviceid_txt);

        sessionManager=new SessionManager(StudentDetailFormActivity.this);
        if(sessionManager!=null)
        {
            String id = sessionManager.getDeviceid();
            String anid = sessionManager.getAndroidId();
            String mob = sessionManager.getStuMobileno();
            String stid = sessionManager.getStudentId();
            if(id!=null)
            {
                DeviceId = id;
                deviceid_txt.setText(DeviceId);
            }
            if(mob!=null)
            {
                MobileNo = mob;
            }
            if(stid!=null)
            {
                Student_Id = stid;
            }
        }

        et_studentname = (EditText) findViewById(R.id.et_studentname);
        et_parentname = (EditText) findViewById(R.id.et_parentname);
        et_parentmob = (EditText) findViewById(R.id.et_parentmob);
        et_collegename = (EditText) findViewById(R.id.et_collegename);
        et_address = (EditText) findViewById(R.id.et_address);
        et_bookaddress = (EditText) findViewById(R.id.et_bookaddress);
        et_city = (EditText) findViewById(R.id.et_city);
        et_pincode = (EditText) findViewById(R.id.et_pincode);
        et_10thcertificate = (EditText) findViewById(R.id.et_10thcertificate);
        et_bonafiedcertificate = (EditText) findViewById(R.id.et_bonafiedcertificate);
        et_noncreamycertificate = (EditText) findViewById(R.id.et_noncreamycertificate);
        et_aadharcard = (EditText) findViewById(R.id.et_aadharcard);
        et_contactno = (EditText) findViewById(R.id.et_contactno);
        et_mobileno = (EditText) findViewById(R.id.et_mobileno);
        et_otp = (EditText) findViewById(R.id.et_otp);

        class_spinner = (Spinner) findViewById(R.id.class_spinner);
        entranceexam_spinner = (Spinner) findViewById(R.id.entranceexam_spinner);
        provider_spinner = (Spinner) findViewById(R.id.provider_spinner);

        et_10thcertificate.setEnabled(true);
        et_10thcertificate.setFocusable(false);

        et_bonafiedcertificate.setEnabled(true);
        et_bonafiedcertificate.setFocusable(false);

        et_noncreamycertificate.setEnabled(true);
        et_noncreamycertificate.setFocusable(false);

        et_aadharcard.setEnabled(true);
        et_aadharcard.setFocusable(false);

        crd_save = (CardView) findViewById(R.id.crd_save);
        crd_sendotp = (CardView) findViewById(R.id.crd_sendotp);
        crd_verify = (CardView) findViewById(R.id.crd_verify);
        crd_reset = (CardView) findViewById(R.id.crd_reset);

        crd_save.setEnabled(false);

        crd_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                et_studentname.setText("");
                et_collegename.setText("");
                et_address.setText("");
                et_bookaddress.setText("");
                et_city.setText("");
                et_pincode.setText("");
                et_contactno.setText("");
                et_mobileno.setText("");
                et_otp.setText("");
            }
        });

        crd_sendotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(et_mobileno.getText().toString().equalsIgnoreCase("") || et_mobileno.getText().toString().length() != 10)
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Enter OTP", Toast.LENGTH_LONG).show();
                }
                else
                {
                    if (CheckConnection.haveNetworkConnection(getApplicationContext()))
                    {
                        sendOTP();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });


        crd_verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(et_otp.getText().toString().equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Enter OTP", Toast.LENGTH_LONG).show();
                }
                else
                {
                    if (CheckConnection.haveNetworkConnection(getApplicationContext()))
                    {
                        optVerify();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        crd_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(et_studentname.getText().toString().equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Enter Student Name", Toast.LENGTH_LONG).show();
                }
                else if(et_collegename.getText().toString().equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Enter College Name", Toast.LENGTH_LONG).show();
                }
                else if(Clssname.equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Select Class Name", Toast.LENGTH_LONG).show();
                }
                else if(EntrancName.equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Select Stream Name", Toast.LENGTH_LONG).show();
                }
                else if(Provider.equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Select Provider Name", Toast.LENGTH_LONG).show();
                }
                else if(et_address.getText().toString().equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Enter Address", Toast.LENGTH_LONG).show();
                }
                else if(et_bookaddress.getText().toString().equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Enter Delivery Address", Toast.LENGTH_LONG).show();
                }
                else if(et_city.getText().toString().equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Enter City", Toast.LENGTH_LONG).show();
                }
                else if(et_pincode.getText().toString().equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Enter Pincode", Toast.LENGTH_LONG).show();
                }
                else if(et_contactno.getText().toString().equalsIgnoreCase(""))
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Enter Contact Number", Toast.LENGTH_LONG).show();
                }
                else
                {
                    if (CheckConnection.haveNetworkConnection(getApplicationContext())) {
                        saveDetails();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Network is not available", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });


        et_10thcertificate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setProfilePic();
            }
        });

        et_bonafiedcertificate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setProfilePic_2();
            }
        });


        et_noncreamycertificate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setProfilePic_3();
            }
        });


        et_aadharcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setProfilePic_4();
            }
        });


        List<String> classes = new ArrayList<String>();
        classes.add("XI");
        classes.add("XII");

        List<String> entran = new ArrayList<String>();
        entran.add("JEE");
        entran.add("NEET");
        entran.add("JEE + NEET");

        List<String> provider = new ArrayList<String>();
        provider.add("Airtel");
        provider.add("Vodafone");


        ArrayAdapter<String> monthAdapter = new ArrayAdapter<String>(StudentDetailFormActivity.this, android.R.layout.simple_spinner_item, classes);
        // Drop down layout style - list view with radio button
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        class_spinner.setAdapter(monthAdapter);
        //inst_startmonth_spinner.setSelection(3);
        class_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                Log.v("item", (String) parent.getItemAtPosition(position));
                Clssname = (String) parent.getItemAtPosition(position);

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>(StudentDetailFormActivity.this, android.R.layout.simple_spinner_item, entran);
        // Drop down layout style - list view with radio button
        //yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        entranceexam_spinner.setAdapter(yearAdapter);
        //inst_startyear_spinner.setSelection(3);
        entranceexam_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                Log.v("item", (String) parent.getItemAtPosition(position));
                EntrancName = (String) parent.getItemAtPosition(position);

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        ArrayAdapter<String> providerAdapter = new ArrayAdapter<String>(StudentDetailFormActivity.this, android.R.layout.simple_spinner_item, provider);
        // Drop down layout style - list view with radio button
        providerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        provider_spinner.setAdapter(providerAdapter);
        //inst_startmonth_spinner.setSelection(3);
        provider_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                Log.v("item", (String) parent.getItemAtPosition(position));
                Provider = (String) parent.getItemAtPosition(position);

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }


    public void setProfilePic()
    {
        final CharSequence[] items = { "Camera", "Choose from Gallery", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(StudentDetailFormActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Camera")) {
                    userChoosenTask="Camera";
                    takeCameraImage();
                } else if (items[item].equals("Choose from Gallery")) {
                    userChoosenTask="Choose from Gallery";
                    takeGalleryImage();
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    public void takeCameraImage()
    {
        if (!checkIfAlreadyhavePermission()) {
            requestForSpecificPermission();
        } else {

            try {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(StudentDetailFormActivity.this, BuildConfig.APPLICATION_ID + ".fileprovider_mahajyoti", createImageFile()));
                startActivityForResult(intent, 1);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    public void takeGalleryImage()
    {
        Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 2);
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (resultCode) {

            case Activity.RESULT_OK: {

                switch (requestCode) {
                    case 1: {

                        try {

                            Bitmap bm = BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(currentImagePath)));

                            ExifInterface ei = new ExifInterface(getContentResolver().openInputStream(Uri.parse(currentImagePath)));
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bm, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bm, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bm, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bm;
                            }

                          //  picIv.setImageBitmap(rotatedBitmap);

                            String img = getStringImage(rotatedBitmap);

                            if (CheckConnection.haveNetworkConnection(StudentDetailFormActivity.this)) {

                                Uri file = Uri.fromFile(new File(currentImagePath));
                                filePathuri = Uri.fromFile(new File(currentImagePath));

                                Uri filePath = Uri.parse(currentImagePath);
                                String path = FilePath.getPath(this, filePath);

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());
                                //Log.e("path",".."+fileExt);

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                Log.e("name..", ".." + currentImagePath);


                                saveImageService("1",imageType, Student_Id +"_"+ ts + "." + imageType, new File(path));


                            }
                            else {
                                Toast.makeText(StudentDetailFormActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }catch (IOException e)
                        {
                            e.printStackTrace();
                        }

                    }

                    break;

                    case 2: {

                        try {

                            Uri selectedImage = data.getData();
                            String[] filePath = {MediaStore.Images.Media.DATA};
                            Cursor c = getContentResolver().query(selectedImage, filePath, null, null, null);
                            c.moveToFirst();
                            int columnIndex = c.getColumnIndex(filePath[0]);
                            String picturePath = c.getString(columnIndex);
                            c.close();
                            bitmap = (BitmapFactory.decodeFile(picturePath));


                            ExifInterface ei = new ExifInterface(picturePath);
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bitmap, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bitmap, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bitmap, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bitmap;
                            }


                          //  picIv.setImageBitmap(rotatedBitmap);

                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                            byte[] imageBytes = baos.toByteArray();
                            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);

                            if (CheckConnection.haveNetworkConnection(StudentDetailFormActivity.this)) {

                                Uri file = Uri.fromFile(new File(picturePath));

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                saveImageService("1",imageType,Student_Id +"_"+ts+"."+imageType,new File(picturePath));


                            } else {
                                Toast.makeText(StudentDetailFormActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }
                        }
                        catch (IOException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    break;


                    case 3: {

                        try {

                            Bitmap bm = BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(currentImagePath)));

                            ExifInterface ei = new ExifInterface(getContentResolver().openInputStream(Uri.parse(currentImagePath)));
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bm, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bm, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bm, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bm;
                            }

                            //  picIv.setImageBitmap(rotatedBitmap);

                            String img = getStringImage(rotatedBitmap);

                            if (CheckConnection.haveNetworkConnection(StudentDetailFormActivity.this)) {

                                Uri file = Uri.fromFile(new File(currentImagePath));
                                filePathuri = Uri.fromFile(new File(currentImagePath));

                                Uri filePath = Uri.parse(currentImagePath);
                                String path = FilePath.getPath(this, filePath);

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());
                                //Log.e("path",".."+fileExt);

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                Log.e("name..", ".." + currentImagePath);


                                saveImageService("2",imageType, Student_Id +"_"+ts + "." + imageType, new File(path));


                            }
                            else {
                                Toast.makeText(StudentDetailFormActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }catch (IOException e)
                        {
                            e.printStackTrace();
                        }

                    }

                    break;

                    case 4: {

                        try {

                            Uri selectedImage = data.getData();
                            String[] filePath = {MediaStore.Images.Media.DATA};
                            Cursor c = getContentResolver().query(selectedImage, filePath, null, null, null);
                            c.moveToFirst();
                            int columnIndex = c.getColumnIndex(filePath[0]);
                            String picturePath = c.getString(columnIndex);
                            c.close();
                            bitmap = (BitmapFactory.decodeFile(picturePath));


                            ExifInterface ei = new ExifInterface(picturePath);
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bitmap, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bitmap, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bitmap, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bitmap;
                            }


                            //  picIv.setImageBitmap(rotatedBitmap);

                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                            byte[] imageBytes = baos.toByteArray();
                            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);

                            if (CheckConnection.haveNetworkConnection(StudentDetailFormActivity.this)) {

                                Uri file = Uri.fromFile(new File(picturePath));

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                saveImageService("2",imageType,Student_Id +"_"+ts+"."+imageType,new File(picturePath));


                            } else {
                                Toast.makeText(StudentDetailFormActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }
                        }
                        catch (IOException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    break;







                    case 5: {

                        try {

                            Bitmap bm = BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(currentImagePath)));

                            ExifInterface ei = new ExifInterface(getContentResolver().openInputStream(Uri.parse(currentImagePath)));
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bm, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bm, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bm, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bm;
                            }

                            //  picIv.setImageBitmap(rotatedBitmap);

                            String img = getStringImage(rotatedBitmap);

                            if (CheckConnection.haveNetworkConnection(StudentDetailFormActivity.this)) {

                                Uri file = Uri.fromFile(new File(currentImagePath));
                                filePathuri = Uri.fromFile(new File(currentImagePath));

                                Uri filePath = Uri.parse(currentImagePath);
                                String path = FilePath.getPath(this, filePath);

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());
                                //Log.e("path",".."+fileExt);

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                Log.e("name..", ".." + currentImagePath);


                                saveImageService("3",imageType, Student_Id +"_"+ts + "." + imageType, new File(path));


                            }
                            else {
                                Toast.makeText(StudentDetailFormActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }catch (IOException e)
                        {
                            e.printStackTrace();
                        }

                    }

                    break;

                    case 6: {

                        try {

                            Uri selectedImage = data.getData();
                            String[] filePath = {MediaStore.Images.Media.DATA};
                            Cursor c = getContentResolver().query(selectedImage, filePath, null, null, null);
                            c.moveToFirst();
                            int columnIndex = c.getColumnIndex(filePath[0]);
                            String picturePath = c.getString(columnIndex);
                            c.close();
                            bitmap = (BitmapFactory.decodeFile(picturePath));


                            ExifInterface ei = new ExifInterface(picturePath);
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bitmap, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bitmap, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bitmap, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bitmap;
                            }


                            //  picIv.setImageBitmap(rotatedBitmap);

                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                            byte[] imageBytes = baos.toByteArray();
                            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);

                            if (CheckConnection.haveNetworkConnection(StudentDetailFormActivity.this)) {

                                Uri file = Uri.fromFile(new File(picturePath));

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                saveImageService("3",imageType,Student_Id +"_"+ts+"."+imageType,new File(picturePath));


                            } else {
                                Toast.makeText(StudentDetailFormActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }
                        }
                        catch (IOException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    break;





                    case 7: {

                        try {

                            Bitmap bm = BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(currentImagePath)));

                            ExifInterface ei = new ExifInterface(getContentResolver().openInputStream(Uri.parse(currentImagePath)));
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bm, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bm, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bm, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bm;
                            }

                            //  picIv.setImageBitmap(rotatedBitmap);

                            String img = getStringImage(rotatedBitmap);

                            if (CheckConnection.haveNetworkConnection(StudentDetailFormActivity.this)) {

                                Uri file = Uri.fromFile(new File(currentImagePath));
                                filePathuri = Uri.fromFile(new File(currentImagePath));

                                Uri filePath = Uri.parse(currentImagePath);
                                String path = FilePath.getPath(this, filePath);

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());
                                //Log.e("path",".."+fileExt);

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                Log.e("name..", ".." + currentImagePath);


                                saveImageService("4",imageType, Student_Id +"_"+ts + "." + imageType, new File(path));


                            }
                            else {
                                Toast.makeText(StudentDetailFormActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }catch (IOException e)
                        {
                            e.printStackTrace();
                        }

                    }

                    break;

                    case 8: {

                        try {

                            Uri selectedImage = data.getData();
                            String[] filePath = {MediaStore.Images.Media.DATA};
                            Cursor c = getContentResolver().query(selectedImage, filePath, null, null, null);
                            c.moveToFirst();
                            int columnIndex = c.getColumnIndex(filePath[0]);
                            String picturePath = c.getString(columnIndex);
                            c.close();
                            bitmap = (BitmapFactory.decodeFile(picturePath));


                            ExifInterface ei = new ExifInterface(picturePath);
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bitmap, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bitmap, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bitmap, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bitmap;
                            }


                            //  picIv.setImageBitmap(rotatedBitmap);

                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                            byte[] imageBytes = baos.toByteArray();
                            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);

                            if (CheckConnection.haveNetworkConnection(StudentDetailFormActivity.this)) {

                                Uri file = Uri.fromFile(new File(picturePath));

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                saveImageService("4",imageType,Student_Id +"_"+ts+"."+imageType,new File(picturePath));


                            } else {
                                Toast.makeText(StudentDetailFormActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }
                        }
                        catch (IOException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    break;
                }
            }
        }

    }

    public static Bitmap rotateImage(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(),
                matrix, true);
    }

    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        Log.e("hiiiii",encodedImage);
        return encodedImage;
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        //This is the directory in which the file will be created. This is the default location of Camera photos
        File storageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DCIM), "Camera");
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        // Save a file: path for using again
        currentImagePath = "file://" + image.getAbsolutePath();
        return image;
    }

    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
    }

    private boolean checkIfAlreadyhavePermission() {
        int fine = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int read = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int write = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (fine == PackageManager.PERMISSION_GRANTED) {
            Log.e("permission1", "fine");
            return true;
        }
        if (read == PackageManager.PERMISSION_GRANTED) {
            Log.e("permission2", "coarse");
            return true;
        }
        if (write == PackageManager.PERMISSION_GRANTED) {
            Log.e("permission2", "coarse");
            return true;
        } else {
            return false;
        }
    }


    public void setProfilePic_2()
    {
        final CharSequence[] items = { "Camera", "Choose from Gallery", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(StudentDetailFormActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Camera")) {
                    userChoosenTask="Camera";
                    takeCameraImage_2();
                } else if (items[item].equals("Choose from Gallery")) {
                    userChoosenTask="Choose from Gallery";
                    takeGalleryImage_2();
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    public void takeCameraImage_2()
    {
        if (!checkIfAlreadyhavePermission()) {
            requestForSpecificPermission();
        } else {

            try {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(StudentDetailFormActivity.this, BuildConfig.APPLICATION_ID + ".fileprovider_mahajyoti", createImageFile()));
                startActivityForResult(intent, 3);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    public void takeGalleryImage_2()
    {
        Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 4);
    }





    public void setProfilePic_3()
    {
        final CharSequence[] items = { "Camera", "Choose from Gallery", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(StudentDetailFormActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Camera")) {
                    userChoosenTask="Camera";
                    takeCameraImage_3();
                } else if (items[item].equals("Choose from Gallery")) {
                    userChoosenTask="Choose from Gallery";
                    takeGalleryImage_3();
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    public void takeCameraImage_3()
    {
        if (!checkIfAlreadyhavePermission()) {
            requestForSpecificPermission();
        } else {

            try {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(StudentDetailFormActivity.this, BuildConfig.APPLICATION_ID + ".fileprovider_mahajyoti", createImageFile()));
                startActivityForResult(intent, 5);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    public void takeGalleryImage_3()
    {
        Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 6);
    }




    public void setProfilePic_4()
    {
        final CharSequence[] items = { "Camera", "Choose from Gallery", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(StudentDetailFormActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Camera")) {
                    userChoosenTask="Camera";
                    takeCameraImage_4();
                } else if (items[item].equals("Choose from Gallery")) {
                    userChoosenTask="Choose from Gallery";
                    takeGalleryImage_4();
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    public void takeCameraImage_4()
    {
        if (!checkIfAlreadyhavePermission()) {
            requestForSpecificPermission();
        } else {

            try {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(StudentDetailFormActivity.this, BuildConfig.APPLICATION_ID + ".fileprovider_mahajyoti", createImageFile()));
                startActivityForResult(intent, 7);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    public void takeGalleryImage_4()
    {
        Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 8);
    }





    public void saveDetails()
    {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(StudentDetailFormActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("DEVICE_ID",DeviceId);
            jsonParams.put("STUDENT_NAME",et_studentname.getText().toString());
            jsonParams.put("PARENTNAME",et_parentname.getText().toString());
            jsonParams.put("PARENTMOBILE",et_parentmob.getText().toString());
            jsonParams.put("STD",Clssname);
            jsonParams.put("STREAM",EntrancName);
            jsonParams.put("ADDRESS",et_address.getText().toString());
            jsonParams.put("BOOKDELIVERYADDRESS",et_bookaddress.getText().toString());
            jsonParams.put("CITY",et_city.getText().toString());
            jsonParams.put("MOBILE_NUMBER",et_mobileno.getText().toString());
            jsonParams.put("CONTACT_NO",et_contactno.getText().toString());
            jsonParams.put("COLLEGE_NAME",et_collegename.getText().toString());
            jsonParams.put("PINCODE",et_pincode.getText().toString());
            jsonParams.put("TAB_CONTACT_NUMBER",et_contactno.getText().toString());
            jsonParams.put("NETWORKPROVIDER",Provider);
            jsonParams.put("TENTH_CERTIFICATE",imgName_1);
            jsonParams.put("TWELVETH_CERTIFICATE","image2.jpg");
            jsonParams.put("NONCREMILIARCERTIFICATE",imgName_3);
            jsonParams.put("AADHARCARD",imgName_4);
            jsonParams.put("BONAFIED",imgName_2);
            jsonParams.put("PHOTO","image2.jpg");

            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(StudentDetailFormActivity.this,"",entity,"Data/SaveStudentDeviceRegistration", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());

                    progressDialog.dismiss();

                    if (String.valueOf(statusCode).equalsIgnoreCase("200"))
                    {
                        Intent intent = new Intent(StudentDetailFormActivity.this,StartActivity.class);
                        sessionManager.setStuDevicestatus("Registered");
                        sessionManager.setDeviceid(DeviceId);
                        startActivity(intent);
                    }
                    else {
                        progressDialog.dismiss();
                        Toast.makeText(StudentDetailFormActivity.this, "Somthing went wrong", Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(StudentDetailFormActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }



    public void sendOTP()
    {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(StudentDetailFormActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("PhoneNumber",et_mobileno.getText().toString());
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(StudentDetailFormActivity.this,"",entity,"Data/sendotp", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());

                    progressDialog.dismiss();

                    if (String.valueOf(statusCode).equalsIgnoreCase("200"))
                    {
                        Toast.makeText(StudentDetailFormActivity.this, "OTP Requested...", Toast.LENGTH_LONG).show();
                    }
                    else {
                        progressDialog.dismiss();
                        Toast.makeText(StudentDetailFormActivity.this, "Somthing went wrong", Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(StudentDetailFormActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }




    public void optVerify()
    {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(StudentDetailFormActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("PhoneNumber",et_mobileno.getText().toString().trim());
            jsonParams.put("Otp",et_otp.getText().toString().trim());
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(StudentDetailFormActivity.this,"",entity,"Data/verifyotp", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());

                    progressDialog.dismiss();

                    if (String.valueOf(statusCode).equalsIgnoreCase("200"))
                    {
                        Toast.makeText(StudentDetailFormActivity.this, "OTP verified", Toast.LENGTH_LONG).show();
                        crd_save.setEnabled(true);
                    }
                    else {
                        crd_save.setEnabled(false);
                        progressDialog.dismiss();
                        Toast.makeText(StudentDetailFormActivity.this, "Incorrect OTP", Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(StudentDetailFormActivity.this, "Incorrect OTP",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }







    public void saveImageService(String imgname,final String imageType , final String filename, final File filep)
    {
        mainpath ="StudentRegistration/"+filename;

        if(imgname.equalsIgnoreCase("1"))
        {
             imgName_1 = mainpath;
        }
        else if(imgname.equalsIgnoreCase("2"))
        {
            imgName_2 = mainpath;
        }
        else if(imgname.equalsIgnoreCase("3"))
        {
            imgName_3 = mainpath;
        }
        else if(imgname.equalsIgnoreCase("4"))
        {
            imgName_4 = mainpath;
        }

        Log.e("mainpath...","..."+mainpath);

        uploadAWSFile(filep,mainpath);

    }



    public void uploadAWSFile(final File myfile,String mainpath)
    {

        final ProgressDialog progressDialog = new ProgressDialog(StudentDetailFormActivity.this);
        progressDialog.setCancelable(false);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        File UPLOADING_IMAGE;
        String  ACCESS_KEY=getString(R.string.ACCESS_KEY),
                SECRET_KEY=getString(R.string.SECRET_KEY),
                MY_BUCKET=getString(R.string.MY_BUCKET),
                OBJECT_KEY=getString(R.string.OBJECT_KEY);
        AWSCredentials credentials = new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);
        AmazonS3 s3 = new AmazonS3Client(credentials);
        java.security.Security.setProperty("networkaddress.cache.ttl" , "60");
        //s3.setRegion(Region.getRegion(Regions.AP_SOUTHEAST_1));
        s3.setRegion(Region.getRegion(Regions.AP_SOUTH_1));
        //s3.setEndpoint("https://s3-ap-southeast-1.amazonaws.com/");
        s3.setEndpoint("https://s3.ap-south-1.amazonaws.com/");
        List<Bucket> buckets=s3.listBuckets();
        for(Bucket bucket:buckets){
            Log.e("Bucket ","Name "+bucket.getName()+" Owner "+bucket.getOwner()+ " Date " + bucket.getCreationDate());
        }
        Log.e("Size ", "" + s3.listBuckets().size());
        TransferUtility transferUtility = new TransferUtility(s3, getApplicationContext());
        // UPLOADING_IMAGE=new File(Environment.getExternalStorageDirectory().getPath()+"/Screenshot.png");
        UPLOADING_IMAGE=myfile;


        Log.e("Size ", "" + myfile.toString());
        //OBJECT_KEY = myfile.getName();
        OBJECT_KEY = mainpath;

        TransferObserver observer = transferUtility.upload(MY_BUCKET,OBJECT_KEY,UPLOADING_IMAGE);
        observer.setTransferListener(new TransferListener() {
            @Override
            public void onStateChanged(int id, TransferState state) {

                progressDialog.dismiss();
                // do something
                //progress.hide();
                // path.setText("ID "+id+"\nState "+state.name()+"\nImage ID "+OBJECT_KEY);
                Log.e("...","ID "+id+"\nState "+state.name()+"\nImage ID "+myfile.getName());
            }

            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                int percentage = (int) (bytesCurrent / bytesTotal * 100);
                //progress.setProgress(percentage);
                //Display percentage transfered to user
                if (!progressDialog.isShowing()) {
                    progressDialog.show();
                    //progressDialog.setProgress(percentage);
                    progressDialog.setMessage("Uploading...  "+String.valueOf(percentage)+"%");
                }
                Log.e("percentage....","...."+String.valueOf(percentage));
                if(percentage==100)
                {
                    Toast.makeText(StudentDetailFormActivity.this, "Uploaded Successfully",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(int id, Exception ex) {
                // do something
                Log.e("Error  ",""+ex );
            }

        });
    }


//    @Override
//    protected void onResume() {
//        super.onResume();
//        if (!headwindMDM.isConnected()) {
//            if (!headwindMDM.connect(this, this)) {
//                // Your application is running outside Headwind MDM
//            }
//        } else {
//            // Already connected, but settings may have changed
//            // when our app was in the background, so reload them
//            loadSettings();
//        }
//    }
//
//    @Override
//    protected void onDestroy() {
//        headwindMDM.disconnect(this);
//        super.onDestroy();
//    }
//
//    @Override
//    public void onHeadwindMDMConnected() {
//        loadSettings();
//    }
//
//    @Override
//    public void onHeadwindMDMDisconnected() {
//
//    }
//
//    @Override
//    public void onHeadwindMDMConfigChanged() {
//        loadSettings();
//    }
//
//    private void loadSettings() {
//
//        tabDevid = headwindMDM.getDeviceId();
//        Log.e("data..",".."+tabDevid);
//        deviceid_txt = findViewById(R.id.deviceid_txt);
//        deviceid_txt.setText(tabDevid);
//    }


    @Override
    public void onBackPressed() {

        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}