package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Adapter.StudentFeedbackVideoAdapter;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.HomeFragmentStuVideoDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class StudentFeedbackVideoActivity extends AppCompatActivity {

    private RecyclerView rv_list1;
    private ArrayList<HomeFragmentStuVideoDAO> studentDAOS;
    private StudentFeedbackVideoAdapter studentAdapter;
    HomeFragmentStuVideoDAO studentDAO;

    private int index1 = 0,end = 20;
    private int count1=1;

    Toolbar mToolbar;
    Bundle bundle;

    SessionManager sessionManager;
    String MobNo="",type="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_feedback_video);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        int red = Color.parseColor("#212121");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        sessionManager = new SessionManager(StudentFeedbackVideoActivity.this);
        if(sessionManager!=null)
        {
            String mob= sessionManager.getStuMobileno();

            if(mob!=null)
            {
                MobNo = mob;
            }
        }

        bundle = getIntent().getExtras();
        if(bundle!=null)
        {
            type = bundle.getString("type");
            if(type.equalsIgnoreCase("Feedback"))
            {
                getSupportActionBar().setTitle("Student Feedback Video");
            }
            else if(type.equalsIgnoreCase("Motivational"))
            {
                getSupportActionBar().setTitle("Motivational video by Teacher");
            }
            else
            {
                getSupportActionBar().setTitle("");
            }
        }

        init();
    }

    public void init()
    {
        rv_list1 = findViewById(R.id.rv_list1);
        studentDAOS = new ArrayList<>();
        studentAdapter = new StudentFeedbackVideoAdapter(rv_list1, studentDAOS,StudentFeedbackVideoActivity.this);

        rv_list1.setLayoutManager(new GridLayoutManager(StudentFeedbackVideoActivity.this,3));
        rv_list1.setItemAnimator(new DefaultItemAnimator());
        rv_list1.setNestedScrollingEnabled(false);

        //studentAdapter = new StudentFeedbackVideoAdapter(rv_list1, studentDAOS,StudentFeedbackVideoActivity.this);
        studentAdapter.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                studentDAOS.add(null);
                studentAdapter.notifyItemInserted(studentDAOS.size() - 1);
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        index1 = studentDAOS.size();
                        end = index1 + 20;
                        count1 = count1 + 1;
                        if (CheckConnection.haveNetworkConnection(StudentFeedbackVideoActivity.this))
                        {
                            getData(count1);
                        }
                        else {
                            Toast.makeText(StudentFeedbackVideoActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });

        if (CheckConnection.haveNetworkConnection(StudentFeedbackVideoActivity.this))
        {
            index1 = 0;
            count1=1;
            studentDAOS.clear();
            studentAdapter.notifyDataSetChanged();

            getData(count1);
        }
        else {
            Toast.makeText(StudentFeedbackVideoActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }
    }




    public void getData(int count) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(StudentFeedbackVideoActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("limit", 20);
            jsonParams.put("page_no", count);
            jsonParams.put("type", type);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(StudentFeedbackVideoActivity.this,"",entity,"Data/videomaster", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if (index1 != 0) {
                            studentDAOS.remove(studentDAOS.size() - 1);
                            studentAdapter.notifyItemRemoved(studentDAOS.size());
                        }

                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                studentDAO = new HomeFragmentStuVideoDAO();

                                if (String.valueOf(jsonObject.getString("id"))==null || String.valueOf(jsonObject.getString("id")).equalsIgnoreCase("null")||String.valueOf(jsonObject.getString("id")).equalsIgnoreCase(""))
                                {
                                    studentDAO.setId("");
                                }
                                else
                                {
                                    studentDAO.setId(String.valueOf(jsonObject.getString("id")));
                                }
                                if (jsonObject.getString("name")==null || jsonObject.getString("name").equalsIgnoreCase("null")||jsonObject.getString("name").equalsIgnoreCase(""))
                                {
                                    studentDAO.setName("");
                                }
                                else
                                {
                                    studentDAO.setName(jsonObject.getString("name"));
                                }
                                if (jsonObject.getString("description")==null || jsonObject.getString("description").equalsIgnoreCase("null")||jsonObject.getString("description").equalsIgnoreCase(""))
                                {
                                    studentDAO.setDescription("");
                                }
                                else
                                {
                                    studentDAO.setDescription(jsonObject.getString("description"));
                                }
                                if (jsonObject.getString("videolink")==null || jsonObject.getString("videolink").equalsIgnoreCase("null")||jsonObject.getString("videolink").equalsIgnoreCase(""))
                                {
                                    studentDAO.setVideolink("");
                                }
                                else
                                {
                                    studentDAO.setVideolink(jsonObject.getString("videolink"));
                                }
                                if (jsonObject.getString("type")==null || jsonObject.getString("type").equalsIgnoreCase("null")||jsonObject.getString("type").equalsIgnoreCase(""))
                                {
                                    studentDAO.setType("");
                                }
                                else
                                {
                                    studentDAO.setType(jsonObject.getString("type"));
                                }
                                if (jsonObject.getString("videoimage")==null || jsonObject.getString("videoimage").equalsIgnoreCase("null")||jsonObject.getString("videoimage").equalsIgnoreCase(""))
                                {
                                    studentDAO.setVideoimage("");
                                }
                                else
                                {
                                    studentDAO.setVideoimage(jsonObject.getString("videoimage"));
                                }

                                studentDAOS.add(studentDAO);

                            }


                            if (index1 == 0 && end == 20)
                            {
                                rv_list1.setAdapter(studentAdapter);
                            }else{
                                Log.e("index and end",index1+","+end);
                            }
                            studentAdapter.notifyDataSetChanged();
                            studentAdapter.setLoaded();

                        }
                        else {
                            studentAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            Toast.makeText(StudentFeedbackVideoActivity.this, "More Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(StudentFeedbackVideoActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onBackPressed() {

        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}