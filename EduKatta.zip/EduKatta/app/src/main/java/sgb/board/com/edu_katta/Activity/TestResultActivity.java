package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import ru.nikartm.support.ImageBadgeView;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class TestResultActivity extends AppCompatActivity {

    Toolbar mToolbar;

    private String selectedItem;
    ListView mDrawerList;
    RelativeLayout mDrawerPane;
    private DrawerLayout mDrawerLayout;

    ArrayList<NavItem> mNavItems = new ArrayList<NavItem>();

    ImageBadgeView notification_Iv;

    String MobNo="";
    SessionManager sessionManager;

    Spinner date_spinner;
    String Date="";

    List<String> dates;
    ArrayAdapter<String> monthAdapter;

    LinearLayout lay_toptenlist,lay_testpdflist;
    ImageView Iv_pic;
    TextView tv_name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_result);

        init();
    }


    public void init()
    {

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Test Result");
        int red = Color.parseColor("#212121");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        notification_Iv = (ImageBadgeView) findViewById(R.id.notification_Iv);
        date_spinner = (Spinner) findViewById(R.id.date_spinner);
        lay_toptenlist = (LinearLayout) findViewById(R.id.lay_toptenlist);
        lay_testpdflist = (LinearLayout) findViewById(R.id.lay_testpdflist);

        Iv_pic = (ImageView) findViewById(R.id.Iv_pic);
        tv_name = (TextView) findViewById(R.id.tv_name);
        sessionManager = new SessionManager(TestResultActivity.this);
        if(sessionManager!=null)
        {
            String mob= sessionManager.getStuMobileno();
            String stnm= sessionManager.getStuName();
            String stp= sessionManager.getStuStuphoto();

            if(mob!=null)
            {
                MobNo = mob;
            }
            if(stnm!=null)
            {
                tv_name.setText(stnm);
            }
            if(stp!=null)
            {
                Glide.with(TestResultActivity.this).load(stp).into(Iv_pic);
            }
        }


        notification_Iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TestResultActivity.this,NotificationActivity.class);
                startActivity(intent);
            }
        });

        if (CheckConnection.haveNetworkConnection(TestResultActivity.this))
        {
            getNotiCount();
        }
        else {
            Toast.makeText(TestResultActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }

        if (CheckConnection.haveNetworkConnection(TestResultActivity.this))
        {
            getDateData();
        }
        else {
            Toast.makeText(TestResultActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }



        dates = new ArrayList<String>();

        monthAdapter = new ArrayAdapter<String>(TestResultActivity.this, android.R.layout.simple_spinner_item, dates);
        // Drop down layout style - list view with radio button
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        date_spinner.setAdapter(monthAdapter);
        //inst_startmonth_spinner.setSelection(3);
        date_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                Log.v("item", (String) parent.getItemAtPosition(position));
                Date = (String) parent.getItemAtPosition(position);

                lay_toptenlist.removeAllViews();
                lay_testpdflist.removeAllViews();

                if (CheckConnection.haveNetworkConnection(TestResultActivity.this))
                {
                    getTopTenData(Date);
                }
                else {
                    Toast.makeText(TestResultActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                }

                if (CheckConnection.haveNetworkConnection(TestResultActivity.this))
                {
                    getTestPdfData(Date);
                }
                else {
                    Toast.makeText(TestResultActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });













        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        // Populate the Navigtion Drawer with options
        mDrawerPane = (RelativeLayout) findViewById(R.id.drawerPane);
        mDrawerList = (ListView) findViewById(R.id.navList);
        // Drawer Item click listeners
        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectItemFromDrawer(position);
            }
        });

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,mDrawerLayout,mToolbar,R.string.drawer_open,R.string.drawer_close){
            @Override
            public void onDrawerClosed(View v){
                super.onDrawerClosed(v);
            }

            @Override
            public void onDrawerOpened(View v) {
                super.onDrawerOpened(v);
            }
        };
        mDrawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();


        mNavItems.add(new NavItem(getResources().getString(R.string.home), getResources().getString(R.string.home_1),R.drawable.dashboard_icon2,"home"));

//        mNavItems.add(new NavItem(getResources().getString(R.string.myprofile), getResources().getString(R.string.myprofile_1),R.drawable.profile__icon5,"profile"));

        mNavItems.add(new NavItem(getResources().getString(R.string.mypayslip), getResources().getString(R.string.mypayslip_1),R.drawable.practicetest_icon,"practicetest"));


        mNavItems.add(new NavItem(getResources().getString(R.string.jeemocktest), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"jeemocktest"));

        mNavItems.add(new NavItem(getResources().getString(R.string.neetmocktest), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"neetmocktest"));


        mNavItems.add(new NavItem(getResources().getString(R.string.pfloanadvance), getResources().getString(R.string.pfloanadvance_1),R.drawable.testresult_icon,"testresult"));

        mNavItems.add(new NavItem(getResources().getString(R.string.specialempreq), getResources().getString(R.string.specialempreq_1),R.drawable.practicetest_icon,"test"));

        // mNavItems.add(new NavItem(getResources().getString(R.string.providentfund), getResources().getString(R.string.providentfund_1),R.drawable.feedback_img,"feedback"));

        mNavItems.add(new NavItem(getResources().getString(R.string.uniform), getResources().getString(R.string.uniform_1),R.drawable.dpp_answer_icon,"submitted_dpp_ans"));

        mNavItems.add(new NavItem(getResources().getString(R.string.form16req), getResources().getString(R.string.form16req_1),R.drawable.report_icon,"report"));

        // mNavItems.add(new NavItem(getResources().getString(R.string.logout), getResources().getString(R.string.form16req_1),R.drawable.logout,"logout"));


        DrawerListAdapter adapter = new DrawerListAdapter(TestResultActivity.this, mNavItems);
        mDrawerList.setAdapter(adapter);

    }

    private void selectItemFromDrawer(int position)
    {
        mDrawerList.setItemChecked(position, true);

        if(mNavItems.get(position).mAction_name.equalsIgnoreCase("home"))
        {
            Intent intent = new Intent(TestResultActivity.this, DashboardActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("practicetest"))
        {
            Intent intent = new Intent(TestResultActivity.this,RecordedSessionActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("jeemocktest"))
        {
            Intent intent = new Intent(TestResultActivity.this,JeeMockTestActivity.class);
            intent.putExtra("Type","JEE");
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("neetmocktest"))
        {
            Intent intent = new Intent(TestResultActivity.this,JeeMockTestActivity.class);
            intent.putExtra("Type","NEET");
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("testresult"))
        {
            Intent intent = new Intent(TestResultActivity.this,TestResultActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("test"))
        {
            Intent intent = new Intent(TestResultActivity.this,TestActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("feedback"))
        {
            Intent intent = new Intent(TestResultActivity.this,FeedbackActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("submitted_dpp_ans"))
        {
            Intent intent = new Intent(TestResultActivity.this,HelpDeskListActivity.class);
            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("report"))
        {
            Intent intent = new Intent(TestResultActivity.this,AskDoubtActivity.class);
            startActivity(intent);
//            Intent intent = new Intent(DashboardActivity.this,LibraryChapterWiseActivity.class);
//            startActivity(intent);
        }
        else if(mNavItems.get(position).mAction_name.equalsIgnoreCase("logout"))
        {
            // logoutpopup();
        }
        // Close the drawer
        mDrawerLayout.closeDrawer(mDrawerPane);
    }

    class NavItem {
        String mTitle;
        String mSubtitle,mAction_name;
        int mIcon;

        public NavItem(String title, String subtitle, int icon ,String action_name) {
            mTitle = title;
            mSubtitle = subtitle;
            mIcon = icon;
            mAction_name = action_name;
        }
    }

    class DrawerListAdapter extends BaseAdapter {

        Context mContext;
        ArrayList<NavItem> mNavItems;

        public DrawerListAdapter(Context context, ArrayList<NavItem> navItems) {
            mContext = context;
            mNavItems = navItems;
        }

        @Override
        public int getCount() {
            return mNavItems.size();
        }

        @Override
        public Object getItem(int position) {
            return mNavItems.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view;

            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.drawer_item, null);
            }
            else {
                view = convertView;
            }

            TextView titleView = (TextView) view.findViewById(R.id.title);
//            TextView subtitleView = (TextView) view.findViewById(R.id.subTitle);
            TextView actionname = (TextView) view.findViewById(R.id.actionname);
            ImageView iconView = (ImageView) view.findViewById(R.id.icon);

            titleView.setText( mNavItems.get(position).mTitle );
//            subtitleView.setText( mNavItems.get(position).mSubtitle );
            actionname.setText( mNavItems.get(position).mAction_name );

            Glide.with(TestResultActivity.this).load(mNavItems.get(position).mIcon).into(iconView);


            return view;
        }
    }


    public void getNotiCount() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(TestResultActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", MobNo);
            jsonParams.put("limit", 20);
            jsonParams.put("page_no", 1);
            jsonParams.put("count", true);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(TestResultActivity.this,"",entity,"Data/notificationlistmaster", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, String response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

//                    try
//                    {
//                        if(response.length()>0)
//                        {
//                            progressDialog.dismiss();
//
//                            if(response.length()>0)
//                            {
//                                String st="";
//                                for(int i=0 ; i<response.length(); i++)
//                                {
//                                    JSONObject jsonObject = response.getJSONObject(i);
//
//                                    if (jsonObject.getString("message")==null || jsonObject.getString("message").equalsIgnoreCase("null")||jsonObject.getString("message").equalsIgnoreCase(""))
//                                    {
////                                        noticeDAO.setName("");
//                                    }
//                                    else
//                                    {
//                                        st = st.concat(jsonObject.getString("message"));
//                                        st = st.concat("    |    ");
//                                    }
//                                }
//
//                                txt_noticemarquee.setText(st);
//                            }
//
//                        }
//                        else {
//                            progressDialog.dismiss();
//                            // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
//                        }
//
//                    }
//                    catch (Exception e)
//                    {
//                        e.printStackTrace();
//                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString() +"..."+String.valueOf(statusCode));
                    if(statusCode==200)
                    {
                        notification_Iv.setBadgeValue(Integer.parseInt(responseString));
                    }
                    else
                    {
                        Toast.makeText(TestResultActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                    }
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }




    public void getDateData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(TestResultActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("YEAR", 2021);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(TestResultActivity.this,"",entity,"Data/TestDateList", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());
                    progressDialog.dismiss();
                    try
                    {
                        if(response.length()>0)
                        {
                            for(int i=0 ; i<response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                if (jsonObject.getString("d")==null || jsonObject.getString("d").equalsIgnoreCase("null")||jsonObject.getString("d").equalsIgnoreCase(""))
                                {
                                }
                                else
                                {
                                }

                                if (jsonObject.getString("r")==null || jsonObject.getString("r").equalsIgnoreCase("null")||jsonObject.getString("r").equalsIgnoreCase(""))
                                {
                                }
                                else
                                {
                                     dates.add(jsonObject.getString("r"));
                                }
                            }

                        }
                        else {
                            progressDialog.dismiss();
                            // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                        monthAdapter.notifyDataSetChanged();

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString() +"..."+String.valueOf(statusCode));
                    Toast.makeText(TestResultActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }




    public void getTopTenData(String dt) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(TestResultActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("TEST_DATE", dt);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(TestResultActivity.this,"",entity,"Data/TopTenTestResultListAllSubject", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());
                    progressDialog.dismiss();
                    try
                    {
                        Iterator iterator = response.keys();
                        while (iterator.hasNext()) {
                            String key = (String)iterator.next();

                            lay_toptenlist = (LinearLayout) findViewById(R.id.lay_toptenlist);
                            final LinearLayout newView = (LinearLayout)getLayoutInflater().inflate(R.layout.topten_student_result_cardview_2, null);
                            newView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                            TextView txt_heading = (TextView) newView.findViewById(R.id.txt_heading);
                            LinearLayout lay_studentlist = (LinearLayout) newView.findViewById(R.id.lay_studentlist);

                            txt_heading.setText("Top 10 "+key+" Students");


                            JSONArray jsonArray = response.getJSONArray(key);
                            if(jsonArray.length()>0)
                            {
                                for(int i=0 ; i<jsonArray.length(); i++)
                                {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                                    lay_studentlist = (LinearLayout) newView.findViewById(R.id.lay_studentlist);
                                    final LinearLayout newView2 = (LinearLayout)getLayoutInflater().inflate(R.layout.topten_student_result_cardview, null);
                                    newView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                                    TextView txt_studentname = (TextView) newView2.findViewById(R.id.txt_studentname);
                                    TextView txt_score = (TextView) newView2.findViewById(R.id.txt_score);

                                    if (jsonObject.getString("studenT_NAME")==null || jsonObject.getString("studenT_NAME").equalsIgnoreCase("null")||jsonObject.getString("studenT_NAME").equalsIgnoreCase(""))
                                    {
                                        txt_studentname.setText("");
                                    }
                                    else
                                    {
                                        txt_studentname.setText(jsonObject.getString("studenT_NAME"));
                                    }

                                    if (jsonObject.getString("totaL_SCORE")==null || jsonObject.getString("totaL_SCORE").equalsIgnoreCase("null")||jsonObject.getString("totaL_SCORE").equalsIgnoreCase(""))
                                    {
                                        txt_score.setText("");
                                    }
                                    else
                                    {
                                        txt_score.setText(jsonObject.getString("totaL_SCORE"));
                                    }

                                    lay_studentlist.addView(newView2);
                                }

                                lay_studentlist = (LinearLayout) newView.findViewById(R.id.lay_studentlist);

                            }
                            else {
                                progressDialog.dismiss();
                                // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                            }

                            lay_toptenlist.addView(newView);
                        }

                        lay_toptenlist = (LinearLayout)findViewById(R.id.lay_toptenlist);

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString() +"..."+String.valueOf(statusCode));

                    Toast.makeText(TestResultActivity.this, "Error occured",Toast.LENGTH_LONG).show();

                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }





    public void getTestPdfData(String dt) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(TestResultActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            //jsonParams.put("TEST_DATE", dt);
            jsonParams.put("TEST_DATE", "04-Dec-21");
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(TestResultActivity.this,"",entity,"Data/subjecttestdetails", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());
                    progressDialog.dismiss();
                    try
                    {
                        if(response.length()>0)
                        {

                            JSONObject jsonObject = response.getJSONObject(0);

                            Iterator iterator = jsonObject.keys();
                            while (iterator.hasNext())
                            {
                                String key = (String) iterator.next();

                                lay_testpdflist = (LinearLayout) findViewById(R.id.lay_testpdflist);
                                final LinearLayout newView = (LinearLayout)getLayoutInflater().inflate(R.layout.test_ques_ans_cardview, null);
                                newView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                                TextView txt_subjectname = (TextView) newView.findViewById(R.id.txt_subjectname);
                                TextView txt_pdf = (TextView) newView.findViewById(R.id.txt_pdf);
                                LinearLayout lay_view = (LinearLayout) newView.findViewById(R.id.lay_view);
                                LinearLayout lay_download = (LinearLayout) newView.findViewById(R.id.lay_download);

                                txt_subjectname.setText(key);
                                String jv = jsonObject.getString(key);
                                //Log.e("data..",".."+key+"...."+jv);
                                if (jv==null || jv.equalsIgnoreCase("null")||jv.equalsIgnoreCase(""))
                                {
                                    txt_pdf.setText("");
                                }
                                else
                                {
                                    txt_pdf.setText(jv);
                                }


                                lay_view.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {

                                        if(txt_pdf.getText().toString().trim().equalsIgnoreCase(""))
                                        {
                                            Toast.makeText(TestResultActivity.this, "PDF not available", Toast.LENGTH_SHORT).show();
                                        }
                                        else
                                        {
                                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(txt_pdf.getText().toString().trim()));
                                            startActivity(browserIntent);
                                        }
                                    }
                                });

                                lay_download.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {

//                                        if(txt_pdf.getText().toString().trim().equalsIgnoreCase(""))
//                                        {
//                                            Toast.makeText(TestResultActivity.this, "PDF not available", Toast.LENGTH_SHORT).show();
//                                        }
//                                        else
//                                        {
//                                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(txt_pdf.getText().toString().trim()));
//                                            startActivity(browserIntent);
//                                        }
                                    }
                                });



                                lay_testpdflist.addView(newView);
                            }

                            lay_testpdflist = (LinearLayout) findViewById(R.id.lay_testpdflist);
                        }
                        else {
                            progressDialog.dismiss();
                            // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString() +"..."+String.valueOf(statusCode));

                    Toast.makeText(TestResultActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }
}