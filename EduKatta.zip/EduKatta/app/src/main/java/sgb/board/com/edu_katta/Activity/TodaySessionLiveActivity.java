package sgb.board.com.edu_katta.Activity;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;
import sgb.board.com.edu_katta.demo.VideoEnabledWebChromeClient;
import sgb.board.com.edu_katta.demo.VideoEnabledWebView;

public class TodaySessionLiveActivity extends AppCompatActivity {

    private VideoEnabledWebView webView,webview_chat;
    private VideoEnabledWebChromeClient webChromeClient,webChromeClient2;

    Bundle bundle;
    String url="",chat="",Tsch_DE_ID="";

    SessionManager sessionManager;
    String MobileNo="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_today_session_live);

        bundle = getIntent().getExtras();
        if(bundle!=null)
        {
            url = bundle.getString("url");
            chat = bundle.getString("chat");
            Tsch_DE_ID = bundle.getString("tsch_de_id");
            Log.e("Data...",".."+chat.toString());
        }

        sessionManager=new SessionManager(TodaySessionLiveActivity.this);
        if(sessionManager!=null)
        {
            String mob = sessionManager.getStuMobileno();
            if(mob!=null)
            {
                MobileNo = mob;
            }
        }

        // Save the web view
        webView = (VideoEnabledWebView)findViewById(R.id.webView);

        webview_chat = (VideoEnabledWebView)findViewById(R.id.webview_chat);

        // Initialize the VideoEnabledWebChromeClient and set event handlers
        View nonVideoLayout = findViewById(R.id.nonVideoLayout); // Your own view, read class comments
        ViewGroup videoLayout = (ViewGroup)findViewById(R.id.videoLayout); // Your own view, read class comments
        //noinspection all
        View loadingView = getLayoutInflater().inflate(R.layout.view_loading_video, null);
        // Your own view, read class comments

        webChromeClient = new VideoEnabledWebChromeClient(nonVideoLayout, videoLayout, loadingView, webView) // See all available constructors...
        {
            // Subscribe to standard events, such as onProgressChanged()...
            @Override
            public void onProgressChanged(WebView view, int progress)
            {
                // Your code...
            }
        };
        webChromeClient.setOnToggledFullscreen(new VideoEnabledWebChromeClient.ToggledFullscreenCallback()
        {
            @Override
            public void toggledFullscreen(boolean fullscreen)
            {
                // Your code to handle the full-screen change, for example showing and hiding the title bar. Example:
                if (fullscreen)
                {
                    WindowManager.LayoutParams attrs = getWindow().getAttributes();
                    attrs.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
                    attrs.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    getWindow().setAttributes(attrs);
                    if (android.os.Build.VERSION.SDK_INT >= 14)
                    {
                        //noinspection all
                        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE);
                    }
                }
                else
                {
                    WindowManager.LayoutParams attrs = getWindow().getAttributes();
                    attrs.flags &= ~WindowManager.LayoutParams.FLAG_FULLSCREEN;
                    attrs.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    getWindow().setAttributes(attrs);
                    if (android.os.Build.VERSION.SDK_INT >= 14)
                    {
                        //noinspection all
                        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                    }
                }

            }
        });
        webView.setWebChromeClient(webChromeClient);
        // Call private class InsideWebViewClient
        webView.setWebViewClient(new InsideWebViewClient());

        // Navigate anywhere you want, but consider that this classes have only been tested on YouTube's mobile site
       // webView.loadUrl("http://m.youtube.com");
        webView.loadUrl(url);








        webChromeClient2 = new VideoEnabledWebChromeClient(nonVideoLayout, videoLayout, loadingView, webview_chat) // See all available constructors...
        {
            // Subscribe to standard events, such as onProgressChanged()...
            @Override
            public void onProgressChanged(WebView view, int progress)
            {
                // Your code...
            }
        };
        webChromeClient2.setOnToggledFullscreen(new VideoEnabledWebChromeClient.ToggledFullscreenCallback()
        {
            @Override
            public void toggledFullscreen(boolean fullscreen)
            {
                // Your code to handle the full-screen change, for example showing and hiding the title bar. Example:
                if (fullscreen)
                {
                    WindowManager.LayoutParams attrs = getWindow().getAttributes();
                    attrs.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
                    attrs.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    getWindow().setAttributes(attrs);
                    if (android.os.Build.VERSION.SDK_INT >= 14)
                    {
                        //noinspection all
                        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE);
                    }
                }
                else
                {
                    WindowManager.LayoutParams attrs = getWindow().getAttributes();
                    attrs.flags &= ~WindowManager.LayoutParams.FLAG_FULLSCREEN;
                    attrs.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    getWindow().setAttributes(attrs);
                    if (android.os.Build.VERSION.SDK_INT >= 14)
                    {
                        //noinspection all
                        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                    }
                }

            }
        });
        webview_chat.setWebChromeClient(webChromeClient2);
        // Call private class InsideWebViewClient
        webview_chat.setWebViewClient(new InsideWebViewClient());

        // Navigate anywhere you want, but consider that this classes have only been tested on YouTube's mobile site
        // webView.loadUrl("http://m.youtube.com");
        webview_chat.loadUrl(chat);



        if (CheckConnection.haveNetworkConnection(TodaySessionLiveActivity.this))
        {
            getAttendSession();
        }
        else {
            Toast.makeText(TodaySessionLiveActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
        }

    }

    private class InsideWebViewClient extends WebViewClient {
        @Override
        // Force links to be opened inside WebView and not in Default Browser
        // Thanks http://stackoverflow.com/a/33681975/1815624
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    @Override
    public void onBackPressed()
    {
        // Notify the VideoEnabledWebChromeClient, and handle it ourselves if it doesn't handle it
        if (!webChromeClient.onBackPressed())
        {
            if (webView.canGoBack())
            {
                webView.goBack();
            }
            else
            {
                // Standard back button implementation (for example this could close the app)
                super.onBackPressed();
            }
        }

        if (!webChromeClient2.onBackPressed())
        {
            if (webview_chat.canGoBack())
            {
                webview_chat.goBack();
            }
            else
            {
                // Standard back button implementation (for example this could close the app)
                super.onBackPressed();
            }
        }
    }



    public void getAttendSession() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(TodaySessionLiveActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", MobileNo);
            jsonParams.put("TSCH_DE_ID", Integer.parseInt(Tsch_DE_ID));
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(TodaySessionLiveActivity.this,"",entity,"Data/AttendLecture", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());
                    progressDialog.dismiss();
                    if (String.valueOf(statusCode).equalsIgnoreCase("200"))
                    {
                        Toast.makeText(TodaySessionLiveActivity.this, "Attendance Done",Toast.LENGTH_LONG).show();
                    }
                    else {
                        progressDialog.dismiss();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(TodaySessionLiveActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }


}