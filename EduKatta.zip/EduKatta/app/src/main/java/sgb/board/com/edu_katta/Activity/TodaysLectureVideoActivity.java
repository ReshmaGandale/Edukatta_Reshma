package sgb.board.com.edu_katta.Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import sgb.board.com.edu_katta.R;

public class TodaysLectureVideoActivity extends AppCompatActivity {

    WebView webview_chat;
    Bundle bundle;
    String url="",chat="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todays_lecture_video);

//        Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
//        dialog.setContentView(R.layout.dialog_help);
        webview_chat = (WebView) findViewById(R.id.webview_chat);
        bundle = getIntent().getExtras();
        if(bundle!=null)
        {
            url = bundle.getString("url");
            chat = bundle.getString("chat");
            Log.e("Data...",".."+chat.toString());
        }

        WebView webView = findViewById(R.id.webview_help_video);

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
        });

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.loadUrl(url);



        webview_chat.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
        });

        WebSettings webSettings2 = webview_chat.getSettings();
        webSettings2.setJavaScriptEnabled(true);
        webview_chat.loadUrl(chat);

//        dialog.setCanceledOnTouchOutside(true);
//        dialog.show();

    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }

}