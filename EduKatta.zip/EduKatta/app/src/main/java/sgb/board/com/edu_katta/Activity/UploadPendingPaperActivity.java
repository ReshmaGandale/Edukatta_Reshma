package sgb.board.com.edu_katta.Activity;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.BuildConfig;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Custom.FilePath;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;

public class UploadPendingPaperActivity extends AppCompatActivity {

    private Bitmap bitmap = null;
    private String userChoosenTask="";
    String currentImagePath;

    Uri filePathuri;
    String imageType="",mainpath="";
    String imgName_1="";

    String MobNo="",Student_Id="";
    SessionManager sessionManager;

    String Stu_Id="",tsch_de_id="";
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_pending_paper);

        bundle = getIntent().getExtras();
        if(bundle!=null)
        {
            Stu_Id = bundle.getString("stuid");
            tsch_de_id = bundle.getString("tsch_de_id");
        }

        sessionManager = new SessionManager(UploadPendingPaperActivity.this);
        if(sessionManager!=null)
        {
            String mob= sessionManager.getStuMobileno();
            String stid = sessionManager.getStudentId();
            if(mob!=null)
            {
                MobNo = mob;
            }
            if(stid!=null)
            {
                Student_Id = stid;
            }
        }

        setProfilePic();
    }


    public void setProfilePic()
    {
        final CharSequence[] items = { "Camera", "Choose from Gallery", "Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(UploadPendingPaperActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Camera")) {
                    userChoosenTask="Camera";
                    takeCameraImage();
                } else if (items[item].equals("Choose from Gallery")) {
                    userChoosenTask="Choose from Gallery";
                    takeGalleryImage();
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    public void takeCameraImage()
    {
        if (!checkIfAlreadyhavePermission()) {
            requestForSpecificPermission();
        } else {

            try {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(UploadPendingPaperActivity.this, BuildConfig.APPLICATION_ID + ".fileprovider_mahajyoti", createImageFile()));
                startActivityForResult(intent, 1);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    public void takeGalleryImage()
    {
        Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 2);
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (resultCode) {

            case Activity.RESULT_OK: {

                switch (requestCode) {
                    case 1: {

                        try {

                            Bitmap bm = BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(currentImagePath)));

                            ExifInterface ei = new ExifInterface(getContentResolver().openInputStream(Uri.parse(currentImagePath)));
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bm, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bm, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bm, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bm;
                            }

                            //  picIv.setImageBitmap(rotatedBitmap);

                            String img = getStringImage(rotatedBitmap);

                            if (CheckConnection.haveNetworkConnection(UploadPendingPaperActivity.this)) {

                                Uri file = Uri.fromFile(new File(currentImagePath));
                                filePathuri = Uri.fromFile(new File(currentImagePath));

                                Uri filePath = Uri.parse(currentImagePath);
                                String path = FilePath.getPath(this, filePath);

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());
                                //Log.e("path",".."+fileExt);

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                Log.e("name..", ".." + currentImagePath);


                                saveImageService(imageType, Student_Id +"_"+ ts + "." + imageType, new File(path));


                            }
                            else {
                                Toast.makeText(UploadPendingPaperActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }catch (IOException e)
                        {
                            e.printStackTrace();
                        }

                    }

                    break;

                    case 2: {

                        try {

                            Uri selectedImage = data.getData();
                            String[] filePath = {MediaStore.Images.Media.DATA};
                            Cursor c = getContentResolver().query(selectedImage, filePath, null, null, null);
                            c.moveToFirst();
                            int columnIndex = c.getColumnIndex(filePath[0]);
                            String picturePath = c.getString(columnIndex);
                            c.close();
                            bitmap = (BitmapFactory.decodeFile(picturePath));


                            ExifInterface ei = new ExifInterface(picturePath);
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bitmap, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bitmap, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bitmap, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bitmap;
                            }


                            //  picIv.setImageBitmap(rotatedBitmap);

                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                            byte[] imageBytes = baos.toByteArray();
                            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);

                            if (CheckConnection.haveNetworkConnection(UploadPendingPaperActivity.this)) {

                                Uri file = Uri.fromFile(new File(picturePath));

                                imageType = MimeTypeMap.getFileExtensionFromUrl(file.toString());

                                Long tsLong = System.currentTimeMillis() / 1000;
                                String ts = tsLong.toString();

                                saveImageService(imageType,Student_Id +"_"+ts+"."+imageType,new File(picturePath));


                            } else {
                                Toast.makeText(UploadPendingPaperActivity.this, "Network is not available", Toast.LENGTH_LONG).show();
                            }
                        }
                        catch (IOException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    break;

                }
            }
        }

    }

    public static Bitmap rotateImage(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(),
                matrix, true);
    }

    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        Log.e("hiiiii",encodedImage);
        return encodedImage;
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Camera");
        File image = File.createTempFile(imageFileName,".jpg",storageDir);
        // Save a file: path for using again
        currentImagePath = "file://" + image.getAbsolutePath();
        return image;
    }

    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
    }

    private boolean checkIfAlreadyhavePermission() {
        int fine = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int read = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int write = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (fine == PackageManager.PERMISSION_GRANTED) {
            Log.e("permission1", "fine");
            return true;
        }
        if (read == PackageManager.PERMISSION_GRANTED) {
            Log.e("permission2", "coarse");
            return true;
        }
        if (write == PackageManager.PERMISSION_GRANTED) {
            Log.e("permission2", "coarse");
            return true;
        } else {
            return false;
        }
    }



    public void saveImageService(final String imageType , final String filename, final File filep)
    {
        mainpath ="pt_assign/"+filename;

        imgName_1 = mainpath;

        Log.e("mainpath...","..."+mainpath);

        uploadAWSFile(filep,mainpath);

    }


    public void uploadAWSFile(final File myfile,String mainpath)
    {

        final ProgressDialog progressDialog = new ProgressDialog(UploadPendingPaperActivity.this);
        progressDialog.setCancelable(false);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        File UPLOADING_IMAGE;
        String  ACCESS_KEY=getString(R.string.ACCESS_KEY),
                SECRET_KEY=getString(R.string.SECRET_KEY),
                MY_BUCKET=getString(R.string.MY_BUCKET),
                OBJECT_KEY=getString(R.string.OBJECT_KEY);
        AWSCredentials credentials = new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);
        AmazonS3 s3 = new AmazonS3Client(credentials);
        java.security.Security.setProperty("networkaddress.cache.ttl" , "60");
        //s3.setRegion(Region.getRegion(Regions.AP_SOUTHEAST_1));
        s3.setRegion(Region.getRegion(Regions.AP_SOUTH_1));
        //s3.setEndpoint("https://s3-ap-southeast-1.amazonaws.com/");
        s3.setEndpoint("https://s3.ap-south-1.amazonaws.com/");
        List<Bucket> buckets=s3.listBuckets();
        for(Bucket bucket:buckets){
            Log.e("Bucket ","Name "+bucket.getName()+" Owner "+bucket.getOwner()+ " Date " + bucket.getCreationDate());
        }
        Log.e("Size ", "" + s3.listBuckets().size());
        TransferUtility transferUtility = new TransferUtility(s3, getApplicationContext());
        // UPLOADING_IMAGE=new File(Environment.getExternalStorageDirectory().getPath()+"/Screenshot.png");
        UPLOADING_IMAGE=myfile;


        Log.e("Size ", "" + myfile.toString());
        //OBJECT_KEY = myfile.getName();
        OBJECT_KEY = mainpath;

        TransferObserver observer = transferUtility.upload(MY_BUCKET,OBJECT_KEY,UPLOADING_IMAGE);
        observer.setTransferListener(new TransferListener() {
            @Override
            public void onStateChanged(int id, TransferState state) {

                progressDialog.dismiss();
                // do something
                //progress.hide();
                // path.setText("ID "+id+"\nState "+state.name()+"\nImage ID "+OBJECT_KEY);
                Log.e("...","ID "+id+"\nState "+state.name()+"\nImage ID "+myfile.getName());
            }

            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                int percentage = (int) (bytesCurrent / bytesTotal * 100);
                //progress.setProgress(percentage);
                //Display percentage transfered to user
                if (!progressDialog.isShowing()) {
                    progressDialog.show();
                    //progressDialog.setProgress(percentage);
                    progressDialog.setMessage("Uploading...  "+String.valueOf(percentage)+"%");
                }
                Log.e("percentage....","...."+String.valueOf(percentage));
                if(percentage==100)
                {
                    Toast.makeText(UploadPendingPaperActivity.this, "Uploaded Successfully",Toast.LENGTH_SHORT).show();
                    saveDetails();
                }
            }

            @Override
            public void onError(int id, Exception ex) {
                // do something
                Log.e("Error  ",""+ex );
            }

        });
    }





    public void saveDetails()
    {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(UploadPendingPaperActivity.this);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();

            jsonParams.put("tsch_de_id",tsch_de_id);
            jsonParams.put("STUDENT_ID",Stu_Id);
            jsonParams.put("SUBMIT_ANSWER",imgName_1);

            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(UploadPendingPaperActivity.this,"",entity,"Data/uploaddppanswer", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());

                    progressDialog.dismiss();

                    if (String.valueOf(statusCode).equalsIgnoreCase("200"))
                    {
                        Toast.makeText(UploadPendingPaperActivity.this, "Submitted Successfully", Toast.LENGTH_LONG).show();
                        finish();
                    }
                    else {
                        progressDialog.dismiss();
                        Toast.makeText(UploadPendingPaperActivity.this, "Somthing went wrong", Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(UploadPendingPaperActivity.this, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }










    @Override
    public void onBackPressed() {

        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}