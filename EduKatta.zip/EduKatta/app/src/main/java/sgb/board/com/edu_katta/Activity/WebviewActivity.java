package sgb.board.com.edu_katta.Activity;

import android.Manifest;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.File;

import sgb.board.com.edu_katta.R;

import static android.os.Environment.DIRECTORY_DOCUMENTS;

public class WebviewActivity extends AppCompatActivity implements View.OnClickListener{

    String pdf;
    Toolbar mToolbar;
    private ImageView downloadIv;
    String Name = "",Actname="";

    private long downloadId;

    ProgressBar progressBar_cyclic;

    private static final String TAG = "Download Task";

    WebView webview;
    ProgressDialog progressDialog;

    File apkStorage = null;
    File outputFile = null;

    int count=0;
    LinearLayout lay_wait;

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        context = getApplicationContext();

        registerReceiver(onDownloadComplete,new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);


    lay_wait = (LinearLayout) findViewById(R.id.lay_wait);
        lay_wait.setVisibility(View.VISIBLE);

        downloadIv = (ImageView) findViewById(R.id.downloadIv);
        downloadIv.setOnClickListener(this);

        init();

    }

//    @Override
//    public boolean onSupportNavigateUp() {
//
//        progressDialog.dismiss();
//        onBackPressed();
//        return true;
//    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
    }
    @Override
    public boolean onSupportNavigateUp() {
        //progressDialog.dismiss();
        onBackPressed();
        return false;
    }



    private void init()
    {
        Log.e("Count....","..."+String.valueOf(count));



        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading Data...");
        progressDialog.setCancelable(false);

        webview = (WebView) findViewById(R.id.web_view);
//        webview.requestFocus();
//        WebSettings settings = webview.getSettings();
//        settings.setJavaScriptEnabled(true);
        Intent intent = getIntent();

        pdf = intent.getStringExtra("url");
        Name = intent.getStringExtra("name");
        Actname = intent.getStringExtra("Activity");
        Log.e("pdf..",".."+pdf);
        Log.e("Act..",".."+Actname);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle(Actname);
        int red = Color.parseColor("#FFFFFF");
        mToolbar.setTitleTextColor(red);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        webview.clearCache(true);
        webview.clearHistory();
        webview.getSettings().setJavaScriptEnabled(true);
        webview.setHorizontalScrollBarEnabled(false);
        webview.getSettings().setPluginState(WebSettings.PluginState.ON);


        initWebView();
        //webview.loadUrl("https://drive.google.com/viewerng/viewer?embedded=true&url="+pdf);
        webview.loadUrl("https://docs.google.com/viewer?url="+pdf);
        //webview.loadUrl("https://docs.google.com/viewer?embedded=true&url="+pdf);

    }


    private void initWebView() {


//        webview.setWebViewClient(new WebViewClient() {
//            @Override
//            public boolean shouldOverrideUrlLoading(final WebView view, final String url) {
//
//                if (view.getTitle().equals(""))
//                {
//                    view.reload();
//                }
//                else
//                {
//                    view.loadUrl(url);
//                }
//
//                return true;
//            }
//
//        });

        webview.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(final WebView view, final int progress) {

                Log.e("prog...",".."+String.valueOf(progress));

                if (progress < 100) {
                    progressDialog.show();
                }
                else
                {

                    if(count==0)
                    {
                        Log.e("Data...1","....");
                        lay_wait.setVisibility(View.VISIBLE);
                        progressDialog.dismiss();
                        count =1;
                        init();
                    }
                    else
                    {
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {

                                if (progress == 100) {

                                    Log.e("Data...2","....");
                                    lay_wait.setVisibility(View.GONE);
                                    progressDialog.dismiss();
                                }
                            }
                        }, 5000);

                    }

                }

            }

        });


    }


    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id)
        {
//            case R.id.shareIv:
//                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
//                sharingIntent.setType("text/plain");
//                String shareBody = pdf;
//                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Policy PDF");
//                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
//                startActivity(Intent.createChooser(sharingIntent, "Share via"));
//                break;

            case R.id.downloadIv:
                String URL= pdf;
                //new DownloadTask(WebviewActivity.this, URL,Name);
                beginDownload(URL,Name);

                break;
        }
    }


    private void beginDownload(String file_link, String name){
        //File file=new File(getExternalFilesDir(null),name);

        //File file=new File(Environment.getExternalStorageDirectory() + "/" + "MahaSGB FILES/"+name);

        File file = new File(Environment.getExternalStoragePublicDirectory(DIRECTORY_DOCUMENTS).getPath()+File.separator+"MahaSGB FILES/"+name);

        apkStorage = new File(Environment.getExternalStoragePublicDirectory(DIRECTORY_DOCUMENTS).getPath()
                + "/MahaSGB FILES");

        if (!apkStorage.exists()) {
            apkStorage.mkdir();
            Toast.makeText(getApplicationContext(), "File is in Documents Folder", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(), "File is in Documents Folder", Toast.LENGTH_LONG).show();
        }


//        try {
//
//            if (new CheckForSDCard().isSDCardPresent()) {
//
//                //apkStorage = new File(Environment.getExternalStorageDirectory() + "/" + "MahaSGB FILES");
//                apkStorage = new File(Environment.getExternalStorageDirectory() +File.separator+"MahaSGB FILES");
//
//            } else
//                Toast.makeText(WebviewActivity.this, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
//
//            //If File is not present create directory
//            if (!apkStorage.exists())
//            {
//                //apkStorage.mkdir();
//                apkStorage.mkdirs();
//                Log.e(TAG, "Directory Created.");
//            }
//
//           // outputFile = new File(apkStorage, name);//Create Output file in Main File
//
//            //Create New File if not present
////            if (!outputFile.exists()) {
////                outputFile.createNewFile();
////                Log.e(TAG, "File Created");
////            }
//
//        } catch (Exception e) {
//
//            //Read exception if something went wrong
//            e.printStackTrace();
//            outputFile = null;
//            Log.e(TAG, "Download Error Exception " + e.getMessage());
//        }

        //checking if android version is equal and greater than noughat

        //now if download complete file not visible now lets show it
        DownloadManager.Request request=null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            request=new DownloadManager.Request(Uri.parse(file_link))
                    .setTitle(name)
                    .setDescription("Downloading")
                    .setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationUri(Uri.fromFile(file))
                    .setRequiresCharging(false)
                    .setAllowedOverMetered(true)
                    .setAllowedOverRoaming(true);
        }
        else{
            request=new DownloadManager.Request(Uri.parse(file_link))
                    .setTitle(name)
                    .setDescription("Downloading")
                    .setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationUri(Uri.fromFile(file))
                    .setAllowedOverRoaming(true);
        }

        DownloadManager downloadManager=(DownloadManager)getSystemService(DOWNLOAD_SERVICE);
        downloadId=downloadManager.enqueue(request);


    }

    private BroadcastReceiver onDownloadComplete=new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            long id=intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID,-1);
            if(downloadId==id){
                Toast.makeText(WebviewActivity.this, "Download Completed", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(onDownloadComplete);
    }

}