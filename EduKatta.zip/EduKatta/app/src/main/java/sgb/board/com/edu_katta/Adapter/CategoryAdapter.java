package sgb.board.com.edu_katta.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.CategoryDAO;
import sgb.board.com.edu_katta.R;

public class CategoryAdapter extends BaseAdapter {

    private Context context;
    LayoutInflater inflater;
    private CategoryDAO sessionDAO;
    private ArrayList<CategoryDAO> sessionDAOS;

    public CategoryAdapter(Activity context, ArrayList<CategoryDAO> sessionDAOS)
    {
        this.context = context;
        this.sessionDAOS = sessionDAOS;
        inflater = LayoutInflater.from(this.context);
    }



    @Override
    public int getCount() {
        //Log.e("jay count", String.valueOf(sessionDAOS.size()));
        return sessionDAOS.size();
    }


    @Override
    public Object getItem(int position) {
        return sessionDAOS.get(position);
    }

    @Override
    public long getItemId(int position) {
        return sessionDAOS.indexOf(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder=null;
        if (convertView==null)
        {
            convertView = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.leave_spinner, null);
            viewHolder = new ViewHolder();
            viewHolder.profile_text = (TextView) convertView.findViewById(R.id.class_text);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        try{
            sessionDAO = sessionDAOS.get(position);
            viewHolder.profile_text.setText(sessionDAO.getName());
        }catch (Exception e){
        }
        return convertView;
    }

    private static class ViewHolder {
        private TextView profile_text,id_text;
    }
}
