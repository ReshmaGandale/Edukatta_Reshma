package sgb.board.com.edu_katta.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import sgb.board.com.edu_katta.R;

public class DashBoardWeeklyTestAdapter extends RecyclerView.Adapter<DashBoardWeeklyTestAdapter.MyHolderView> {
    List<String>weeklyTest;

    public DashBoardWeeklyTestAdapter(List<String> weeklyTest) {
        this.weeklyTest = weeklyTest;
    }

    @NonNull
    @androidx.annotation.NonNull
    @Override
    public DashBoardWeeklyTestAdapter.MyHolderView onCreateViewHolder(@NonNull @androidx.annotation.NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.dashboard_test_layout,viewGroup,false);
        return new MyHolderView(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @androidx.annotation.NonNull DashBoardWeeklyTestAdapter.MyHolderView myHolderView, int position) {
        myHolderView.testTitle.setText(weeklyTest.get(position)+"");

    }

    @Override
    public int getItemCount() {
        return weeklyTest.size();
    }

    public class MyHolderView extends RecyclerView.ViewHolder {
        TextView testTitle;
        public MyHolderView(@NonNull @androidx.annotation.NonNull View itemView) {
            super(itemView);
            testTitle=itemView.findViewById(R.id.testTitle);
        }
    }
}
