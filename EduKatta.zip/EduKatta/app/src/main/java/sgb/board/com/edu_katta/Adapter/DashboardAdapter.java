package sgb.board.com.edu_katta.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ru.nikartm.support.ImageBadgeView;
import sgb.board.com.edu_katta.Dao.DashboardDAO;
import sgb.board.com.edu_katta.R;

public class DashboardAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<DashboardDAO> homeGridDAOS;
    private DashboardDAO homeGridDAO;
    LayoutInflater inflater;

    public DashboardAdapter(Context context, ArrayList<DashboardDAO> homeGridDAOS)
    {
        this.context = context;
        this.homeGridDAOS = homeGridDAOS;
        inflater = LayoutInflater.from(this.context);
    }
    @Override
    public int getCount() {
        return homeGridDAOS.size();
    }

    @Override
    public Object getItem(int position) {
        return homeGridDAOS.get(position);
    }

    @Override
    public long getItemId(int position) {
        return homeGridDAOS.indexOf(getItem(position));
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        DashboardAdapter.ViewHolder viewHolder = null;
        if (view == null)
        {
            view = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.home_grid_custom, null);

            viewHolder = new DashboardAdapter.ViewHolder();
            viewHolder.imageView = (ImageBadgeView) view.findViewById(R.id.gridview_image);
            viewHolder.engNameTv = (TextView) view.findViewById(R.id.gridview_text);

            view.setTag(viewHolder);
        }
        else
            {
            viewHolder = (DashboardAdapter.ViewHolder) view.getTag();
        }
        try{

            homeGridDAO = homeGridDAOS.get(position);
            viewHolder.imageView.setImageResource(Integer.parseInt(homeGridDAOS.get(position).getImage()));
            viewHolder.engNameTv.setText(homeGridDAOS.get(position).getEngName());


            viewHolder.imageView.setBadgeValue(Integer.parseInt(homeGridDAOS.get(position).getCount()));

        }
        catch (Exception e){
        }
        return view;
    }

    private static class ViewHolder {
        private TextView engNameTv;
        private ImageBadgeView imageView;
    }
}
