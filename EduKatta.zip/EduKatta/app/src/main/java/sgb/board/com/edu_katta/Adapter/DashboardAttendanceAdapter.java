package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.LectureAttendanceDAO;
import sgb.board.com.edu_katta.R;

public class DashboardAttendanceAdapter extends RecyclerView.Adapter<DashboardAttendanceAdapter.MyViewHolder> {
private Context context;
private ArrayList<LectureAttendanceDAO> todaysDAOS;

public class MyViewHolder extends RecyclerView.ViewHolder {
    public TextView txt_subject,txt_attendance;


    public MyViewHolder(View view) {
        super(view);

        txt_subject = view.findViewById(R.id.txt_subject);
        txt_attendance = view.findViewById(R.id.txt_attendance);

    }
}


    public DashboardAttendanceAdapter(Context context, ArrayList<LectureAttendanceDAO> addressListDAOS) {
        this.context = context;
        this.todaysDAOS = addressListDAOS;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.dashboard_attendance_cardview, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final LectureAttendanceDAO current = todaysDAOS.get(position);

        holder.txt_subject.setText(current.getSubject()+" : ");

        if(current.getType().equalsIgnoreCase("att"))
        {
            holder.txt_attendance.setText(current.getAttendance()+"/"+current.getTotal_lectures());
        }
        else
        {
            holder.txt_attendance.setText(current.getSubmitted_assignments()+"/"+current.getAssignments());
        }
    }

    @Override
    public int getItemCount() {
        return todaysDAOS.size();
    }
}
