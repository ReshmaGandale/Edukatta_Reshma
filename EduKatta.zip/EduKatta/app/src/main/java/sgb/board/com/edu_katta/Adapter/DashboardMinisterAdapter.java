package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.HomeFragmentDAO;
import sgb.board.com.edu_katta.R;

public class DashboardMinisterAdapter extends RecyclerView.Adapter<DashboardMinisterAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<HomeFragmentDAO> todaysDAOS;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txt_ministername,txt_post,txt_desc;
        public ImageView img_minister;

        public MyViewHolder(View view) {
            super(view);

            txt_ministername = view.findViewById(R.id.txt_ministername);
            txt_post = view.findViewById(R.id.txt_post);
            txt_desc = view.findViewById(R.id.txt_desc);
            img_minister = view.findViewById(R.id.img_minister);
        }
    }


    public DashboardMinisterAdapter(Context context, ArrayList<HomeFragmentDAO> addressListDAOS) {
        this.context = context;
        this.todaysDAOS = addressListDAOS;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.minister_list_cardview, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final HomeFragmentDAO current = todaysDAOS.get(position);

        holder.txt_ministername.setText(current.getName());
        holder.txt_post.setText(current.getPost());
        holder.txt_desc.setText(current.getDescription());

        if(current.getPhoto().equalsIgnoreCase(""))
        {
            Glide.with(context).load(R.drawable.demo_image).into(holder.img_minister);
        }
        else
        {
            Glide.with(context).load(current.getPhoto()).into(holder.img_minister);
        }

    }

    @Override
    public int getItemCount() {
        return todaysDAOS.size();
    }
}
