package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.HomeFragmentNoticeDAO;
import sgb.board.com.edu_katta.R;

public class DashboardNoticeAdapter extends RecyclerView.Adapter<DashboardNoticeAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<HomeFragmentNoticeDAO> todaysDAOS;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txt_desc,txt_title;


        public MyViewHolder(View view) {
            super(view);

            txt_desc = view.findViewById(R.id.txt_desc);
            txt_title = view.findViewById(R.id.txt_title);

        }
    }


    public DashboardNoticeAdapter(Context context, ArrayList<HomeFragmentNoticeDAO> addressListDAOS) {
        this.context = context;
        this.todaysDAOS = addressListDAOS;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.notice_list_cardview, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final HomeFragmentNoticeDAO current = todaysDAOS.get(position);

        //holder.txt_desc.setText(current.getDescription());
        holder.txt_title.setText(current.getName());

    }

    @Override
    public int getItemCount() {
        return todaysDAOS.size();
    }
}
