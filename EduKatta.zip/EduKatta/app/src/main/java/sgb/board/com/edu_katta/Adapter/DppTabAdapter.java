package sgb.board.com.edu_katta.Adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import sgb.board.com.edu_katta.Fragment.PendingPaperFragment;
import sgb.board.com.edu_katta.Fragment.SubmittedPaperFragment;

public class DppTabAdapter  extends FragmentStatePagerAdapter {

    int mNumOfTabs;

    public DppTabAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                PendingPaperFragment tab0 = new PendingPaperFragment();
                return tab0;
            case 1:
                SubmittedPaperFragment tab1 = new SubmittedPaperFragment();
                return tab1;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
