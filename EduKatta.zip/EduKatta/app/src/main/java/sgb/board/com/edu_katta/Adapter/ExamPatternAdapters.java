package sgb.board.com.edu_katta.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Utils.RecycleViewClickListner;

public class ExamPatternAdapters extends RecyclerView.Adapter<ExamPatternAdapters.MyViewHolder> {
    Context context;
    List<String> examPattern;
    RecycleViewClickListner recycleViewClickListner;

    public ExamPatternAdapters(Context context, List<String> examPattern, RecycleViewClickListner recycleViewClickListner) {
        this.context = context;
        this.examPattern = examPattern;
        this.recycleViewClickListner = recycleViewClickListner;
    }

    @NonNull
    @androidx.annotation.NonNull
    @Override
    public ExamPatternAdapters.MyViewHolder onCreateViewHolder(@NonNull @androidx.annotation.NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.dashboard_test_layout,viewGroup,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @androidx.annotation.NonNull ExamPatternAdapters.MyViewHolder myViewHolder, int position) {
        myViewHolder.testTitle.setText(examPattern.get(position));
        myViewHolder.testTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recycleViewClickListner.onClick(view,position);
                notifyDataSetChanged();
            }
        });


    }

    @Override
    public int getItemCount() {
        return examPattern.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView testTitle;
        public MyViewHolder(@NonNull @androidx.annotation.NonNull View itemView) {
            super(itemView);
            testTitle=itemView.findViewById(R.id.testTitle);
        }
    }
}
