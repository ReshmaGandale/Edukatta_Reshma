package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


import sgb.board.com.edu_katta.Dao.HelpDeskListDAO;
import sgb.board.com.edu_katta.R;

public class HelpDeskListAdapter extends RecyclerView.Adapter<HelpDeskListAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<HelpDeskListDAO> todaysDAOS;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txt_catname,txt_subcatname,txt_desc;
        public ImageView img_minister;

        public MyViewHolder(View view) {
            super(view);

            txt_catname = view.findViewById(R.id.txt_catname);
            txt_subcatname = view.findViewById(R.id.txt_subcatname);
            txt_desc = view.findViewById(R.id.txt_desc);
//            img_minister = view.findViewById(R.id.img_minister);
        }
    }


    public HelpDeskListAdapter(Context context, ArrayList<HelpDeskListDAO> addressListDAOS) {
        this.context = context;
        this.todaysDAOS = addressListDAOS;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.helpdesk_list_cardview, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final HelpDeskListDAO current = todaysDAOS.get(position);

        holder.txt_catname.setText(current.getQuerY_TYPE_NAME());
        holder.txt_subcatname.setText(current.getSubquerY_TYPE_NAME());
        holder.txt_desc.setText(current.getQuery());
//
//        if(current.getPhoto().equalsIgnoreCase(""))
//        {
//            Glide.with(context).load(R.drawable.demo_image).into(holder.img_minister);
//        }
//        else
//        {
//            Glide.with(context).load(current.getPhoto()).into(holder.img_minister);
//        }

    }

    @Override
    public int getItemCount() {
        return todaysDAOS.size();
    }
}
