package sgb.board.com.edu_katta.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import sgb.board.com.edu_katta.Models.HomePageContentModels;
import sgb.board.com.edu_katta.R;

public class HomeContentAdapters extends RecyclerView.Adapter<HomeContentAdapters.MyViewolder> {
    List<HomePageContentModels.DataEntity> contentData;


    public HomeContentAdapters(List<HomePageContentModels.DataEntity> contentData) {
        this.contentData = contentData;
    }

    @Override
    public MyViewolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.content_items, viewGroup, false);
        return new MyViewolder(view);
    }

    @Override
    public void onBindViewHolder( MyViewolder holder, int i) {
        holder.title.setText(contentData.get(i).getTitle());
        holder.description.setText(contentData.get(i).getDescription());

    }

    @Override
    public int getItemCount() {
        return contentData.size();
    }



    public class MyViewolder extends RecyclerView.ViewHolder {
        private TextView title;
        private TextView description;
        public MyViewolder(View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.title);
            description = (TextView) itemView.findViewById(R.id.description);
        }
    }
}
