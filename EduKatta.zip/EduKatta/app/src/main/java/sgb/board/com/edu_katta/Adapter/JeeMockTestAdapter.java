package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.JeeMockTestDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;

public class JeeMockTestAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    private ArrayList<JeeMockTestDAO> rDmemberDAOS;
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLoading;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;

    public JeeMockTestAdapter(RecyclerView recyclerView, ArrayList<JeeMockTestDAO> rDmemberDAOS, Context context)
    {
        this.context = context;
        this.rDmemberDAOS = rDmemberDAOS;
        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    if (onLoadMoreListener != null) {
                        onLoadMoreListener.onLoadMore();
                    }
                    isLoading = true;
                }
            }
        });
    }

    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener) {
        this.onLoadMoreListener = mOnLoadMoreListener;
    }

    @Override
    public int getItemViewType(int position) {
        return rDmemberDAOS.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(context).inflate(R.layout.jee_mock_test_cardview, parent, false);
            return new JeeMockTestAdapter.UserViewHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_loading, parent, false);
            return new JeeMockTestAdapter.LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof JeeMockTestAdapter.UserViewHolder) {

            JeeMockTestDAO current = rDmemberDAOS.get(position);
            JeeMockTestAdapter.UserViewHolder userViewHolder = (JeeMockTestAdapter.UserViewHolder) holder;

            userViewHolder.txt_topic.setText(rDmemberDAOS.get(position).getTesT_TOPIC());
            userViewHolder.txt_date.setText(rDmemberDAOS.get(position).getTest_DATE());


            userViewHolder.crd_download_question.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(rDmemberDAOS.get(position).getQuestions().equalsIgnoreCase(""))
                    {

                    }
                    else
                    {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(rDmemberDAOS.get(position).getQuestions()));
                        context.startActivity(browserIntent);
                    }


                }
            });


            userViewHolder.crd_download_ans.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(rDmemberDAOS.get(position).getAnswers().equalsIgnoreCase(""))
                    {

                    }
                    else
                    {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(rDmemberDAOS.get(position).getAnswers()));
                        context.startActivity(browserIntent);
                    }

                }
            });


            userViewHolder.crd_submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(rDmemberDAOS.get(position).getSubmit().equalsIgnoreCase(""))
                    {
                        userViewHolder.txt_submitted.setText("Submit Answer");
                    }
                    else
                    {
                        userViewHolder.txt_submitted.setText("Submitted Answer");
                    }
                }
            });


//            userViewHolder.crd_assin_todo.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    Log.e("Heelo...","..");
//                    if(rDmemberDAOS.get(position).getUploadeD_ASSIGNMENT().equalsIgnoreCase(""))
//                    {
//                        Toast.makeText(context, "Data not available", Toast.LENGTH_SHORT).show();
//                    }
//                    else
//                    {
//                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(rDmemberDAOS.get(position).getUploadeD_ASSIGNMENT()));
//                        context.startActivity(browserIntent);
//                    }
//
//                }
//            });
//
//            userViewHolder.crd_ans_bylecturer.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    Log.e("Heelo2...","..");
//                    if(rDmemberDAOS.get(position).getUploadeD_ANSWER().equalsIgnoreCase(""))
//                    {
//                        Toast.makeText(context, "Data not available", Toast.LENGTH_SHORT).show();
//                    }
//                    else {
//                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(rDmemberDAOS.get(position).getUploadeD_ANSWER()));
//                        context.startActivity(browserIntent);
//                    }
//                }
//            });
//
//            try {
//                JSONArray subjsonArray = new JSONArray(rDmemberDAOS.get(position).getSubmitteD_ANSWER());
//                JSONArray viewjsonArray = new JSONArray(rDmemberDAOS.get(position).getVieW_ANSWER());
//
//
//                if(subjsonArray.length()==0)
//                {
//                    userViewHolder.txt_submitted.setText("Submitted");
//                }
//                else if(subjsonArray.length()==0 && rDmemberDAOS.get(position).getUploadeD_ANSWER().equalsIgnoreCase(""))
//                {
//                    userViewHolder.txt_submitted.setText("Locked");
//                }
//                else if(subjsonArray.length()==0 && !rDmemberDAOS.get(position).getUploadeD_ANSWER().equalsIgnoreCase(""))
//                {
//                    userViewHolder.txt_submitted.setText("Upload");
//                }
//
//                userViewHolder.crd_ans_bystudent.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//
//                        if(userViewHolder.txt_submitted.getText().toString().equalsIgnoreCase("Upload"))
//                        {
//                        }
//                        else
//                        {
//                        }
//                    }
//                });
//
//                userViewHolder.crd_view_ans_student.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//
//                        if(viewjsonArray.length()==0)
//                        {
//                            Toast.makeText(context, "Data not available", Toast.LENGTH_SHORT).show();
//                        }
//                        else {
//                            Intent browserIntent = null;
//                            try {
//                                browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(viewjsonArray.getString(0)));
//                                context.startActivity(browserIntent);
//                            } catch (JSONException e) {
//                                e.printStackTrace();
//                            }
//                        }
//                    }
//                });
//
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }


        } else if (holder instanceof JeeMockTestAdapter.LoadingViewHolder) {
            JeeMockTestAdapter.LoadingViewHolder loadingViewHolder = (JeeMockTestAdapter.LoadingViewHolder) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }

    }


    @Override
    public int getItemCount() {
        return rDmemberDAOS == null ? 0 : rDmemberDAOS.size();
    }
    public void setLoaded() {
        isLoading = false;
    }



    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public LoadingViewHolder(View view) {
            super(view);
            progressBar = view.findViewById(R.id.progressBar1);
        }
    }


    private class UserViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_topic,txt_date,txt_submitted;
        public LinearLayout lay_main;
        public CardView crd_submit,crd_download_ans,crd_download_question;

        public UserViewHolder(View itemView) {
            super(itemView);

            txt_topic = itemView.findViewById(R.id.txt_topic);
            lay_main = itemView.findViewById(R.id.lay_main);
            txt_submitted = itemView.findViewById(R.id.txt_submitted);
            txt_date = itemView.findViewById(R.id.txt_date);
            crd_submit = itemView.findViewById(R.id.crd_submit);
            crd_download_ans = itemView.findViewById(R.id.crd_download_ans);
            crd_download_question = itemView.findViewById(R.id.crd_download_question);


        }
    }
}
