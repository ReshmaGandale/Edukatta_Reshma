package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.LibraryChapterWiseDAO;
import sgb.board.com.edu_katta.Dao.LibraryVideoListDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;

public class LibraryChapterWiseAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    private ArrayList<LibraryChapterWiseDAO> rDmemberDAOS;
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLoading;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;

    public LibraryChapterWiseAdapter(RecyclerView recyclerView, ArrayList<LibraryChapterWiseDAO> rDmemberDAOS, Context context)
    {
        this.context = context;
        this.rDmemberDAOS = rDmemberDAOS;
        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    if (onLoadMoreListener != null) {
                        onLoadMoreListener.onLoadMore();
                    }
                    isLoading = true;
                }
            }
        });
    }

    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener) {
        this.onLoadMoreListener = mOnLoadMoreListener;
    }

    @Override
    public int getItemViewType(int position) {
        return rDmemberDAOS.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(context).inflate(R.layout.library_chapterwise_cardview, parent, false);
            return new LibraryChapterWiseAdapter.UserViewHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_loading, parent, false);
            return new LibraryChapterWiseAdapter.LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof LibraryChapterWiseAdapter.UserViewHolder) {
            final LibraryChapterWiseDAO current = rDmemberDAOS.get(position);
            final LibraryChapterWiseAdapter.UserViewHolder userViewHolder = (LibraryChapterWiseAdapter.UserViewHolder) holder;

            userViewHolder.tx_chapter.setText(current.getChapter());
            userViewHolder.txt_video_count.setText(current.getVideo_count());


            userViewHolder.rDmemberAccDAOs.clear();
            try {
                JSONArray jsonArray = new JSONArray(rDmemberDAOS.get(position).getVideoList());

                if (jsonArray.length() > 0) {

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        userViewHolder.rDmemberAccDAO = new LibraryVideoListDAO();
                        userViewHolder.rDmemberAccDAO.setImg(jsonObject.getString("img"));
                        userViewHolder.rDmemberAccDAO.setLisT_TITLE(jsonObject.getString("lisT_TITLE"));
                        userViewHolder.rDmemberAccDAO.setDiscuessioN_ON_TOPIC(jsonObject.getString("discuessioN_ON_TOPIC"));
                        userViewHolder.rDmemberAccDAOs.add(userViewHolder.rDmemberAccDAO);
                    }

                    userViewHolder.rDmemberAccAdapter = new LibraryVideoListAdapter(context, userViewHolder.rDmemberAccDAOs);
                    userViewHolder.rv_child.setAdapter(userViewHolder.rDmemberAccAdapter);
                    userViewHolder.rDmemberAccAdapter.notifyDataSetChanged();
                }
                else {
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }







        } else if (holder instanceof LibraryChapterWiseAdapter.LoadingViewHolder) {
            LibraryChapterWiseAdapter.LoadingViewHolder loadingViewHolder = (LibraryChapterWiseAdapter.LoadingViewHolder) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }
    }

    @Override
    public int getItemCount() {
        return rDmemberDAOS == null ? 0 : rDmemberDAOS.size();
    }
    public void setLoaded() {
        isLoading = false;
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public LoadingViewHolder(View view) {
            super(view);
            progressBar = view.findViewById(R.id.progressBar1);
        }
    }


    private class UserViewHolder extends RecyclerView.ViewHolder {

        public TextView tx_chapter,txt_video_count;
        public RecyclerView rv_child;
        ArrayList<LibraryVideoListDAO> rDmemberAccDAOs;
        LibraryVideoListDAO rDmemberAccDAO;
        LibraryVideoListAdapter rDmemberAccAdapter;

        public UserViewHolder(View itemView) {
            super(itemView);

            tx_chapter = itemView.findViewById(R.id.tx_chapter);
            txt_video_count = itemView.findViewById(R.id.txt_video_count);
            rv_child = itemView.findViewById(R.id.rv_child);

            rDmemberAccDAOs = new ArrayList<>();
            final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
            rv_child.setLayoutManager(linearLayoutManager);
            rv_child.setItemAnimator(new DefaultItemAnimator());
            rv_child.setNestedScrollingEnabled(false);
        }
    }

}
