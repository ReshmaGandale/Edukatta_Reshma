package sgb.board.com.edu_katta.Adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import sgb.board.com.edu_katta.Fragment.RecordedMaterialFragment;
import sgb.board.com.edu_katta.Fragment.StudyMaterialFragment;

public class LibraryTabAdapter extends FragmentStatePagerAdapter {

    int mNumOfTabs;

    public LibraryTabAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                StudyMaterialFragment tab0 = new StudyMaterialFragment();
                return tab0;
            case 1:
                RecordedMaterialFragment tab1 = new RecordedMaterialFragment();
                return tab1;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
