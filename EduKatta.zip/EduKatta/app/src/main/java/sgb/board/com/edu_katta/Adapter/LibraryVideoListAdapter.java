package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Activity.RecordedMaterialVideoActivity;
import sgb.board.com.edu_katta.Dao.LibraryVideoListDAO;
import sgb.board.com.edu_katta.R;

public class LibraryVideoListAdapter  extends RecyclerView.Adapter<LibraryVideoListAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<LibraryVideoListDAO> todaysDAOS;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView img_video;
        public LinearLayout lay_main;
        public TextView txt_title;

        public MyViewHolder(View view) {
            super(view);

            txt_title = view.findViewById(R.id.txt_title);
            img_video = view.findViewById(R.id.img_video);
            lay_main = view.findViewById(R.id.lay_main);
        }
    }


    public LibraryVideoListAdapter(Context context, ArrayList<LibraryVideoListDAO> addressListDAOS) {
        this.context = context;
        this.todaysDAOS = addressListDAOS;
    }

    @Override
    public LibraryVideoListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.library_video_list_cardview, parent, false);

        return new LibraryVideoListAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(LibraryVideoListAdapter.MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final LibraryVideoListDAO current = todaysDAOS.get(position);

        holder.txt_title.setText(todaysDAOS.get(position).getDiscuessioN_ON_TOPIC());

        if(todaysDAOS.get(position).getImg().equalsIgnoreCase(""))
        {
            Glide.with(context).load(R.drawable.upcome_img_1).into(holder.img_video);
        }
        else
        {
            Glide.with(context).load(todaysDAOS.get(position).getImg()).into(holder.img_video);
        }

        holder.lay_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, RecordedMaterialVideoActivity.class);
                intent.putExtra("title",todaysDAOS.get(position).getDiscuessioN_ON_TOPIC());
                intent.putExtra("url",todaysDAOS.get(position).getLisT_TITLE());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return todaysDAOS.size();
    }
}
