package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.NoticeListDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;

public class NoticeListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    private ArrayList<NoticeListDAO> rDmemberDAOS;
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLoading;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;

    public NoticeListAdapter(RecyclerView recyclerView, ArrayList<NoticeListDAO> rDmemberDAOS, Context context)
    {
        this.context = context;
        this.rDmemberDAOS = rDmemberDAOS;
        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    if (onLoadMoreListener != null) {
                        onLoadMoreListener.onLoadMore();
                    }
                    isLoading = true;
                }
            }
        });
    }

    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener) {
        this.onLoadMoreListener = mOnLoadMoreListener;
    }

    @Override
    public int getItemViewType(int position) {
        return rDmemberDAOS.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(context).inflate(R.layout.notice_list2_cardview, parent, false);
            return new NoticeListAdapter.UserViewHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_loading, parent, false);
            return new NoticeListAdapter.LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof NoticeListAdapter.UserViewHolder) {
            final NoticeListDAO current = rDmemberDAOS.get(position);
            final NoticeListAdapter.UserViewHolder userViewHolder = (NoticeListAdapter.UserViewHolder) holder;

            userViewHolder.txt_msg.setText(current.getMessage());
            userViewHolder.txt_date.setText(current.getNoticE_DATE());
//            userViewHolder.tx_time.setText(current.getFrom_time()+"-"+current.getTo_time());

        }
        else if (holder instanceof NoticeListAdapter.LoadingViewHolder) {
            NoticeListAdapter.LoadingViewHolder loadingViewHolder = (NoticeListAdapter.LoadingViewHolder) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }

    }


    @Override
    public int getItemCount() {
        return rDmemberDAOS == null ? 0 : rDmemberDAOS.size();
    }
    public void setLoaded() {
        isLoading = false;
    }



    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public LoadingViewHolder(View view) {
            super(view);
            progressBar = view.findViewById(R.id.progressBar1);
        }
    }


    private class UserViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_date,txt_msg;
        public CardView card_attend;

        public UserViewHolder(View itemView) {
            super(itemView);

            txt_date = itemView.findViewById(R.id.txt_date);
            txt_msg = itemView.findViewById(R.id.txt_msg);

        }
    }

}
