package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.NotificationDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;

public class NotificationAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    private ArrayList<NotificationDAO> notificationDAOS;
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLoading;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;

    public NotificationAdapter(RecyclerView recyclerView,ArrayList<NotificationDAO> notificationDAOS,Context context)
    {
        this.context = context;
        this.notificationDAOS = notificationDAOS;
        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    if (onLoadMoreListener != null) {
                        onLoadMoreListener.onLoadMore();
                    }
                    isLoading = true;
                }
            }
        });
    }

    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener) {
        this.onLoadMoreListener = mOnLoadMoreListener;
    }

    @Override
    public int getItemViewType(int position) {
        return notificationDAOS.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(context).inflate(R.layout.notification_list_cardview, parent, false);
            return new NotificationAdapter.UserViewHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_loading, parent, false);
            return new NotificationAdapter.LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof NotificationAdapter.UserViewHolder) {
            final NotificationDAO notificationDAO = notificationDAOS.get(position);
            final NotificationAdapter.UserViewHolder userViewHolder = (NotificationAdapter.UserViewHolder) holder;

            userViewHolder.tv_message.setText(notificationDAO.getMessage());
            userViewHolder.tv_msgdate.setText(notificationDAO.getSend_date());

        } else if (holder instanceof NotificationAdapter.LoadingViewHolder) {
            NotificationAdapter.LoadingViewHolder loadingViewHolder = (NotificationAdapter.LoadingViewHolder) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }
    }

    @Override
    public int getItemCount() {
        return notificationDAOS == null ? 0 : notificationDAOS.size();
    }
    public void setLoaded() {
        isLoading = false;
    }


    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public LoadingViewHolder(View view) {
            super(view);
            progressBar = view.findViewById(R.id.progressBar1);
        }
    }


    private class UserViewHolder extends RecyclerView.ViewHolder {
        TextView tv_message,tv_msgdate;

        public UserViewHolder(View itemView) {
            super(itemView);
            tv_message= itemView.findViewById(R.id.tv_message);
            tv_msgdate= itemView.findViewById(R.id.tv_msgdate);

        }
    }
}
