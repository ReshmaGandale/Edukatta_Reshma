package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Activity.UploadPendingPaperActivity;
import sgb.board.com.edu_katta.Dao.PendingPaperListDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;

public class PendingPaperListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    private ArrayList<PendingPaperListDAO> rDmemberDAOS;
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLoading;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;

    public PendingPaperListAdapter(RecyclerView recyclerView, ArrayList<PendingPaperListDAO> rDmemberDAOS, Context context)
    {
        this.context = context;
        this.rDmemberDAOS = rDmemberDAOS;
        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    if (onLoadMoreListener != null) {
                        onLoadMoreListener.onLoadMore();
                    }
                    isLoading = true;
                }
            }
        });
    }

    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener) {
        this.onLoadMoreListener = mOnLoadMoreListener;
    }

    @Override
    public int getItemViewType(int position) {
        return rDmemberDAOS.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(context).inflate(R.layout.pending_paper_cardview, parent, false);
            return new PendingPaperListAdapter.UserViewHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_loading, parent, false);
            return new PendingPaperListAdapter.LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof PendingPaperListAdapter.UserViewHolder) {

            PendingPaperListDAO current = rDmemberDAOS.get(position);
            PendingPaperListAdapter.UserViewHolder userViewHolder = (PendingPaperListAdapter.UserViewHolder) holder;

            userViewHolder.txt_topic.setText(rDmemberDAOS.get(position).getTopic());
            userViewHolder.txt_teachername.setText(rDmemberDAOS.get(position).getTeacheR_NAME());


            Log.e("sub...",".."+rDmemberDAOS.get(position).getSubmitteD_ANSWER());


            userViewHolder.crd_assin_todo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.e("Heelo...","..");
                    if(rDmemberDAOS.get(position).getUploadeD_ASSIGNMENT().equalsIgnoreCase(""))
                    {
                        Toast.makeText(context, "Data not available", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(rDmemberDAOS.get(position).getUploadeD_ASSIGNMENT()));
                        context.startActivity(browserIntent);
                    }

                }
            });

            userViewHolder.crd_ans_bylecturer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.e("Heelo2...","..");
                    if(rDmemberDAOS.get(position).getUploadeD_ANSWER().equalsIgnoreCase(""))
                    {
                        Toast.makeText(context, "Data not available", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(rDmemberDAOS.get(position).getUploadeD_ANSWER()));
                        context.startActivity(browserIntent);
                    }
                }
            });

            try {
                JSONArray subjsonArray = new JSONArray(rDmemberDAOS.get(position).getSubmitteD_ANSWER());
                JSONArray viewjsonArray = new JSONArray(rDmemberDAOS.get(position).getVieW_ANSWER());


                if(subjsonArray.length()==0)
                {
                    userViewHolder.txt_submitted.setText("Submitted");
                    Glide.with(context).load(R.drawable.lock_icon).into(userViewHolder.crd_ans_bystudent);
                    userViewHolder.crd_ans_bystudent.setColorFilter(context.getResources().getColor(R.color.liner));
                }
                else if(subjsonArray.length()==0 && rDmemberDAOS.get(position).getUploadeD_ANSWER().equalsIgnoreCase(""))
                {
                    userViewHolder.txt_submitted.setText("Locked");
                    Glide.with(context).load(R.drawable.lock_icon).into(userViewHolder.crd_ans_bystudent);
                    userViewHolder.crd_ans_bystudent.setColorFilter(context.getResources().getColor(R.color.liner));
                }
                else if(subjsonArray.length()==0 && !rDmemberDAOS.get(position).getUploadeD_ANSWER().equalsIgnoreCase(""))
                {
                    userViewHolder.txt_submitted.setText("Upload");
                    Glide.with(context).load(R.drawable.upload).into(userViewHolder.crd_ans_bystudent);
                    userViewHolder.crd_ans_bystudent.setColorFilter(context.getResources().getColor(R.color.liner));
                }

                userViewHolder.crd_ans_bystudent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if(userViewHolder.txt_submitted.getText().toString().equalsIgnoreCase("Upload"))
                        {
                             Intent intent = new Intent(context, UploadPendingPaperActivity.class);
                             intent.putExtra("stuid",  rDmemberDAOS.get(position).getStudenT_ID());
                             intent.putExtra("tsch_de_id", rDmemberDAOS.get(position).getStoreD_LINK());
                             context.startActivity(intent);
                        }
                        else
                        {
                        }
                    }
                });

                userViewHolder.crd_view_ans_student.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if(viewjsonArray.length()==0)
                        {
                            Toast.makeText(context, "Data not available", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            Intent browserIntent = null;
                            try {
                                browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(viewjsonArray.getString(0)));
                                context.startActivity(browserIntent);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });

                } catch (JSONException e) {
                    e.printStackTrace();
                }


        } else if (holder instanceof PendingPaperListAdapter.LoadingViewHolder) {
            PendingPaperListAdapter.LoadingViewHolder loadingViewHolder = (PendingPaperListAdapter.LoadingViewHolder) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }

    }


    @Override
    public int getItemCount() {
        return rDmemberDAOS == null ? 0 : rDmemberDAOS.size();
    }
    public void setLoaded() {
        isLoading = false;
    }



    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public LoadingViewHolder(View view) {
            super(view);
            progressBar = view.findViewById(R.id.progressBar1);
        }
    }


    private class UserViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_topic,txt_teachername,txt_submitted;
        public LinearLayout lay_main;
        public ImageView crd_assin_todo,crd_ans_bylecturer,crd_ans_bystudent,crd_view_ans_student;

        public UserViewHolder(View itemView) {
            super(itemView);

            txt_topic = itemView.findViewById(R.id.txt_topic);
            lay_main = itemView.findViewById(R.id.lay_main);
            txt_submitted = itemView.findViewById(R.id.txt_submitted);
            txt_teachername = itemView.findViewById(R.id.txt_teachername);

            crd_assin_todo = itemView.findViewById(R.id.crd_assin_todo);
            crd_ans_bylecturer = itemView.findViewById(R.id.crd_ans_bylecturer);
            crd_ans_bystudent = itemView.findViewById(R.id.crd_ans_bystudent);
            crd_view_ans_student = itemView.findViewById(R.id.crd_view_ans_student);

        }
    }
}
