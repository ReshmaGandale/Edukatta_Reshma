package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Activity.RecordedMaterialVideoActivity;
import sgb.board.com.edu_katta.Dao.RecordedMaterialSubDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;

public class RecordedMaterialSubAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    private ArrayList<RecordedMaterialSubDAO> rDmemberDAOS;
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLoading;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;

    public RecordedMaterialSubAdapter(RecyclerView recyclerView, ArrayList<RecordedMaterialSubDAO> rDmemberDAOS, Context context)
    {
        this.context = context;
        this.rDmemberDAOS = rDmemberDAOS;
        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    if (onLoadMoreListener != null) {
                        onLoadMoreListener.onLoadMore();
                    }
                    isLoading = true;
                }
            }
        });
    }

    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener) {
        this.onLoadMoreListener = mOnLoadMoreListener;
    }

    @Override
    public int getItemViewType(int position) {
        return rDmemberDAOS.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(context).inflate(R.layout.recorded_materialsub_cardview, parent, false);
            return new RecordedMaterialSubAdapter.UserViewHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_loading, parent, false);
            return new RecordedMaterialSubAdapter.LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof RecordedMaterialSubAdapter.UserViewHolder) {

            RecordedMaterialSubDAO current = rDmemberDAOS.get(position);
            RecordedMaterialSubAdapter.UserViewHolder userViewHolder = (RecordedMaterialSubAdapter.UserViewHolder) holder;

            userViewHolder.txt_title.setText(rDmemberDAOS.get(position).getDiscuession_on_topic());
            if(rDmemberDAOS.get(position).getImage().equalsIgnoreCase(""))
            {
                Glide.with(context).load(R.drawable.upcome_img_1).into(userViewHolder.img_video);
            }
            else
            {
                Glide.with(context).load(rDmemberDAOS.get(position).getImage()).into(userViewHolder.img_video);
            }

             userViewHolder.lay_main.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View v) {
                     Intent intent = new Intent(context, RecordedMaterialVideoActivity.class);
                     intent.putExtra("title",rDmemberDAOS.get(position).getDiscuession_on_topic());
                     intent.putExtra("url",rDmemberDAOS.get(position).getList_title());
                     context.startActivity(intent);
                 }
             });


            if(rDmemberDAOS.get(position).getAssign_to_do().equalsIgnoreCase(""))
            {
                userViewHolder.crd_viewDpp.setVisibility(View.GONE);
            }
            else {
                userViewHolder.crd_viewDpp.setVisibility(View.VISIBLE);
            }

            if(rDmemberDAOS.get(position).getAssign_ans().equalsIgnoreCase(""))
            {
                userViewHolder.crd_ansDpp.setVisibility(View.GONE);
            }
            else {
                userViewHolder.crd_ansDpp.setVisibility(View.VISIBLE);
            }


            userViewHolder.crd_viewDpp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.e("Heelo...","..");

                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(rDmemberDAOS.get(position).getAssign_to_do()));
                    context.startActivity(browserIntent);
                }
            });

            userViewHolder.crd_ansDpp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.e("Heelo...","..");

                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(rDmemberDAOS.get(position).getAssign_ans()));
                    context.startActivity(browserIntent);

                }
            });


        } else if (holder instanceof RecordedMaterialSubAdapter.LoadingViewHolder) {
            RecordedMaterialSubAdapter.LoadingViewHolder loadingViewHolder = (RecordedMaterialSubAdapter.LoadingViewHolder) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }

    }


    @Override
    public int getItemCount() {
        return rDmemberDAOS == null ? 0 : rDmemberDAOS.size();
    }
    public void setLoaded() {
        isLoading = false;
    }



    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public LoadingViewHolder(View view) {
            super(view);
            progressBar = view.findViewById(R.id.progressBar1);
        }
    }


    private class UserViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_title;
        public LinearLayout lay_main;
        public CardView crd_ansDpp,crd_viewDpp;
        public ImageView img_video;

        public UserViewHolder(View itemView) {
            super(itemView);

            txt_title = itemView.findViewById(R.id.txt_title);
            lay_main = itemView.findViewById(R.id.lay_main);
//            web_view = itemView.findViewById(R.id.web_view);
            img_video = itemView.findViewById(R.id.img_video);
            crd_ansDpp = itemView.findViewById(R.id.crd_ansDpp);
            crd_viewDpp = itemView.findViewById(R.id.crd_viewDpp);

        }
    }
}
