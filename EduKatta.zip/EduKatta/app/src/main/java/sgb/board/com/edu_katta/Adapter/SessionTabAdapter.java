package sgb.board.com.edu_katta.Adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import sgb.board.com.edu_katta.Fragment.NextweekFragment;
import sgb.board.com.edu_katta.Fragment.TodatsFragment;
import sgb.board.com.edu_katta.Fragment.UpcomimgFragment;

public class SessionTabAdapter extends FragmentStatePagerAdapter {

    int mNumOfTabs;

    public SessionTabAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                TodatsFragment tab0 = new TodatsFragment();
                return tab0;
            case 1:
                UpcomimgFragment tab1 = new UpcomimgFragment();
                return tab1;
            case 2:
                NextweekFragment tab2 = new NextweekFragment();
                return tab2;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
