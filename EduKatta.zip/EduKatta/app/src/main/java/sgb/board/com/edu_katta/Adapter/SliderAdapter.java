package sgb.board.com.edu_katta.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import sgb.board.com.edu_katta.Models.HomeSliderModels;
import sgb.board.com.edu_katta.R;

public class SliderAdapter extends RecyclerView.Adapter<SliderAdapter.MyViewHolder> {
    List<HomeSliderModels.DataEntity>sliderData;
    Context context;

    public SliderAdapter(List<HomeSliderModels.DataEntity> sliderData, Context context) {
        this.sliderData = sliderData;
        this.context = context;
    }

    @NonNull
    @Override
    public SliderAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view=LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.homepage_slider_items,viewGroup,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SliderAdapter.MyViewHolder myViewHolder, int position) {

      //  Glide.with(context).load(sliderData.get(1).getImagepath()+"").fitCenter().into(myViewHolder.sliderView);
        Picasso.get().load(sliderData.get(position).getImagepath()+"").into(myViewHolder.sliderView);
    }

    @Override
    public int getItemCount() {
        return sliderData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView sliderView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            sliderView=itemView.findViewById(R.id.iv_auto_image_slider);
        }
    }
}