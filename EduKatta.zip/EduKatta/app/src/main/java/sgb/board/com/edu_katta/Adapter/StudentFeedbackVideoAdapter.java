package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Activity.RecordedMaterialVideoActivity;
import sgb.board.com.edu_katta.Dao.HomeFragmentStuVideoDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;

public class StudentFeedbackVideoAdapter  extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    private ArrayList<HomeFragmentStuVideoDAO> rDmemberDAOS;
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLoading;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;

    public StudentFeedbackVideoAdapter(RecyclerView recyclerView, ArrayList<HomeFragmentStuVideoDAO> rDmemberDAOS, Context context)
    {
        this.context = context;
        this.rDmemberDAOS = rDmemberDAOS;
        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    if (onLoadMoreListener != null) {
                        onLoadMoreListener.onLoadMore();
                    }
                    isLoading = true;
                }
            }
        });
    }

    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener) {
        this.onLoadMoreListener = mOnLoadMoreListener;
    }

    @Override
    public int getItemViewType(int position) {
        return rDmemberDAOS.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(context).inflate(R.layout.student_feedback_video2_cardview, parent, false);
            return new StudentFeedbackVideoAdapter.UserViewHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_loading, parent, false);
            return new StudentFeedbackVideoAdapter.LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof StudentFeedbackVideoAdapter.UserViewHolder) {

            HomeFragmentStuVideoDAO current = rDmemberDAOS.get(position);
            StudentFeedbackVideoAdapter.UserViewHolder userViewHolder = (StudentFeedbackVideoAdapter.UserViewHolder) holder;

            userViewHolder.txt_title.setText(rDmemberDAOS.get(position).getName());
            if(rDmemberDAOS.get(position).getVideoimage().equalsIgnoreCase(""))
            {
                Glide.with(context).load(R.drawable.upcome_img_1).into(userViewHolder.img_video);
            }
            else
            {
                Glide.with(context).load(rDmemberDAOS.get(position).getVideoimage()).into(userViewHolder.img_video);
            }

            userViewHolder.lay_main.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, RecordedMaterialVideoActivity.class);
                    intent.putExtra("title",rDmemberDAOS.get(position).getName());
                    intent.putExtra("url",rDmemberDAOS.get(position).getVideolink());
                    context.startActivity(intent);
                }
            });



        } else if (holder instanceof StudentFeedbackVideoAdapter.LoadingViewHolder) {
            StudentFeedbackVideoAdapter.LoadingViewHolder loadingViewHolder = (StudentFeedbackVideoAdapter.LoadingViewHolder) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }

    }


    @Override
    public int getItemCount() {
        return rDmemberDAOS == null ? 0 : rDmemberDAOS.size();
    }
    public void setLoaded() {
        isLoading = false;
    }



    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public LoadingViewHolder(View view) {
            super(view);
            progressBar = view.findViewById(R.id.progressBar1);
        }
    }


    private class UserViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_title;
        public LinearLayout lay_main;
        //        public WebView web_view;
        public ImageView img_video;

        public UserViewHolder(View itemView) {
            super(itemView);

            txt_title = itemView.findViewById(R.id.txt_title);
            lay_main = itemView.findViewById(R.id.lay_main);
//            web_view = itemView.findViewById(R.id.web_view);
            img_video = itemView.findViewById(R.id.img_video);

        }
    }
}
