package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.StudyMaterialSubDAO;
import sgb.board.com.edu_katta.R;

public class StudyMaterialSubAdapter  extends RecyclerView.Adapter<StudyMaterialSubAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<StudyMaterialSubDAO> todaysDAOS;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txt_topic,txt_topicDesc;
        public CardView pdfCard;

        public MyViewHolder(View view) {
            super(view);

            txt_topic = view.findViewById(R.id.txt_topic);
            txt_topicDesc = view.findViewById(R.id.txt_topicDesc);
            pdfCard = view.findViewById(R.id.pdfCard);
        }
    }


    public StudyMaterialSubAdapter(Context context, ArrayList<StudyMaterialSubDAO> addressListDAOS) {
        this.context = context;
        this.todaysDAOS = addressListDAOS;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.study_material_cardview, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final StudyMaterialSubDAO current = todaysDAOS.get(position);

        holder.txt_topic.setText(current.getTopic());
        holder.txt_topicDesc.setText(current.getTopicDescription());

        holder.pdfCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(todaysDAOS.get(position).getPdflink()));
                context.startActivity(browserIntent);
            }
        });
//
//        if(current.getPhoto().equalsIgnoreCase(""))
//        {
//            Glide.with(context).load(R.drawable.demo_image).into(holder.img_minister);
//        }
//        else
//        {
//            Glide.with(context).load(current.getPhoto()).into(holder.img_minister);
//        }

    }

    @Override
    public int getItemCount() {
        return todaysDAOS.size();
    }
}
