package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.TodaysDAO;
import sgb.board.com.edu_katta.R;

public class StudyMaterialSub_1Adapter  extends RecyclerView.Adapter<StudyMaterialSub_1Adapter.MyViewHolder> {
    private Context context;
    private ArrayList<TodaysDAO> todaysDAOS;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tx_name,tx_time,tx_subject,tx_topic,tx_duration;

        public CardView card_attend;

        public MyViewHolder(View view) {
            super(view);

//            tx_name = view.findViewById(R.id.tx_name);
//            tx_time = view.findViewById(R.id.tx_time);
//            tx_subject = view.findViewById(R.id.tx_subject);
//            tx_topic = view.findViewById(R.id.tx_topic);
//            tx_duration = view.findViewById(R.id.tx_duration);
//            card_attend = view.findViewById(R.id.card_attend);
        }
    }


    public StudyMaterialSub_1Adapter(Context context, ArrayList<TodaysDAO> addressListDAOS) {
        this.context = context;
        this.todaysDAOS = addressListDAOS;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.recorded_materialsub_cardview, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final TodaysDAO current = todaysDAOS.get(position);

//        holder.tx_name.setText(current.getName());
//        holder.tx_time.setText(current.getTime());
//        holder.tx_subject.setText(current.getSubject());
//        holder.tx_topic.setText(current.getTopic());
//        holder.tx_duration.setText(current.getDuration());
//
//        holder.card_attend.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Intent intent = new Intent(context, TodaysLectureActivity.class);
//                context.startActivity(intent);
//            }
//        });

    }

    @Override
    public int getItemCount() {
        return todaysDAOS.size();
    }
}
