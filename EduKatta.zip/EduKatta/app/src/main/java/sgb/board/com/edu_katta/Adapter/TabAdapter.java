package sgb.board.com.edu_katta.Adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import sgb.board.com.edu_katta.Fragment.DPPFragment;
import sgb.board.com.edu_katta.Fragment.DashboardFragment;
import sgb.board.com.edu_katta.Fragment.HomeFragment;
import sgb.board.com.edu_katta.Fragment.LibraryFragment;
import sgb.board.com.edu_katta.Fragment.SessionFragment;

public class TabAdapter extends FragmentStatePagerAdapter {

    int mNumOfTabs;

    public TabAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                HomeFragment tab0 = new HomeFragment();
                return tab0;
            case 1:
                DashboardFragment tab1 = new DashboardFragment();
                return tab1;
            case 2:
                SessionFragment tab2 = new SessionFragment();
                return tab2;
            case 3:
                LibraryFragment tab3 = new LibraryFragment();
                return tab3;
            case 4:
                DPPFragment tab4 = new DPPFragment();
                return tab4;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
