package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import sgb.board.com.edu_katta.Activity.JeeMockTestActivity;
import sgb.board.com.edu_katta.Dao.TestTypeSpinnerDAO;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Session.SessionManager;

public class TestTypeSpinnerAdapter extends RecyclerView.Adapter<TestTypeSpinnerAdapter.ViewHolder> {
    Context context1;
    private List<TestTypeSpinnerDAO> expenseSpinnerDAOS;
    private List<TestTypeSpinnerDAO> mFilteredList;
    TestTypeSpinnerDAO current;
    SessionManager sessionManager;
    View view1;
    public TestTypeSpinnerAdapter(Context context2, List<TestTypeSpinnerDAO> expenseSpinnerDAOS){

        this.context1 = context2;
        this.expenseSpinnerDAOS = expenseSpinnerDAOS;
        this.mFilteredList = expenseSpinnerDAOS;
        sessionManager = new SessionManager(context1);
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        public TextView terryName;
        public LinearLayout terry;
        public ViewHolder(View v)
        {
            super(v);
            terryName = (TextView) v.findViewById(R.id.terryName);
            terry = (LinearLayout) v.findViewById(R.id.terry);
        }
    }
    @Override
    public TestTypeSpinnerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view1 = LayoutInflater.from(context1).inflate(R.layout.dropdown_list_raw,parent,false);
        TestTypeSpinnerAdapter.ViewHolder viewHolder1 = new TestTypeSpinnerAdapter.ViewHolder(view1);
        return viewHolder1;
    }

    @Override
    public void onBindViewHolder(final TestTypeSpinnerAdapter.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        current = mFilteredList.get(position);
        holder.terryName.setText(current.getTesT_TOPIC());

        holder.terryName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((JeeMockTestActivity) context1).onTesttypePopupClick(mFilteredList.get(position).getMocK_ID(),mFilteredList.get(position).getTesT_TOPIC());
            }
        });
    }

    @Override
    public int getItemCount() {
        return mFilteredList.size();
    }

    public Filter getFilter() {

        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                Log.e("charString",charString);
                if (charString.isEmpty()) {
                    mFilteredList = expenseSpinnerDAOS;
                } else {
                    ArrayList<TestTypeSpinnerDAO> filteredList = new ArrayList<>();
                    for (TestTypeSpinnerDAO cityDAOS : expenseSpinnerDAOS) {
                        if (cityDAOS.getTesT_TOPIC().toLowerCase().contains(charString)) {
                            filteredList.add(cityDAOS);
                        }
                    }
                    mFilteredList = filteredList;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = mFilteredList;
                return filterResults;
            }
            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilteredList = (ArrayList<TestTypeSpinnerDAO>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }
}
