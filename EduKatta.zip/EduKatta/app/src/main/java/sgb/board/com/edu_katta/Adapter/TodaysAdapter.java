package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Activity.TodaySessionLiveActivity;
import sgb.board.com.edu_katta.Dao.TodaysDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;

public class TodaysAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    private ArrayList<TodaysDAO> rDmemberDAOS;
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLoading;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;

    public TodaysAdapter(RecyclerView recyclerView, ArrayList<TodaysDAO> rDmemberDAOS, Context context)
    {
        this.context = context;
        this.rDmemberDAOS = rDmemberDAOS;
        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    if (onLoadMoreListener != null) {
                        onLoadMoreListener.onLoadMore();
                    }
                    isLoading = true;
                }
            }
        });
    }

    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener) {
        this.onLoadMoreListener = mOnLoadMoreListener;
    }

    @Override
    public int getItemViewType(int position) {
        return rDmemberDAOS.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(context).inflate(R.layout.todays_list_cardview, parent, false);
            return new TodaysAdapter.UserViewHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_loading, parent, false);
            return new TodaysAdapter.LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof TodaysAdapter.UserViewHolder) {
            final TodaysDAO current = rDmemberDAOS.get(position);
            final UserViewHolder userViewHolder = (UserViewHolder) holder;

            userViewHolder.tx_name.setText(current.getTeacheR_NAME());
            userViewHolder.tx_subject.setText(current.getSubject());
            userViewHolder.tx_topic.setText(current.getDiscuessioN_ON_TOPIC());
            userViewHolder.tx_duration.setText(current.getDuration());
            userViewHolder.tx_time.setText(current.getFrom_time()+"-"+current.getTo_time());

            if(current.getMarK_ATTENDENCE().equalsIgnoreCase("Attended"))
            {
                userViewHolder.card_attend.setVisibility(View.GONE); //
            }
            else
            {
                userViewHolder.card_attend.setVisibility(View.VISIBLE);
            }

            if(current.getImage().equalsIgnoreCase(""))
            {
                Glide.with(context).load(R.drawable.demo_image).into(userViewHolder.img_teacher);
            }
            else
            {
                Glide.with(context).load(current.getImage()).into(userViewHolder.img_teacher);
            }

            userViewHolder.card_attend.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(rDmemberDAOS.get(position).getLive().equalsIgnoreCase(""))
                    {
                        Toast.makeText(context, "Video Not Available", Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                      //  Intent intent = new Intent(context, TodaysLectureVideoActivity.class);
                        Intent intent = new Intent(context, TodaySessionLiveActivity.class);
                        intent.putExtra("url",rDmemberDAOS.get(position).getLive());
                        intent.putExtra("chat",rDmemberDAOS.get(position).getChat());
                        intent.putExtra("tsch_de_id",rDmemberDAOS.get(position).getTscH_DE_ID());
                        context.startActivity(intent);
                    }

                }
            });


        } else if (holder instanceof TodaysAdapter.LoadingViewHolder) {
            TodaysAdapter.LoadingViewHolder loadingViewHolder = (TodaysAdapter.LoadingViewHolder) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }

    }


    @Override
    public int getItemCount() {
        return rDmemberDAOS == null ? 0 : rDmemberDAOS.size();
    }
    public void setLoaded() {
        isLoading = false;
    }



    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public LoadingViewHolder(View view) {
            super(view);
            progressBar = view.findViewById(R.id.progressBar1);
        }
    }


    private class UserViewHolder extends RecyclerView.ViewHolder {

        public TextView tx_name,tx_subject,tx_topic,tx_duration,tx_time;
        public CardView card_attend;
        public ImageView img_teacher;

        public UserViewHolder(View itemView) {
            super(itemView);

            tx_name = itemView.findViewById(R.id.tx_name);
            tx_subject = itemView.findViewById(R.id.tx_subject);
            tx_topic = itemView.findViewById(R.id.tx_topic);
            tx_duration = itemView.findViewById(R.id.tx_duration);
            card_attend = itemView.findViewById(R.id.card_attend);

            img_teacher = itemView.findViewById(R.id.img_teacher);
            tx_time = itemView.findViewById(R.id.tx_time);

        }
    }

}
