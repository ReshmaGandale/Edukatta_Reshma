package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.TodaysLectureDAO;
import sgb.board.com.edu_katta.R;

public class TodaysLectureAdapter extends RecyclerView.Adapter<TodaysLectureAdapter.ViewHolder> {

    ArrayList<TodaysLectureDAO> al_video;
    Context context;
    Activity activity;


    public TodaysLectureAdapter(Context context, ArrayList<TodaysLectureDAO> al_video, Activity activity) {

        this.al_video = al_video;
        this.context = context;
        this.activity = activity;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView iv_image;
        RelativeLayout rl_select;
        public ViewHolder(View v) {

            super(v);

            iv_image = (ImageView) v.findViewById(R.id.iv_image);
            rl_select = (RelativeLayout) v.findViewById(R.id.rl_select);

        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.todays_lecture_cardview, parent, false);

        ViewHolder viewHolder1 = new ViewHolder(view);

        return viewHolder1;
    }

    @Override
    public void onBindViewHolder(final ViewHolder Vholder, @SuppressLint("RecyclerView") final int position) {


//        Glide.with(context).load(al_video.get(position).getStr_thumb())
//                .skipMemoryCache(false)
//                .into(Vholder.iv_image);
//        Vholder.rl_select.setBackgroundColor(Color.parseColor("#000000"));
//        Vholder.rl_select.setAlpha(0.3f);

        Vholder.rl_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(al_video.get(position).getUrl().equalsIgnoreCase(""))
                {
                    Toast.makeText(context, "Video Not Available", Toast.LENGTH_LONG).show();
                }
                else
                {
//                    Intent intent_gallery = new Intent(context,VideoGalleryDetailActivity.class);
//                    intent_gallery.putExtra("news_url",al_video.get(position).getUrl());
//                    activity.startActivity(intent_gallery);
                }
            }
        });

    }

    @Override
    public int getItemCount() {

        return al_video.size();
    }
}
