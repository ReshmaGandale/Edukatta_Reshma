package sgb.board.com.edu_katta.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import sgb.board.com.edu_katta.Dao.UpcomingLectureDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;

public class UpcomingAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    private ArrayList<UpcomingLectureDAO> rDmemberDAOS;
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    private OnLoadMoreListener onLoadMoreListener;
    private boolean isLoading;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;

    public UpcomingAdapter(RecyclerView recyclerView, ArrayList<UpcomingLectureDAO> rDmemberDAOS, Context context)
    {
        this.context = context;
        this.rDmemberDAOS = rDmemberDAOS;
        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                totalItemCount = linearLayoutManager.getItemCount();
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                    if (onLoadMoreListener != null) {
                        onLoadMoreListener.onLoadMore();
                    }
                    isLoading = true;
                }
            }
        });
    }

    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener) {
        this.onLoadMoreListener = mOnLoadMoreListener;
    }

    @Override
    public int getItemViewType(int position) {
        return rDmemberDAOS.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(context).inflate(R.layout.upcoming_list_cardview, parent, false);
            return new UpcomingAdapter.UserViewHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_loading, parent, false);
            return new UpcomingAdapter.LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof UpcomingAdapter.UserViewHolder) {
            final UpcomingLectureDAO current = rDmemberDAOS.get(position);
            final UpcomingAdapter.UserViewHolder userViewHolder = (UpcomingAdapter.UserViewHolder) holder;

            userViewHolder.tx_name.setText(current.getFirstname());
            userViewHolder.tx_subject.setText(current.getSubject());
            userViewHolder.tx_topic.setText(current.getTopic());
            userViewHolder.tx_duration.setText(current.getDuration());
            userViewHolder.txt_date.setText(current.getDate());
            userViewHolder.tx_time.setText(current.getTime());

            if(current.getImage().equalsIgnoreCase(""))
            {
                Glide.with(context).load(R.drawable.demo_image).into(userViewHolder.img_teacher);
            }
            else
            {
                Glide.with(context).load(current.getImage()).into(userViewHolder.img_teacher);
            }

        } else if (holder instanceof UpcomingAdapter.LoadingViewHolder) {
            UpcomingAdapter.LoadingViewHolder loadingViewHolder = (UpcomingAdapter.LoadingViewHolder) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }
    }

    @Override
    public int getItemCount() {
        return rDmemberDAOS == null ? 0 : rDmemberDAOS.size();
    }
    public void setLoaded() {
        isLoading = false;
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public LoadingViewHolder(View view) {
            super(view);
            progressBar = view.findViewById(R.id.progressBar1);
        }
    }


    private class UserViewHolder extends RecyclerView.ViewHolder {

        public TextView tx_name,tx_subject,tx_topic,tx_duration,tx_time,txt_date;
        public CardView card_order;
        public ImageView img_teacher;

        public UserViewHolder(View itemView) {
            super(itemView);

            tx_name = itemView.findViewById(R.id.tx_name);
            tx_subject = itemView.findViewById(R.id.tx_subject);
            tx_topic = itemView.findViewById(R.id.tx_topic);
            tx_duration = itemView.findViewById(R.id.tx_duration);
            tx_time = itemView.findViewById(R.id.tx_time);
            txt_date = itemView.findViewById(R.id.txt_date);
            img_teacher = itemView.findViewById(R.id.img_teacher);

        }
    }

}
