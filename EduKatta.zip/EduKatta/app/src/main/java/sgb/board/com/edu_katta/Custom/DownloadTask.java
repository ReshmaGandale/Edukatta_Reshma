package sgb.board.com.edu_katta.Custom;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import sgb.board.com.edu_katta.R;

public class DownloadTask {

    private static final String TAG = "Download Task";
    private Context context1;

    private String downloadUrl = "", downloadFileName = "";
    private ProgressDialog progressDialog ;
    PendingIntent pendingIntent;

    public DownloadTask(Context context, String downloadUrl,String name) {
        Log.e("context...",context.toString());
        this.context1 = context;

        this.downloadUrl = downloadUrl;

       // downloadFileName = downloadUrl.substring(downloadUrl.lastIndexOf('/'), downloadUrl.length());//Create file name by picking download file name from URL
        //downloadFileName =
        downloadFileName = name;
        Log.e(TAG, downloadFileName);
//         Intent myIntent = new Intent(context, HomeActivity.class);
//         pendingIntent = PendingIntent.getActivity(context,0,myIntent,Intent.FLAG_ACTIVITY_NEW_TASK);
        //Start Downloading Task
        new DownloadingTask().execute();
    }

    private class DownloadingTask extends AsyncTask<Void, Void, Void> {

        File apkStorage = null;
        File outputFile = null;
        NotificationManager mNotifyManager;
        NotificationCompat.Builder mBuilder;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(context1);
            progressDialog.setMessage("Downloading...");
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(Void result) {
            try {
                if (outputFile != null) {
                    progressDialog.dismiss();
                    Toast.makeText(context1, "Downloaded Successfully", Toast.LENGTH_SHORT).show();
                    String filePath =Environment.getExternalStorageDirectory() + "/" + "MahaSGB FILES/"+downloadFileName;
                    Log.e("filepath",filePath);
                    File file = new File(filePath);
                    Toast.makeText(context1, filePath, Toast.LENGTH_LONG).show();
                    MimeTypeMap mime = MimeTypeMap.getSingleton();
                    String ext=file.getName().substring(file.getName().indexOf(".")+1);
                    String type = mime.getMimeTypeFromExtension(ext);
                    Intent openFile = new Intent(Intent.ACTION_VIEW, Uri.fromFile(file));
                    openFile.setDataAndType(Uri.fromFile(file), type);
                    openFile.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    PendingIntent p = PendingIntent.getActivity(context1, 0, openFile, 0);

                    mNotifyManager =(NotificationManager) context1.getSystemService(Context.NOTIFICATION_SERVICE);
                    mBuilder = new NotificationCompat.Builder(context1);
                    mBuilder.setContentTitle("File Download").setContentText("Download in progress")
                            .setSmallIcon(R.mipmap.ic_launcher).setContentIntent(p);
                    mBuilder.setContentText("Download complete");
                    // Removes the progress bar
                    mBuilder.setProgress(0,0,false);
                    mNotifyManager.notify(0, mBuilder.build());
                } else {

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                        }
                    }, 3000);

                    Log.e(TAG, "Download Failed");

                }
            } catch (Exception e) {
                e.printStackTrace();

                //Change button text if exception occurs

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                    }
                }, 3000);
                Log.e(TAG, "Download Failed with Exception - " + e.getLocalizedMessage());

            }


            super.onPostExecute(result);
        }


        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                URL url = new URL(downloadUrl);//Create Download URl
                HttpURLConnection c = (HttpURLConnection) url.openConnection();//Open Url Connection
                c.setRequestMethod("GET");//Set Request Method to "GET" since we are grtting data
                c.connect();//connect the URL Connection

                //If Connection response is not OK then show Logs
                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.e(TAG, "Server returned HTTP " + c.getResponseCode()
                            + " " + c.getResponseMessage());

                }


                //Get File if SD card is present
                if (new CheckForSDCard().isSDCardPresent()) {

                    apkStorage = new File(
                            Environment.getExternalStorageDirectory() + "/"
                                    + "MahaSGB FILES");
                } else
                    Toast.makeText(context1, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();

                //If File is not present create directory
                if (!apkStorage.exists()) {
                    apkStorage.mkdir();
                    Log.e(TAG, "Directory Created.");
                }

                outputFile = new File(apkStorage, downloadFileName);//Create Output file in Main File

                //Create New File if not present
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                    Log.e(TAG, "File Created");
                }

                FileOutputStream fos = new FileOutputStream(outputFile);//Get OutputStream for NewFile Location

                InputStream is = c.getInputStream();//Get InputStream for connection

                byte[] buffer = new byte[1024];//Set buffer type
                int len1 = 0;//init length
                while ((len1 = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len1);//Write new file
                }

                //Close all connection after doing task
                fos.close();
                is.close();

            } catch (Exception e) {

                //Read exception if something went wrong
                e.printStackTrace();
                outputFile = null;
                Log.e(TAG, "Download Error Exception " + e.getMessage());
            }

            return null;
        }

        protected void onProgressUpdate(Integer... progress) {

            mBuilder.setProgress(100, progress[0], false);
            // Displays the progress bar on notification
            mNotifyManager.notify(0, mBuilder.build());
        }
    }
}
