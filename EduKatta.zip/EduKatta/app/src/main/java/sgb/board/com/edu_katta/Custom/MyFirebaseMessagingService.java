package sgb.board.com.edu_katta.Custom;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;

import sgb.board.com.edu_katta.Activity.DashboardActivity;
import sgb.board.com.edu_katta.R;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage)
    {
        super.onMessageReceived(remoteMessage);

        Log.d("Message", "Message received ["+ remoteMessage.getNotification().getBody() +"]");
        //Bitmap licon = BitmapFactory.decodeFile(remoteMessage.getData().get("img_url"));
        //Create Notification
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 1,
                intent, PendingIntent.FLAG_ONE_SHOT);

        final NotificationCompat.Builder notificationBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(this);
        notificationBuilder.setColor(ContextCompat.getColor(this, R.color.colorPrimaryDark));
        notificationBuilder.setSmallIcon(R.drawable.noti_icon);
        notificationBuilder.setDefaults(Notification.DEFAULT_SOUND);
        notificationBuilder.setContentTitle(remoteMessage.getNotification().getTitle());
        notificationBuilder.setContentText(remoteMessage.getNotification().getBody());
        //notificationBuilder.setLargeIcon(licon);
        notificationBuilder.setAutoCancel(true);
        notificationBuilder.setContentIntent(pendingIntent);
        //    //imge code
        ImageRequest imageRequest = new ImageRequest(remoteMessage.getData().get("img_url"), new Response.Listener<Bitmap>()
        {
            @Override
            public void onResponse(Bitmap response)
            {
                System.out.println("IB_IMAGE BACK "+remoteMessage.getData().get("img_url"));
                notificationBuilder.setStyle(new NotificationCompat.BigPictureStyle().bigPicture(response));
                NotificationManager notificationManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                notificationManager.notify(1,notificationBuilder.build());
            }
        }, 0, 0, null ,new Response.ErrorListener()
        {
            @Override
            public void onErrorResponse(VolleyError error)
            {

            }
        });

        MySingleton.getmIntance(this).addToRequestQue(imageRequest);
        //end image code
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        notificationBuilder.setSound(alarmSound);
        long[] v = {500,1000};
        notificationBuilder.setVibrate(v);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(1, notificationBuilder.build());
    }
}
