package sgb.board.com.edu_katta.Custom;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

public class MySingleton {

    private static MySingleton myInstace;
    private static Context context;
    private RequestQueue requestQueue;

    private MySingleton(Context context)
    {
        this.context = context;
        requestQueue = getRequestQueue();
    }

    private RequestQueue getRequestQueue()
    {
        if(requestQueue==null)
            requestQueue = Volley.newRequestQueue(context.getApplicationContext());
        return requestQueue;
    }

    public static synchronized MySingleton getmIntance(Context context)
    {
        if(myInstace==null)
            myInstace = new MySingleton(context);
        return myInstace;
    }

    public <T>void addToRequestQue(Request<T> request)
    {
        getRequestQueue().add(request);
    }
}
