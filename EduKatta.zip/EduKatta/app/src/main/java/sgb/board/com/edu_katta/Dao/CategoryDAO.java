package sgb.board.com.edu_katta.Dao;

public class CategoryDAO {

    private  String  id, name, status,qtypE_ID,code;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getQtypE_ID() {
        return qtypE_ID;
    }

    public void setQtypE_ID(String qtypE_ID) {
        this.qtypE_ID = qtypE_ID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
