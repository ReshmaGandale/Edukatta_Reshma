package sgb.board.com.edu_katta.Dao;

public class HelpDeskListDAO {

    private String id, querY_TYPE, subquerY_TYPE, filE_PATH, query, status, useR_ID, querY_TYPE_NAME, subquerY_TYPE_NAME;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQuerY_TYPE() {
        return querY_TYPE;
    }

    public void setQuerY_TYPE(String querY_TYPE) {
        this.querY_TYPE = querY_TYPE;
    }

    public String getSubquerY_TYPE() {
        return subquerY_TYPE;
    }

    public void setSubquerY_TYPE(String subquerY_TYPE) {
        this.subquerY_TYPE = subquerY_TYPE;
    }

    public String getFilE_PATH() {
        return filE_PATH;
    }

    public void setFilE_PATH(String filE_PATH) {
        this.filE_PATH = filE_PATH;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUseR_ID() {
        return useR_ID;
    }

    public void setUseR_ID(String useR_ID) {
        this.useR_ID = useR_ID;
    }

    public String getQuerY_TYPE_NAME() {
        return querY_TYPE_NAME;
    }

    public void setQuerY_TYPE_NAME(String querY_TYPE_NAME) {
        this.querY_TYPE_NAME = querY_TYPE_NAME;
    }

    public String getSubquerY_TYPE_NAME() {
        return subquerY_TYPE_NAME;
    }

    public void setSubquerY_TYPE_NAME(String subquerY_TYPE_NAME) {
        this.subquerY_TYPE_NAME = subquerY_TYPE_NAME;
    }
}
