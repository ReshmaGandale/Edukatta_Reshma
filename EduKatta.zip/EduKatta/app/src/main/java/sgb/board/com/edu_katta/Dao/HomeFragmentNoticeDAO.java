package sgb.board.com.edu_katta.Dao;

public class HomeFragmentNoticeDAO {

    private String id, name, description, link, fromdate, todate, imagE_URL;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getFromdate() {
        return fromdate;
    }

    public void setFromdate(String fromdate) {
        this.fromdate = fromdate;
    }

    public String getTodate() {
        return todate;
    }

    public void setTodate(String todate) {
        this.todate = todate;
    }

    public String getImagE_URL() {
        return imagE_URL;
    }

    public void setImagE_URL(String imagE_URL) {
        this.imagE_URL = imagE_URL;
    }
}
