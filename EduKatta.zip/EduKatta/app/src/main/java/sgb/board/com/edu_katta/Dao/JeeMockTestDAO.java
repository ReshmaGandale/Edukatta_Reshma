package sgb.board.com.edu_katta.Dao;

public class JeeMockTestDAO {

    private String id, tesT_TOPIC, test_DATE, year, submitteD_STUDENT_ID, remark, mocK_STD_ID, studenT_ID, questions, answers, submit;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTesT_TOPIC() {
        return tesT_TOPIC;
    }

    public void setTesT_TOPIC(String tesT_TOPIC) {
        this.tesT_TOPIC = tesT_TOPIC;
    }

    public String getTest_DATE() {
        return test_DATE;
    }

    public void setTest_DATE(String test_DATE) {
        this.test_DATE = test_DATE;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getSubmitteD_STUDENT_ID() {
        return submitteD_STUDENT_ID;
    }

    public void setSubmitteD_STUDENT_ID(String submitteD_STUDENT_ID) {
        this.submitteD_STUDENT_ID = submitteD_STUDENT_ID;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getMocK_STD_ID() {
        return mocK_STD_ID;
    }

    public void setMocK_STD_ID(String mocK_STD_ID) {
        this.mocK_STD_ID = mocK_STD_ID;
    }

    public String getStudenT_ID() {
        return studenT_ID;
    }

    public void setStudenT_ID(String studenT_ID) {
        this.studenT_ID = studenT_ID;
    }

    public String getQuestions() {
        return questions;
    }

    public void setQuestions(String questions) {
        this.questions = questions;
    }

    public String getAnswers() {
        return answers;
    }

    public void setAnswers(String answers) {
        this.answers = answers;
    }

    public String getSubmit() {
        return submit;
    }

    public void setSubmit(String submit) {
        this.submit = submit;
    }
}
