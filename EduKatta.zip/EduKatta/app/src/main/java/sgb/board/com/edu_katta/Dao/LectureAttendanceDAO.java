package sgb.board.com.edu_katta.Dao;

public class LectureAttendanceDAO {

    private String subject, total_lectures, attendance, assignments, submitted_assignments,type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTotal_lectures() {
        return total_lectures;
    }

    public void setTotal_lectures(String total_lectures) {
        this.total_lectures = total_lectures;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }

    public String getAssignments() {
        return assignments;
    }

    public void setAssignments(String assignments) {
        this.assignments = assignments;
    }

    public String getSubmitted_assignments() {
        return submitted_assignments;
    }

    public void setSubmitted_assignments(String submitted_assignments) {
        this.submitted_assignments = submitted_assignments;
    }
}
