package sgb.board.com.edu_katta.Dao;

public class LibraryVideoListDAO {

    private String lisT_TITLE, img, lisT_TITLElink, schedule, discuessioN_ON_TOPIC, download, assigN_TO_DO, assigN_ANS;

    public String getLisT_TITLE() {
        return lisT_TITLE;
    }

    public void setLisT_TITLE(String lisT_TITLE) {
        this.lisT_TITLE = lisT_TITLE;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getLisT_TITLElink() {
        return lisT_TITLElink;
    }

    public void setLisT_TITLElink(String lisT_TITLElink) {
        this.lisT_TITLElink = lisT_TITLElink;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public String getDiscuessioN_ON_TOPIC() {
        return discuessioN_ON_TOPIC;
    }

    public void setDiscuessioN_ON_TOPIC(String discuessioN_ON_TOPIC) {
        this.discuessioN_ON_TOPIC = discuessioN_ON_TOPIC;
    }

    public String getDownload() {
        return download;
    }

    public void setDownload(String download) {
        this.download = download;
    }

    public String getAssigN_TO_DO() {
        return assigN_TO_DO;
    }

    public void setAssigN_TO_DO(String assigN_TO_DO) {
        this.assigN_TO_DO = assigN_TO_DO;
    }

    public String getAssigN_ANS() {
        return assigN_ANS;
    }

    public void setAssigN_ANS(String assigN_ANS) {
        this.assigN_ANS = assigN_ANS;
    }
}
