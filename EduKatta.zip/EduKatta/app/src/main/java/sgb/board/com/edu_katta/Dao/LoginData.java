package sgb.board.com.edu_katta.Dao;

public class LoginData {

}
