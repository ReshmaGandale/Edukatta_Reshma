package sgb.board.com.edu_katta.Dao;

public class NoticeListDAO {

    private String noticE_DATE,message,mjnB_ID;

    public String getNoticE_DATE() {
        return noticE_DATE;
    }

    public void setNoticE_DATE(String noticE_DATE) {
        this.noticE_DATE = noticE_DATE;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMjnB_ID() {
        return mjnB_ID;
    }

    public void setMjnB_ID(String mjnB_ID) {
        this.mjnB_ID = mjnB_ID;
    }
}
