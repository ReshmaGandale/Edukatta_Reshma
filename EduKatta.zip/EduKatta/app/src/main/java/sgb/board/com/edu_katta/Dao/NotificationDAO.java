package sgb.board.com.edu_katta.Dao;

public class NotificationDAO {

    private String  receiver_id, notification_id, message, receiver_type_id, status, recepient_id, sgb_board_id,notitype,send_date;

    public String getSend_date() {
        return send_date;
    }

    public void setSend_date(String send_date) {
        this.send_date = send_date;
    }

    public String getNotitype() {
        return notitype;
    }

    public void setNotitype(String notitype) {
        this.notitype = notitype;
    }

    public String getReceiver_id() {
        return receiver_id;
    }

    public void setReceiver_id(String receiver_id) {
        this.receiver_id = receiver_id;
    }

    public String getNotification_id() {
        return notification_id;
    }

    public void setNotification_id(String notification_id) {
        this.notification_id = notification_id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getReceiver_type_id() {
        return receiver_type_id;
    }

    public void setReceiver_type_id(String receiver_type_id) {
        this.receiver_type_id = receiver_type_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRecepient_id() {
        return recepient_id;
    }

    public void setRecepient_id(String recepient_id) {
        this.recepient_id = recepient_id;
    }

    public String getSgb_board_id() {
        return sgb_board_id;
    }

    public void setSgb_board_id(String sgb_board_id) {
        this.sgb_board_id = sgb_board_id;
    }
}
