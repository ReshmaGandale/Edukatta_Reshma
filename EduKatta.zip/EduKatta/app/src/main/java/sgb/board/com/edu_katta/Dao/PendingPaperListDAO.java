package sgb.board.com.edu_katta.Dao;

public class PendingPaperListDAO {

    private String   teacheR_NAME, schedule, course, subject, topic, storeD_LINK, uploadeD_ASSIGNMENT,
            uploadeD_ANSWER, studenT_ID, submitteD_ANSWER, vieW_ANSWER;

    public String getTeacheR_NAME() {
        return teacheR_NAME;
    }

    public void setTeacheR_NAME(String teacheR_NAME) {
        this.teacheR_NAME = teacheR_NAME;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getStoreD_LINK() {
        return storeD_LINK;
    }

    public void setStoreD_LINK(String storeD_LINK) {
        this.storeD_LINK = storeD_LINK;
    }

    public String getUploadeD_ASSIGNMENT() {
        return uploadeD_ASSIGNMENT;
    }

    public void setUploadeD_ASSIGNMENT(String uploadeD_ASSIGNMENT) {
        this.uploadeD_ASSIGNMENT = uploadeD_ASSIGNMENT;
    }

    public String getUploadeD_ANSWER() {
        return uploadeD_ANSWER;
    }

    public void setUploadeD_ANSWER(String uploadeD_ANSWER) {
        this.uploadeD_ANSWER = uploadeD_ANSWER;
    }

    public String getStudenT_ID() {
        return studenT_ID;
    }

    public void setStudenT_ID(String studenT_ID) {
        this.studenT_ID = studenT_ID;
    }

    public String getSubmitteD_ANSWER() {
        return submitteD_ANSWER;
    }

    public void setSubmitteD_ANSWER(String submitteD_ANSWER) {
        this.submitteD_ANSWER = submitteD_ANSWER;
    }

    public String getVieW_ANSWER() {
        return vieW_ANSWER;
    }

    public void setVieW_ANSWER(String vieW_ANSWER) {
        this.vieW_ANSWER = vieW_ANSWER;
    }
}
