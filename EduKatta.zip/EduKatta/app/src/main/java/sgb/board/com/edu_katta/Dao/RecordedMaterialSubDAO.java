package sgb.board.com.edu_katta.Dao;

public class RecordedMaterialSubDAO {

    private String list_title, list_titlelink, schedule, discuession_on_topic, download, assign_to_do, assign_ans,image;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getList_title() {
        return list_title;
    }

    public void setList_title(String list_title) {
        this.list_title = list_title;
    }

    public String getList_titlelink() {
        return list_titlelink;
    }

    public void setList_titlelink(String list_titlelink) {
        this.list_titlelink = list_titlelink;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public String getDiscuession_on_topic() {
        return discuession_on_topic;
    }

    public void setDiscuession_on_topic(String discuession_on_topic) {
        this.discuession_on_topic = discuession_on_topic;
    }

    public String getDownload() {
        return download;
    }

    public void setDownload(String download) {
        this.download = download;
    }

    public String getAssign_to_do() {
        return assign_to_do;
    }

    public void setAssign_to_do(String assign_to_do) {
        this.assign_to_do = assign_to_do;
    }

    public String getAssign_ans() {
        return assign_ans;
    }

    public void setAssign_ans(String assign_ans) {
        this.assign_ans = assign_ans;
    }
}
