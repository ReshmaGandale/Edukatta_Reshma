package sgb.board.com.edu_katta.Dao;

public class TestTypeSpinnerDAO {

    private String tesT_TOPIC,mocK_ID;

    public String getTesT_TOPIC() {
        return tesT_TOPIC;
    }

    public void setTesT_TOPIC(String tesT_TOPIC) {
        this.tesT_TOPIC = tesT_TOPIC;
    }

    public String getMocK_ID() {
        return mocK_ID;
    }

    public void setMocK_ID(String mocK_ID) {
        this.mocK_ID = mocK_ID;
    }
}
