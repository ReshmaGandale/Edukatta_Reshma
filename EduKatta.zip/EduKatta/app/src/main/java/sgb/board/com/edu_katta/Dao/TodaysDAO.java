package sgb.board.com.edu_katta.Dao;

public class TodaysDAO {

   private String teacheR_NAME, subject, schedule, discuessioN_ON_TOPIC, marK_ATTENDENCE, date, scheduleFormat,duration,from_time,to_time,image;
   private String teacheR_ID, tscH_DE_ID, studenT_ID,live,chat;

    public String getLive() {
        return live;
    }

    public void setLive(String live) {
        this.live = live;
    }

    public String getChat() {
        return chat;
    }

    public void setChat(String chat) {
        this.chat = chat;
    }

    public String getFrom_time() {
        return from_time;
    }

    public void setFrom_time(String from_time) {
        this.from_time = from_time;
    }

    public String getTo_time() {
        return to_time;
    }

    public void setTo_time(String to_time) {
        this.to_time = to_time;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTeacheR_NAME() {
        return teacheR_NAME;
    }

    public void setTeacheR_NAME(String teacheR_NAME) {
        this.teacheR_NAME = teacheR_NAME;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public String getDiscuessioN_ON_TOPIC() {
        return discuessioN_ON_TOPIC;
    }

    public void setDiscuessioN_ON_TOPIC(String discuessioN_ON_TOPIC) {
        this.discuessioN_ON_TOPIC = discuessioN_ON_TOPIC;
    }

    public String getMarK_ATTENDENCE() {
        return marK_ATTENDENCE;
    }

    public void setMarK_ATTENDENCE(String marK_ATTENDENCE) {
        this.marK_ATTENDENCE = marK_ATTENDENCE;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getScheduleFormat() {
        return scheduleFormat;
    }

    public void setScheduleFormat(String scheduleFormat) {
        this.scheduleFormat = scheduleFormat;
    }

    public String getTeacheR_ID() {
        return teacheR_ID;
    }

    public void setTeacheR_ID(String teacheR_ID) {
        this.teacheR_ID = teacheR_ID;
    }

    public String getTscH_DE_ID() {
        return tscH_DE_ID;
    }

    public void setTscH_DE_ID(String tscH_DE_ID) {
        this.tscH_DE_ID = tscH_DE_ID;
    }

    public String getStudenT_ID() {
        return studenT_ID;
    }

    public void setStudenT_ID(String studenT_ID) {
        this.studenT_ID = studenT_ID;
    }


    String name,time,topic;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
