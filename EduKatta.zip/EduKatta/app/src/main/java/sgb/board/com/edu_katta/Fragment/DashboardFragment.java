package sgb.board.com.edu_katta.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Activity.DashboardActivity;
import sgb.board.com.edu_katta.Activity.JeeMockTestActivity;
import sgb.board.com.edu_katta.Activity.NoticeListActivity;
import sgb.board.com.edu_katta.Adapter.DashBoardWeeklyTestAdapter;
import sgb.board.com.edu_katta.Adapter.DashboardAttendanceAdapter;
import sgb.board.com.edu_katta.Adapter.ExamPatternAdapters;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.LectureAttendanceDAO;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Session.SessionManager;
import sgb.board.com.edu_katta.Utils.RecycleViewClickListner;


public class DashboardFragment extends Fragment {
    DashBoardWeeklyTestAdapter dashBoardWeeklyTestAdapter;
    ExamPatternAdapters examPatternAdapters;
    List<String> weeklyTestData = new ArrayList<>();
    List<String> expammPattern = new ArrayList<>();

    View view;
    Context context;
    RecyclerView weeklyTest, mockTestRecycleView, syllabusRecycleView;

    LinearLayout lay_thisweeksession, lay_nextweeksession, lay_todaysession, lay_library_study, lay_library_recorded, lay_dpp_pending, lay_dpp_submitted;

    TextView txt_count_submitpaper, txt_count_pendingpaper;
    TextView txt_noticemarquee;

    String txt_JeeAdvance, txt_JeeMains, txt_Neet, txt_Mhcet;

    CardView crd_Mhcet, crd_Neet, crd_JeeMains, crd_JeeAdvance, crd_jeemock, crd_neetmock;

    ImageView img_profile;
    TextView txt_name, txt_bookdelivery, txt_contact, txt_college, txt_parent;

    RecyclerView rv_attendance, rv_assignment;

    private ArrayList<LectureAttendanceDAO> attendenceDAOS;
    private DashboardAttendanceAdapter attendenceAdapter;
    LectureAttendanceDAO attendenceDAO;

    private ArrayList<LectureAttendanceDAO> assignmentDAOS;
    private DashboardAttendanceAdapter assignmentAdapter;
    LectureAttendanceDAO assignmentDAO;

    SessionManager sessionManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        context = getActivity();

        sessionManager = new SessionManager(context);

        txt_name = (TextView) view.findViewById(R.id.txt_name);
        weeklyTest = view.findViewById(R.id.weeklyTest);
        txt_bookdelivery = (TextView) view.findViewById(R.id.txt_bookdelivery);
        txt_contact = (TextView) view.findViewById(R.id.txt_contact);
        txt_college = (TextView) view.findViewById(R.id.txt_college);
        txt_parent = (TextView) view.findViewById(R.id.txt_parent);
        mockTestRecycleView = view.findViewById(R.id.mockTestRecycleView);
        syllabusRecycleView = view.findViewById(R.id.syllabusRecycleView);

        weeklyTestData.add("NEET");
        weeklyTestData.add("NEET");
        weeklyTestData.add("NEET");
        weeklyTestData.add("NEET");
        weeklyTestData.add("NEET");
        weeklyTestData.add("NEET");

        expammPattern.add("JEE ADVANCE");
        expammPattern.add("JEE MAINS");
        expammPattern.add("NEET");
        expammPattern.add("MHT-CET");

        dashBoardWeeklyTestAdapter = new DashBoardWeeklyTestAdapter(weeklyTestData);
        weeklyTest.setAdapter(dashBoardWeeklyTestAdapter);
        mockTestRecycleView.setAdapter(dashBoardWeeklyTestAdapter);

        examPatternAdapters = new ExamPatternAdapters(getActivity(), expammPattern, new RecycleViewClickListner() {
            @Override
            public void onClick(View view, int position) {
                if (position == 0) {
                    if (txt_JeeAdvance.equalsIgnoreCase("")) {
                        Toast.makeText(context, "File Not Available", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(txt_JeeAdvance));
                        context.startActivity(browserIntent);
                    }
                } else if (position == 1) {
                    if (txt_JeeMains.equalsIgnoreCase("")) {
                        Toast.makeText(context, "File Not Available", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(txt_JeeMains));
                        context.startActivity(browserIntent);
                    }
                } else if (position == 2) {
                    if (txt_Neet.equalsIgnoreCase("")) {
                        Toast.makeText(context, "File Not Available", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(txt_Neet));
                        context.startActivity(browserIntent);
                    }
                } else if (position == 3) {
                    if (txt_JeeMains.equalsIgnoreCase("")) {
                        Toast.makeText(context, "File Not Available", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(txt_JeeMains));
                        context.startActivity(browserIntent);
                    }
                }

            }
        });
        syllabusRecycleView.setAdapter(examPatternAdapters);

        //        txt_attend_session = (TextView) view.findViewById(R.id.txt_attend_session);
//        txt_pending_session = (TextView) view.findViewById(R.id.txt_pending_session);
//        txt_submitted_paper = (TextView) view.findViewById(R.id.txt_submitted_paper);
//        txt_pending_paper = (TextView) view.findViewById(R.id.txt_pending_paper);
//        txt_lastscore = (TextView) view.findViewById(R.id.txt_lastscore);
//        txt_attendance = (TextView) view.findViewById(R.id.txt_attendance);

        img_profile = (ImageView) view.findViewById(R.id.img_profile);

        txt_noticemarquee = (TextView) view.findViewById(R.id.txt_noticemarquee);
        txt_noticemarquee.setSelected(true);


        txt_count_submitpaper = (TextView) view.findViewById(R.id.txt_count_submitpaper);
        txt_count_pendingpaper = (TextView) view.findViewById(R.id.txt_count_pendingpaper);

        lay_todaysession = (LinearLayout) view.findViewById(R.id.lay_todaysession);
        lay_nextweeksession = (LinearLayout) view.findViewById(R.id.lay_nextweeksession);
        lay_thisweeksession = (LinearLayout) view.findViewById(R.id.lay_thisweeksession);
        lay_library_study = (LinearLayout) view.findViewById(R.id.lay_library_study);
        lay_library_recorded = (LinearLayout) view.findViewById(R.id.lay_library_recorded);
        lay_dpp_pending = (LinearLayout) view.findViewById(R.id.lay_dpp_pending);
        lay_dpp_submitted = (LinearLayout) view.findViewById(R.id.lay_dpp_submitted);


        lay_todaysession.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, DashboardActivity.class);
                intent.putExtra("tabpos", "3");
                intent.putExtra("tabpos_second", "0");
                context.startActivity(intent);
            }
        });

        lay_thisweeksession.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, DashboardActivity.class);
                intent.putExtra("tabpos", "3");
                intent.putExtra("tabpos_second", "1");
                context.startActivity(intent);
            }
        });

        lay_nextweeksession.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, DashboardActivity.class);
                intent.putExtra("tabpos", "3");
                intent.putExtra("tabpos_second", "2");
                context.startActivity(intent);
            }
        });

        lay_library_study.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, DashboardActivity.class);
                intent.putExtra("tabpos", "4");
                intent.putExtra("tabpos_second", "0");
                context.startActivity(intent);
            }
        });

        lay_library_recorded.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, DashboardActivity.class);
                intent.putExtra("tabpos", "4");
                intent.putExtra("tabpos_second", "1");
                context.startActivity(intent);
            }
        });


        lay_dpp_pending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, DashboardActivity.class);
                intent.putExtra("tabpos", "5");
                intent.putExtra("tabpos_second", "0");
                context.startActivity(intent);
            }
        });

        lay_dpp_submitted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, DashboardActivity.class);
                intent.putExtra("tabpos", "5");
                intent.putExtra("tabpos_second", "1");
                context.startActivity(intent);
            }
        });

        txt_name.setText(DashboardActivity.StudentName);

        if (CheckConnection.haveNetworkConnection(context)) {
            getData();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

        if (CheckConnection.haveNetworkConnection(context)) {
            getNoticeData();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

        if (CheckConnection.haveNetworkConnection(context)) {
            getProfileData();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

        txt_noticemarquee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, NoticeListActivity.class);
                context.startActivity(intent);
            }
        });


        if (CheckConnection.haveNetworkConnection(context)) {
            getSyllabus();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }


        rv_attendance = view.findViewById(R.id.rv_attendance);
        attendenceDAOS = new ArrayList<>();
        attendenceAdapter = new DashboardAttendanceAdapter(context, attendenceDAOS);

        rv_attendance.setLayoutManager(new GridLayoutManager(context, 2));
        rv_attendance.setItemAnimator(new DefaultItemAnimator());
        rv_attendance.setNestedScrollingEnabled(false);

        rv_attendance.setAdapter(attendenceAdapter);

        if (CheckConnection.haveNetworkConnection(context)) {
            attendenceDAOS.clear();
            attendenceAdapter.notifyDataSetChanged();
            getattdanceData();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }


        rv_assignment = view.findViewById(R.id.rv_assignment);
        assignmentDAOS = new ArrayList<>();
        assignmentAdapter = new DashboardAttendanceAdapter(context, assignmentDAOS);

        rv_assignment.setLayoutManager(new GridLayoutManager(context, 2));
        rv_assignment.setItemAnimator(new DefaultItemAnimator());
        rv_assignment.setNestedScrollingEnabled(false);

        rv_assignment.setAdapter(assignmentAdapter);

        if (CheckConnection.haveNetworkConnection(context)) {
            assignmentDAOS.clear();
            assignmentAdapter.notifyDataSetChanged();
            getassignmentData();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

//        crd_jeemock.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(context, JeeMockTestActivity.class);
//                intent.putExtra("Type","JEE");
//                context.startActivity(intent);
//            }
//        });


        return view;
    }


    public void getattdanceData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", DashboardActivity.MobNo);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/subjectwisestudentattendance", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());
                    progressDialog.dismiss();
                    try {
                        if (response.length() > 0) {

                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);

                                attendenceDAO = new LectureAttendanceDAO();
                                attendenceDAO.setType("att");

                                if (String.valueOf(jsonObject.getString("subject")) == null || String.valueOf(jsonObject.getString("subject")).equalsIgnoreCase("null") || String.valueOf(jsonObject.getString("subject")).equalsIgnoreCase("")) {
                                    attendenceDAO.setSubject("");
                                } else {
                                    attendenceDAO.setSubject(String.valueOf(jsonObject.getString("subject")));
                                }

                                if (jsonObject.getString("total_lectures") == null || jsonObject.getString("total_lectures").equalsIgnoreCase("null") || jsonObject.getString("total_lectures").equalsIgnoreCase("")) {
                                    attendenceDAO.setTotal_lectures("0");
                                } else {
                                    attendenceDAO.setTotal_lectures(jsonObject.getString("total_lectures"));
                                }

                                if (jsonObject.getString("attendance") == null || jsonObject.getString("attendance").equalsIgnoreCase("null") || jsonObject.getString("attendance").equalsIgnoreCase("")) {
                                    attendenceDAO.setAttendance("0");
                                } else {
                                    attendenceDAO.setAttendance(jsonObject.getString("attendance"));
                                }

                                attendenceDAOS.add(attendenceDAO);
                            }

                            attendenceAdapter.notifyDataSetChanged();
                        } else {
                            attendenceAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            //Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        progressDialog.dismiss();
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getassignmentData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", DashboardActivity.MobNo);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/subjectwisestudentassignments", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());
                    progressDialog.dismiss();
                    try {
                        if (response.length() > 0) {

                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);

                                assignmentDAO = new LectureAttendanceDAO();
                                assignmentDAO.setType("ass");

                                if (String.valueOf(jsonObject.getString("subject")) == null || String.valueOf(jsonObject.getString("subject")).equalsIgnoreCase("null") || String.valueOf(jsonObject.getString("subject")).equalsIgnoreCase("")) {
                                    assignmentDAO.setSubject("");
                                } else {
                                    assignmentDAO.setSubject(String.valueOf(jsonObject.getString("subject")));
                                }

                                if (jsonObject.getString("assignments") == null || jsonObject.getString("assignments").equalsIgnoreCase("null") || jsonObject.getString("assignments").equalsIgnoreCase("")) {
                                    assignmentDAO.setAssignments("0");
                                } else {
                                    assignmentDAO.setAssignments(jsonObject.getString("assignments"));
                                }

                                if (jsonObject.getString("submitted_assignments") == null || jsonObject.getString("submitted_assignments").equalsIgnoreCase("null") || jsonObject.getString("submitted_assignments").equalsIgnoreCase("")) {
                                    assignmentDAO.setSubmitted_assignments("0");
                                } else {
                                    assignmentDAO.setSubmitted_assignments(jsonObject.getString("submitted_assignments"));
                                }

                                assignmentDAOS.add(assignmentDAO);
                            }

                            assignmentAdapter.notifyDataSetChanged();
                        } else {
                            assignmentAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            //Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        progressDialog.dismiss();
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", DashboardActivity.MobNo);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/dashboarddata", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());

                    try {
                        if (response.length() > 0) {
                            progressDialog.dismiss();

//                            if (response.getString("nO_OF_LECTURES")==null || response.getString("nO_OF_LECTURES").equalsIgnoreCase("null")||response.getString("nO_OF_LECTURES").equalsIgnoreCase(""))
//                            {
//
//                            }
//                            else
//                            {
//                                txt_attend_session.setText(String.valueOf(response.getString("nO_OF_LECTURES")));
//                            }
//                            if (response.getString("last_test")==null || response.getString("last_test").equalsIgnoreCase("null")||response.getString("last_test").equalsIgnoreCase(""))
//                            {
//
//                            }
//                            else
//                            {
//                                //txt_lastscore.setText(response.getString("last_test"));
//                                txt_lastscore.setText(Html.fromHtml(response.getString("last_test"), Html.FROM_HTML_MODE_COMPACT));
//                            }
//                            if (response.getString("lecturE_ATTEND")==null || response.getString("lecturE_ATTEND").equalsIgnoreCase("null")||response.getString("lecturE_ATTEND").equalsIgnoreCase(""))
//                            {
//
//                            }
//                            else
//                            {
//                                txt_pending_session.setText(String.valueOf(response.getString("lecturE_ATTEND")));
//                            }
                            if (response.getString("uploaD_ASSIGNMENT") == null || response.getString("uploaD_ASSIGNMENT").equalsIgnoreCase("null") || response.getString("uploaD_ASSIGNMENT").equalsIgnoreCase("")) {
                                txt_count_pendingpaper.setText("(0)");
                            } else {
                                // txt_pending_paper.setText(String.valueOf(response.getString("uploaD_ASSIGNMENT")));
                                txt_count_pendingpaper.setText("(" + response.getString("uploaD_ASSIGNMENT") + ")");
                            }
                            if (response.getString("submiT_ANSWER") == null || response.getString("submiT_ANSWER").equalsIgnoreCase("null") || response.getString("submiT_ANSWER").equalsIgnoreCase("")) {
                                txt_count_submitpaper.setText("(0)");
                            } else {
                                //txt_submitted_paper.setText(String.valueOf(response.getString("submiT_ANSWER")));
                                txt_count_submitpaper.setText("(" + response.getString("submiT_ANSWER") + ")");
                            }
//                            if (response.getString("totaL_ATTENDANCE")==null || response.getString("totaL_ATTENDANCE").equalsIgnoreCase("null")||response.getString("totaL_ATTENDANCE").equalsIgnoreCase(""))
//                            {
//
//                            }
//                            else
//                            {
//                                txt_attendance.setText(String.valueOf(response.getString("totaL_ATTENDANCE")));
//                            }

                        } else {

                            progressDialog.dismiss();
                            //Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getNoticeData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("limit", 5);
            jsonParams.put("page_no", 1);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/mjnoticelist", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());

                    try {
                        if (response.length() > 0) {
                            progressDialog.dismiss();

                            if (response.length() > 0) {
                                String st = "";
                                for (int i = 0; i < response.length(); i++) {
                                    JSONObject jsonObject = response.getJSONObject(i);

                                    if (jsonObject.getString("message") == null || jsonObject.getString("message").equalsIgnoreCase("null") || jsonObject.getString("message").equalsIgnoreCase("")) {
//                                        noticeDAO.setName("");
                                    } else {
                                        st = st.concat(jsonObject.getString("message"));
                                        st = st.concat("    |    ");
                                    }
                                }

                                txt_noticemarquee.setText(st);
                            }

                        } else {
                            progressDialog.dismiss();
                            // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getProfileData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", DashboardActivity.MobNo);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/studentprofiledetails", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());

                    try {
                        if (response.length() > 0) {
                            progressDialog.dismiss();

                            String pnm = "", pmob = "";

                            if (response.getString("studenT_NAME") == null || response.getString("studenT_NAME").equalsIgnoreCase("null") || response.getString("studenT_NAME").equalsIgnoreCase("")) {
                                txt_name.setText("");
                            } else {
                                txt_name.setText(String.valueOf(response.getString("studenT_NAME")));
                            }
                            if (response.getString("bookdeliveryaddress") == null || response.getString("bookdeliveryaddress").equalsIgnoreCase("null") || response.getString("bookdeliveryaddress").equalsIgnoreCase("")) {
                                txt_bookdelivery.setText("");
                            } else {
                                txt_bookdelivery.setText(Html.fromHtml(response.getString("bookdeliveryaddress"), Html.FROM_HTML_MODE_COMPACT));
                            }
                            if (response.getString("contacT_NO") == null || response.getString("contacT_NO").equalsIgnoreCase("null") || response.getString("contacT_NO").equalsIgnoreCase("")) {
                                txt_contact.setText("");
                            } else {
                                txt_contact.setText(String.valueOf(response.getString("contacT_NO")));
                            }
                            if (response.getString("collegE_NAME") == null || response.getString("collegE_NAME").equalsIgnoreCase("null") || response.getString("collegE_NAME").equalsIgnoreCase("")) {
                                txt_college.setText("");
                            } else {
                                txt_college.setText(String.valueOf(response.getString("collegE_NAME")));
                            }
                            if (response.getString("parentname") == null || response.getString("parentname").equalsIgnoreCase("null") || response.getString("parentname").equalsIgnoreCase("")) {
                            } else {
                                pnm = response.getString("parentname");
                            }
                            if (response.getString("parentmobile") == null || response.getString("parentmobile").equalsIgnoreCase("null") || response.getString("parentmobile").equalsIgnoreCase("")) {

                            } else {
                                pmob = response.getString("parentmobile");
                            }
                            if (response.getString("photo") == null || response.getString("photo").equalsIgnoreCase("null") || response.getString("photo").equalsIgnoreCase("")) {
                                sessionManager.setStuStuphoto("");
                            } else {
                                Glide.with(context).load(response.getString("photo")).into(img_profile);
                                sessionManager.setStuStuphoto(response.getString("photo"));
                            }

                            txt_parent.setText(pnm + " (" + pmob + ")");

                        } else {

                            progressDialog.dismiss();
                            //Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getSyllabus() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", DashboardActivity.MobNo);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/syllabuslist", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());

                    try {
                        if (response.length() > 0) {
                            progressDialog.dismiss();

                            if (response.length() > 0) {
                                for (int i = 0; i < response.length(); i++) {
                                    JSONObject jsonObject = response.getJSONObject(i);

                                    if (jsonObject.getString("name") == null || jsonObject.getString("name").equalsIgnoreCase("null") || jsonObject.getString("name").equalsIgnoreCase("")) {
                                    } else {
                                        if (jsonObject.getString("name").equalsIgnoreCase("jee advance 2022")) {
                                            if (jsonObject.getString("link") == null || jsonObject.getString("link").equalsIgnoreCase("null") || jsonObject.getString("link").equalsIgnoreCase("")) {
                                            } else {
                                                txt_JeeAdvance = jsonObject.getString("link");
                                            }
                                        } else if (jsonObject.getString("name").equalsIgnoreCase("jee main 2022")) {
                                            if (jsonObject.getString("link") == null || jsonObject.getString("link").equalsIgnoreCase("null") || jsonObject.getString("link").equalsIgnoreCase("")) {
                                            } else {
                                                txt_JeeMains= jsonObject.getString("link");
                                            }
                                        } else if (jsonObject.getString("name").equalsIgnoreCase("neet 2022")) {
                                            if (jsonObject.getString("link") == null || jsonObject.getString("link").equalsIgnoreCase("null") || jsonObject.getString("link").equalsIgnoreCase("")) {
                                            } else {
                                                txt_Neet= jsonObject.getString("link");
                                            }
                                        } else if (jsonObject.getString("name").equalsIgnoreCase("mht cet 2022")) {
                                            if (jsonObject.getString("link") == null || jsonObject.getString("link").equalsIgnoreCase("null") || jsonObject.getString("link").equalsIgnoreCase("")) {
                                            } else {
                                                txt_Mhcet= jsonObject.getString("link");
                                            }
                                        }

                                    }
                                }
                            }

                        } else {
                            progressDialog.dismiss();
                            // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
