package sgb.board.com.edu_katta.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.TimerTask;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import sgb.board.com.edu_katta.Activity.DashboardActivity;
import sgb.board.com.edu_katta.Activity.NoticeListActivity;
import sgb.board.com.edu_katta.Activity.StudentFeedbackVideoActivity;
import sgb.board.com.edu_katta.Adapter.DashboardContentAdapter;
import sgb.board.com.edu_katta.Adapter.DashboardMinisterAdapter;

import sgb.board.com.edu_katta.Adapter.HomeContentAdapters;
import sgb.board.com.edu_katta.Adapter.HomeFragStudentVideoAdapter;
import sgb.board.com.edu_katta.Adapter.HomeFragTeacherVideoAdapter;
import sgb.board.com.edu_katta.Adapter.SliderAdapter;
import sgb.board.com.edu_katta.Adapter.The_Slide_items_Pager_Adapter;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.HomeFragmentDAO;
import sgb.board.com.edu_katta.Dao.HomeFragmentDAO_2;
import sgb.board.com.edu_katta.Dao.HomeFragmentStuVideoDAO;
import sgb.board.com.edu_katta.Dao.HomeFragmentTeachVideoDAO;
import sgb.board.com.edu_katta.Models.HomePageContentModels;
import sgb.board.com.edu_katta.Models.HomeSliderModels;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Request.HomeSliderRequest;
import sgb.board.com.edu_katta.RxJavaRemote.ApiUtils;
import sgb.board.com.edu_katta.Server.Server;
import sgb.board.com.edu_katta.Utils.Utils;

public class HomeFragment extends Fragment implements View.OnClickListener {

    View view;
    Context context;

    TextView txt_prastavna, txt_kary, txt_noticemarquee;

    private RecyclerView rv_minister, rv_contentlist, rv_studentvideo, rv_teachdervideo;
    private ArrayList<HomeFragmentDAO> todaysDAOS;
    private DashboardMinisterAdapter todaysAdapter;
    HomeFragmentDAO todaysDAO;
    SliderAdapter sliderAdapter;
    HomeContentAdapters homeContentAdapters;
    List<HomeSliderModels.DataEntity> sliderData = new ArrayList<>();
    List<HomePageContentModels.DataEntity> contentData = new ArrayList<>();
    The_Slide_items_Pager_Adapter slide_items_pager_adapter;
    private ArrayList<HomeFragmentDAO_2> todaysDAOS2;
    private DashboardContentAdapter todaysAdapter2;
    HomeFragmentDAO_2 todaysDAO2;

    private ArrayList<HomeFragmentStuVideoDAO> studentDAOS;
    private HomeFragStudentVideoAdapter studentAdapter;
    HomeFragmentStuVideoDAO studentDAO;

    private ArrayList<HomeFragmentTeachVideoDAO> teachserDAOS;
    private HomeFragTeacherVideoAdapter teachserAdapter;
    HomeFragmentTeachVideoDAO teachserDAO;

    TextView newsmarqueeText, txt_viewall_student, txt_viewall_teacher;
    RecyclerView homePageContentRecycleView;
    ViewPager my_pager;
    TabLayout my_tablayout;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_home, container, false);
        homePageContentRecycleView = view.findViewById(R.id.homePageContentRecycleView);
        sliderDataLoad();
        homePageContentList();
        context = getActivity();
        newsmarqueeText = (TextView) view.findViewById(R.id.newsmarqueeText);
        my_pager = view.findViewById(R.id.my_pager);
        my_tablayout = view.findViewById(R.id.my_tablayout);
        newsmarqueeText.setSelected(true);

        txt_viewall_student = (TextView) view.findViewById(R.id.txt_viewall_student);
        txt_viewall_teacher = (TextView) view.findViewById(R.id.txt_viewall_teacher);
        txt_noticemarquee = (TextView) view.findViewById(R.id.txt_noticemarquee);

        txt_noticemarquee.setSelected(true);

        txt_viewall_student.setOnClickListener(this);
        txt_viewall_teacher.setOnClickListener(this);

        rv_minister = view.findViewById(R.id.rv_minister);
        todaysDAOS = new ArrayList<>();
        todaysAdapter = new DashboardMinisterAdapter(context, todaysDAOS);

        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        rv_minister.setLayoutManager(linearLayoutManager);
        rv_minister.setItemAnimator(new DefaultItemAnimator());
        rv_minister.setNestedScrollingEnabled(false);
        rv_minister.setAdapter(todaysAdapter);

        // The_slide_timer
        java.util.Timer timer = new java.util.Timer();
        //timer.scheduleAtFixedRate(new The_slide_timer(),2000,3000);
        my_tablayout.setupWithViewPager(my_pager,true);

        if (CheckConnection.haveNetworkConnection(context)) {
            todaysDAOS.clear();
            todaysAdapter.notifyDataSetChanged();
            getData();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

        rv_contentlist = view.findViewById(R.id.rv_contentlist);
        todaysDAOS2 = new ArrayList<>();
        todaysAdapter2 = new DashboardContentAdapter(context, todaysDAOS2);

        final LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        rv_contentlist.setLayoutManager(linearLayoutManager2);
        rv_contentlist.setItemAnimator(new DefaultItemAnimator());
        rv_contentlist.setNestedScrollingEnabled(false);
        rv_contentlist.setAdapter(todaysAdapter2);

        if (CheckConnection.haveNetworkConnection(context)) {
            todaysDAOS2.clear();
            todaysAdapter2.notifyDataSetChanged();
            getContentData();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

//        rv_notice = view.findViewById(R.id.rv_notice);
//        noticeDAOS = new ArrayList<>();
//        noticeAdapter = new DashboardNoticeAdapter(context, noticeDAOS);
//
//        final LinearLayoutManager linearLayoutManager3 = new LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false);
//        rv_notice.setLayoutManager(linearLayoutManager3);
//        rv_notice.setItemAnimator(new DefaultItemAnimator());
//        rv_notice.setNestedScrollingEnabled(false);
//        rv_notice.setAdapter(noticeAdapter);

        if (CheckConnection.haveNetworkConnection(context)) {
//            noticeDAOS.clear();
//            noticeAdapter.notifyDataSetChanged();
            getNewsData();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

        rv_studentvideo = view.findViewById(R.id.rv_studentvideo);
        studentDAOS = new ArrayList<>();
        studentAdapter = new HomeFragStudentVideoAdapter(rv_studentvideo, studentDAOS, context);

        final LinearLayoutManager linearLayoutManager3 = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        rv_studentvideo.setLayoutManager(linearLayoutManager3);
        rv_studentvideo.setItemAnimator(new DefaultItemAnimator());
        rv_studentvideo.setNestedScrollingEnabled(false);
        rv_studentvideo.setAdapter(studentAdapter);

        if (CheckConnection.haveNetworkConnection(context)) {
            studentDAOS.clear();
            studentAdapter.notifyDataSetChanged();
            getStudent();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

        rv_teachdervideo = view.findViewById(R.id.rv_teachdervideo);
        teachserDAOS = new ArrayList<>();
        teachserAdapter = new HomeFragTeacherVideoAdapter(rv_teachdervideo, teachserDAOS, context);

        final LinearLayoutManager linearLayoutManager4 = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        rv_teachdervideo.setLayoutManager(linearLayoutManager4);
        rv_teachdervideo.setItemAnimator(new DefaultItemAnimator());
        rv_teachdervideo.setNestedScrollingEnabled(false);
        rv_teachdervideo.setAdapter(teachserAdapter);

        if (CheckConnection.haveNetworkConnection(context)) {
            teachserDAOS.clear();
            teachserAdapter.notifyDataSetChanged();
            getTeacher();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

        if (CheckConnection.haveNetworkConnection(context)) {
            getNoticeData();
        } else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

        txt_noticemarquee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, NoticeListActivity.class);
                context.startActivity(intent);
            }
        });
        return view;
    }

    private void homePageContentList() {
        HomeSliderRequest homeSliderRequest = new HomeSliderRequest();
        homeSliderRequest.setMobile("9096799390");
        ApiUtils.getAPIService().HomePageContent(homeSliderRequest).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<HomePageContentModels>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                Utils.customMessage(getActivity(),e.getMessage());
            }

            @Override
            public void onNext(HomePageContentModels response) {
                if (response.getStatus()) {
                    if (response.getStatus()==true){
                        contentData=response.getData();
                        homeContentAdapters=new HomeContentAdapters(contentData);
                        homePageContentRecycleView.setAdapter(homeContentAdapters);

                    }
                }
            }
        });
    }

    private void sliderDataLoad() {
        HomeSliderRequest homeSliderRequest = new HomeSliderRequest();
        homeSliderRequest.setMobile("9096799390");
        ApiUtils.getAPIService().Slider(homeSliderRequest).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<HomeSliderModels>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                Toast.makeText(getActivity(), e.toString(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNext(HomeSliderModels response) {
                if (response.getStatus()) {
                    if (response.getData().size() > 0) {
                        sliderData = response.getData();
                        slide_items_pager_adapter=new The_Slide_items_Pager_Adapter(getActivity(),sliderData);
                        my_pager.setAdapter(slide_items_pager_adapter);

                    }
                }
            }
        });
    }

    public void getData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", DashboardActivity.MobNo);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/dashboarddata", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());

                    try {
                        if (response.length() > 0) {
                            progressDialog.dismiss();

                            JSONArray jsonArray = response.getJSONArray("governmenT_PANEL");
                            if (jsonArray.length() > 0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                                    todaysDAO = new HomeFragmentDAO();


                                    if (String.valueOf(jsonObject.getString("id")) == null || String.valueOf(jsonObject.getString("id")).equalsIgnoreCase("null") || String.valueOf(jsonObject.getString("id")).equalsIgnoreCase("")) {
                                        todaysDAO.setId("");
                                    } else {
                                        todaysDAO.setId(String.valueOf(jsonObject.getString("id")));
                                    }

                                    if (jsonObject.getString("name") == null || jsonObject.getString("name").equalsIgnoreCase("null") || jsonObject.getString("name").equalsIgnoreCase("")) {
                                        todaysDAO.setName("");
                                    } else {
                                        todaysDAO.setName(jsonObject.getString("name"));
                                    }

                                    if (jsonObject.getString("post") == null || jsonObject.getString("post").equalsIgnoreCase("null") || jsonObject.getString("post").equalsIgnoreCase("")) {
                                        todaysDAO.setPost("");
                                    } else {
                                        todaysDAO.setPost(jsonObject.getString("post"));
                                    }

                                    if (jsonObject.getString("description") == null || jsonObject.getString("description").equalsIgnoreCase("null") || jsonObject.getString("description").equalsIgnoreCase("")) {
                                        todaysDAO.setDescription("");
                                    } else {
                                        todaysDAO.setDescription(jsonObject.getString("description"));
                                    }

                                    if (jsonObject.getString("photo") == null || jsonObject.getString("photo").equalsIgnoreCase("null") || jsonObject.getString("photo").equalsIgnoreCase("")) {
                                        todaysDAO.setPhoto("");
                                    } else {
                                        todaysDAO.setPhoto(jsonObject.getString("photo"));
                                    }

                                    todaysDAOS.add(todaysDAO);
                                }

                                todaysAdapter.notifyDataSetChanged();
                            }

                        } else {
                            todaysAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            //Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getContentData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", DashboardActivity.MobNo);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/dashboarddata", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());

                    try {
                        if (response.length() > 0) {
                            progressDialog.dismiss();

                            JSONArray jsonArray = response.getJSONArray("schemes");
                            if (jsonArray.length() > 0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                                    todaysDAO2 = new HomeFragmentDAO_2();


                                    if (String.valueOf(jsonObject.getString("id")) == null || String.valueOf(jsonObject.getString("id")).equalsIgnoreCase("null") || String.valueOf(jsonObject.getString("id")).equalsIgnoreCase("")) {
                                        todaysDAO2.setId("");
                                    } else {
                                        todaysDAO2.setId(String.valueOf(jsonObject.getString("id")));
                                    }

                                    if (jsonObject.getString("name") == null || jsonObject.getString("name").equalsIgnoreCase("null") || jsonObject.getString("name").equalsIgnoreCase("")) {
                                        todaysDAO2.setName("");
                                    } else {
                                        todaysDAO2.setName(jsonObject.getString("name"));
                                    }

                                    if (jsonObject.getString("description") == null || jsonObject.getString("description").equalsIgnoreCase("null") || jsonObject.getString("description").equalsIgnoreCase("")) {
                                        todaysDAO2.setDescription("");
                                    } else {
                                        todaysDAO2.setDescription(jsonObject.getString("description"));
                                    }

                                    todaysDAOS2.add(todaysDAO2);
                                }

                                todaysAdapter2.notifyDataSetChanged();
                            }

                        } else {
                            todaysAdapter2.notifyDataSetChanged();
                            progressDialog.dismiss();
                            //Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getNewsData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", DashboardActivity.MobNo);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/dashboarddata", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());

                    try {
                        if (response.length() > 0) {
                            progressDialog.dismiss();

                            JSONArray jsonArray = response.getJSONArray("newslist");
                            if (jsonArray.length() > 0) {
                                String st = "";
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                                    if (jsonObject.getString("name") == null || jsonObject.getString("name").equalsIgnoreCase("null") || jsonObject.getString("name").equalsIgnoreCase("")) {
//                                        noticeDAO.setName("");
                                    } else {
//                                        noticeDAO.setName(jsonObject.getString("name"));
                                        st = st.concat(jsonObject.getString("name"));
                                        st = st.concat("    |    ");
                                    }

                                }

                                newsmarqueeText.setText(st);
//                                noticeAdapter.notifyDataSetChanged();
                            }

                        } else {
//                            noticeAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            //Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getStudent() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("limit", 5);
            jsonParams.put("page_no", 1);
            jsonParams.put("type", "Feedback");
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/videomaster", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());
                    progressDialog.dismiss();
                    try {
                        if (response.length() > 0) {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);

                                studentDAO = new HomeFragmentStuVideoDAO();

                                if (String.valueOf(jsonObject.getString("id")) == null || String.valueOf(jsonObject.getString("id")).equalsIgnoreCase("null") || String.valueOf(jsonObject.getString("id")).equalsIgnoreCase("")) {
                                    studentDAO.setId("");
                                } else {
                                    studentDAO.setId(String.valueOf(jsonObject.getString("id")));
                                }
                                if (jsonObject.getString("name") == null || jsonObject.getString("name").equalsIgnoreCase("null") || jsonObject.getString("name").equalsIgnoreCase("")) {
                                    studentDAO.setName("");
                                } else {
                                    studentDAO.setName(jsonObject.getString("name"));
                                }
                                if (jsonObject.getString("description") == null || jsonObject.getString("description").equalsIgnoreCase("null") || jsonObject.getString("description").equalsIgnoreCase("")) {
                                    studentDAO.setDescription("");
                                } else {
                                    studentDAO.setDescription(jsonObject.getString("description"));
                                }
                                if (jsonObject.getString("videolink") == null || jsonObject.getString("videolink").equalsIgnoreCase("null") || jsonObject.getString("videolink").equalsIgnoreCase("")) {
                                    studentDAO.setVideolink("");
                                } else {
                                    studentDAO.setVideolink(jsonObject.getString("videolink"));
                                }
                                if (jsonObject.getString("type") == null || jsonObject.getString("type").equalsIgnoreCase("null") || jsonObject.getString("type").equalsIgnoreCase("")) {
                                    studentDAO.setType("");
                                } else {
                                    studentDAO.setType(jsonObject.getString("type"));
                                }
                                if (jsonObject.getString("videoimage") == null || jsonObject.getString("videoimage").equalsIgnoreCase("null") || jsonObject.getString("videoimage").equalsIgnoreCase("")) {
                                    studentDAO.setVideoimage("");
                                } else {
                                    studentDAO.setVideoimage(jsonObject.getString("videoimage"));
                                }


                                studentDAOS.add(studentDAO);
                            }

                            studentAdapter.notifyDataSetChanged();
                        } else {
                            studentAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            //  Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getTeacher() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("limit", 5);
            jsonParams.put("page_no", 1);
            jsonParams.put("type", "Motivational");
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/videomaster", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());
                    progressDialog.dismiss();
                    try {
                        if (response.length() > 0) {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);

                                teachserDAO = new HomeFragmentTeachVideoDAO();

                                if (String.valueOf(jsonObject.getString("id")) == null || String.valueOf(jsonObject.getString("id")).equalsIgnoreCase("null") || String.valueOf(jsonObject.getString("id")).equalsIgnoreCase("")) {
                                    teachserDAO.setId("");
                                } else {
                                    teachserDAO.setId(String.valueOf(jsonObject.getString("id")));
                                }
                                if (jsonObject.getString("name") == null || jsonObject.getString("name").equalsIgnoreCase("null") || jsonObject.getString("name").equalsIgnoreCase("")) {
                                    teachserDAO.setName("");
                                } else {
                                    teachserDAO.setName(jsonObject.getString("name"));
                                }
                                if (jsonObject.getString("description") == null || jsonObject.getString("description").equalsIgnoreCase("null") || jsonObject.getString("description").equalsIgnoreCase("")) {
                                    teachserDAO.setDescription("");
                                } else {
                                    teachserDAO.setDescription(jsonObject.getString("description"));
                                }
                                if (jsonObject.getString("videolink") == null || jsonObject.getString("videolink").equalsIgnoreCase("null") || jsonObject.getString("videolink").equalsIgnoreCase("")) {
                                    teachserDAO.setVideolink("");
                                } else {
                                    teachserDAO.setVideolink(jsonObject.getString("videolink"));
                                }
                                if (jsonObject.getString("type") == null || jsonObject.getString("type").equalsIgnoreCase("null") || jsonObject.getString("type").equalsIgnoreCase("")) {
                                    teachserDAO.setType("");
                                } else {
                                    teachserDAO.setType(jsonObject.getString("type"));
                                }
                                if (jsonObject.getString("videoimage") == null || jsonObject.getString("videoimage").equalsIgnoreCase("null") || jsonObject.getString("videoimage").equalsIgnoreCase("")) {
                                    teachserDAO.setVideoimage("");
                                } else {
                                    teachserDAO.setVideoimage(jsonObject.getString("videoimage"));
                                }


                                teachserDAOS.add(teachserDAO);
                            }

                            teachserAdapter.notifyDataSetChanged();
                        } else {
                            teachserAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void getNoticeData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("limit", 5);
            jsonParams.put("page_no", 1);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para", entity.toString());
            Log.e("para....", jsonParams.toString());
            Server.post(context, "", entity, "Data/mjnoticelist", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..", ".." + response.length());

                    try {
                        if (response.length() > 0) {
                            progressDialog.dismiss();

                            if (response.length() > 0) {
                                String st = "";
                                for (int i = 0; i < response.length(); i++) {
                                    JSONObject jsonObject = response.getJSONObject(i);

                                    if (jsonObject.getString("message") == null || jsonObject.getString("message").equalsIgnoreCase("null") || jsonObject.getString("message").equalsIgnoreCase("")) {
//                                        noticeDAO.setName("");
                                    } else {
                                        st = st.concat(jsonObject.getString("message"));
                                        st = st.concat("    |    ");
                                    }
                                }

                                txt_noticemarquee.setText(st);
                            }

                        } else {
                            progressDialog.dismiss();
                            //Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is", ".." + responseString.toString());
                    Toast.makeText(context, "Error occured", Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onClick(View v) {

        if (v == txt_viewall_student) {
            Intent intent = new Intent(context, StudentFeedbackVideoActivity.class);
            intent.putExtra("type", "Feedback");
            context.startActivity(intent);
        }
        if (v == txt_viewall_teacher) {
            Intent intent = new Intent(context, StudentFeedbackVideoActivity.class);
            intent.putExtra("type", "Motivational");
            context.startActivity(intent);
        }
    }

    public class The_slide_timer extends TimerTask {
        @Override
        public void run() {

            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (my_pager.getCurrentItem()< sliderData.size()-1) {
                        my_pager.setCurrentItem(my_pager.getCurrentItem()+1);
                    }
                    else
                        my_pager.setCurrentItem(0);
                }
            });
        }
    }
}
