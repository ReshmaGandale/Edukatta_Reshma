package sgb.board.com.edu_katta.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import sgb.board.com.edu_katta.Activity.DashboardActivity;
import sgb.board.com.edu_katta.Adapter.LibraryTabAdapter;
import sgb.board.com.edu_katta.R;


public class LibraryFragment extends Fragment {

    View view;
    Context context;

    TabLayout tab_layout;
    LibraryTabAdapter adapter;
    ViewPager viewPager;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_library, container, false);

        context = getActivity();

        tab_layout = (TabLayout) view.findViewById(R.id.tab_layout2);

        tab_layout.addTab(tab_layout.newTab().setText("Study Material"));
        tab_layout.addTab(tab_layout.newTab().setText("Recorded Session"));


        tab_layout.setTabGravity(TabLayout.GRAVITY_FILL);

        viewPager = (ViewPager) view.findViewById(R.id.pager2);

        adapter = new LibraryTabAdapter(getChildFragmentManager(), tab_layout.getTabCount());
        viewPager.setAdapter(adapter);

        if(DashboardActivity.TabPos_Second>0)
        {
            new Handler().postDelayed(
                    new Runnable(){
                        @Override
                        public void run() {
                            tab_layout.getTabAt(1).select();
                        }
                    }, 50);
        }

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tab_layout));
        tab_layout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                if(DashboardActivity.TabPos_Second>0)
                {
                    new Handler().postDelayed(
                            new Runnable(){
                                @Override
                                public void run() {
                                    viewPager.setCurrentItem(1);
                                    tab_layout.getTabAt(1).select();
                                    tab_layout.setScrollPosition(1, 0, true);
                                }
                            }, 50);
                }
                else
                {
                    viewPager.setCurrentItem(tab.getPosition());
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                //tab.getIcon().setTint(R.color.white);
                DashboardActivity.TabPos_Second=-1;
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                //tab.getIcon().setTint(R.color.white);
                DashboardActivity.TabPos_Second=-1;
            }
        });


        return view;
    }
}
