package sgb.board.com.edu_katta.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import sgb.board.com.edu_katta.Activity.DashboardActivity;
import sgb.board.com.edu_katta.Adapter.SessionTabAdapter;
import sgb.board.com.edu_katta.R;


public class SessionFragment extends Fragment {

    View view3;
    Context context;

    TabLayout tab_layout3;
    SessionTabAdapter adapter3;
    ViewPager viewPager3;
    int po = 0;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view3 =  inflater.inflate(R.layout.fragment_session, container, false);

        tab_layout3 = (TabLayout) view3.findViewById(R.id.tab_layout3);

        context = getActivity();

        tab_layout3.addTab(tab_layout3.newTab().setText("Today's Session"));
        tab_layout3.addTab(tab_layout3.newTab().setText("This Week Session"));
        tab_layout3.addTab(tab_layout3.newTab().setText("Next Week Session"));


        tab_layout3.setTabGravity(TabLayout.GRAVITY_FILL);

        viewPager3 = (ViewPager) view3.findViewById(R.id.pager3);

        adapter3 = new SessionTabAdapter(getChildFragmentManager(), tab_layout3.getTabCount());
        viewPager3.setAdapter(adapter3);

        Log.e("tab.sec..",".."+DashboardActivity.TabPos_Second);
        po = DashboardActivity.TabPos_Second;
        if(po>0)
        {
            new Handler().postDelayed(
                    new Runnable(){
                        @Override
                        public void run() {
                           // tab_layout3.getTabAt(DashboardActivity.TabPos_Second).select();
                            tab_layout3.getTabAt(po).select();
                        }
                    }, 50);

        }

        viewPager3.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tab_layout3));
        tab_layout3.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                if(po>0)
                {
                    new Handler().postDelayed(
                            new Runnable(){
                                @Override
                                public void run() {
                                    viewPager3.setCurrentItem(po);
                                    tab_layout3.getTabAt(po).select();
                                    tab_layout3.setScrollPosition(po, 0, true);
                                }
                            }, 50);

                }
                else
                {
                    viewPager3.setCurrentItem(tab.getPosition());
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                //tab.getIcon().setTint(R.color.white);
                DashboardActivity.TabPos_Second = -1;
                po = 0;
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                //tab.getIcon().setTint(R.color.white);
                DashboardActivity.TabPos_Second=-1;
                po = 0;
            }
        });

       return view3;
    }
}