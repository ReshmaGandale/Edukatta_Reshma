package sgb.board.com.edu_katta.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;

public class SubmittedPaperFragment extends Fragment {

    View view;
    Context context;
    CardView crd_math,crd_physics,crd_chemistry,crd_botny,crd_zoology,crd_project;
    TextView txt_math,txt_physics,txt_chemistry,txt_botny,txt_zoology,txt_project;
    TextView txt_math_id,txt_physics_id,txt_chemistry_id,txt_botny_id,txt_zoology_id,txt_project_id;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_submitted_paper, container, false);

        context = getActivity();

        crd_math = view.findViewById(R.id.crd_math);
        crd_physics = view.findViewById(R.id.crd_physics);
        crd_chemistry = view.findViewById(R.id.crd_chemistry);
        crd_botny = view.findViewById(R.id.crd_botny);
        crd_zoology = view.findViewById(R.id.crd_zoology);
        crd_project = view.findViewById(R.id.crd_project);

        txt_math = view.findViewById(R.id.txt_math);
        txt_physics = view.findViewById(R.id.txt_physics);
        txt_chemistry = view.findViewById(R.id.txt_chemistry);
        txt_zoology = view.findViewById(R.id.txt_zoology);
        txt_botny = view.findViewById(R.id.txt_botny);
        txt_project = view.findViewById(R.id.txt_project);

        txt_math_id = view.findViewById(R.id.txt_math_id);
        txt_physics_id = view.findViewById(R.id.txt_physics_id);
        txt_chemistry_id = view.findViewById(R.id.txt_chemistry_id);
        txt_zoology_id = view.findViewById(R.id.txt_zoology_id);
        txt_botny_id = view.findViewById(R.id.txt_botny_id);
        txt_project_id = view.findViewById(R.id.txt_project_id);



        crd_math.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(context, StudyMaterialSubjectActivity.class);
//                context.startActivity(intent);
            }
        });

        crd_physics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(context, StudyMaterialSubjectActivity.class);
//                context.startActivity(intent);
            }
        });

        crd_chemistry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(context, StudyMaterialSubjectActivity.class);
//                context.startActivity(intent);
            }
        });

        crd_botny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(context, StudyMaterialSubjectActivity.class);
//                context.startActivity(intent);
            }
        });

        crd_zoology.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(context, StudyMaterialSubjectActivity.class);
//                context.startActivity(intent);
            }
        });

        crd_project.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(context, StudyMaterialSubjectActivity.class);
//                context.startActivity(intent);
            }
        });

        getData();

        return view;
    }

    public void getData() {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE","9096799390");
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(context,"",entity,"Data/subjectlist", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());
                    progressDialog.dismiss();
                    try
                    {
                        if(response.length()>0)
                        {


                            for (int i = 0; i < 6; i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                Log.e("data..",".."+jsonObject.getString("subject"));

                                if(i==0)
                                {
                                    if (jsonObject.getString("subject")==null || jsonObject.getString("subject").equalsIgnoreCase("null")||jsonObject.getString("subject").equalsIgnoreCase(""))
                                    {
                                        txt_math.setText("");
                                    }
                                    else
                                    {
                                        txt_math.setText(jsonObject.getString("subject"));
                                    }
                                    if (jsonObject.getString("mjmS_ID")==null || jsonObject.getString("mjmS_ID").equalsIgnoreCase("null")||jsonObject.getString("mjmS_ID").equalsIgnoreCase(""))
                                    {
                                        txt_math_id.setText("");
                                    }
                                    else
                                    {
                                        txt_math_id.setText(String.valueOf(jsonObject.getString("mjmS_ID")));
                                    }
                                }
                                else if(i==1)
                                {
                                    if (jsonObject.getString("subject")==null || jsonObject.getString("subject").equalsIgnoreCase("null")||jsonObject.getString("subject").equalsIgnoreCase(""))
                                    {
                                        txt_project.setText("");
                                    }
                                    else
                                    {
                                        txt_project.setText(jsonObject.getString("subject"));
                                    }
                                    if (jsonObject.getString("mjmS_ID")==null || jsonObject.getString("mjmS_ID").equalsIgnoreCase("null")||jsonObject.getString("mjmS_ID").equalsIgnoreCase(""))
                                    {
                                        txt_project_id.setText("");
                                    }
                                    else
                                    {
                                        txt_project_id.setText(String.valueOf(jsonObject.getString("mjmS_ID")));
                                    }
                                }
                                else if(i==2)
                                {
                                    if (jsonObject.getString("subject")==null || jsonObject.getString("subject").equalsIgnoreCase("null")||jsonObject.getString("subject").equalsIgnoreCase(""))
                                    {
                                        txt_physics.setText("");
                                    }
                                    else
                                    {
                                        txt_physics.setText(jsonObject.getString("subject"));
                                    }
                                    if (jsonObject.getString("mjmS_ID")==null || jsonObject.getString("mjmS_ID").equalsIgnoreCase("null")||jsonObject.getString("mjmS_ID").equalsIgnoreCase(""))
                                    {
                                        txt_physics_id.setText("");
                                    }
                                    else
                                    {
                                        txt_physics_id.setText(String.valueOf(jsonObject.getString("mjmS_ID")));
                                    }
                                }
                                else if(i==3)
                                {
                                    if (jsonObject.getString("subject")==null || jsonObject.getString("subject").equalsIgnoreCase("null")||jsonObject.getString("subject").equalsIgnoreCase(""))
                                    {
                                        txt_zoology.setText("");
                                    }
                                    else
                                    {
                                        txt_zoology.setText(jsonObject.getString("subject"));
                                    }
                                    if (jsonObject.getString("mjmS_ID")==null || jsonObject.getString("mjmS_ID").equalsIgnoreCase("null")||jsonObject.getString("mjmS_ID").equalsIgnoreCase(""))
                                    {
                                        txt_zoology_id.setText("");
                                    }
                                    else
                                    {
                                        txt_zoology_id.setText(String.valueOf(jsonObject.getString("mjmS_ID")));
                                    }
                                }
                                else if(i==4)
                                {
                                    if (jsonObject.getString("subject")==null || jsonObject.getString("subject").equalsIgnoreCase("null")||jsonObject.getString("subject").equalsIgnoreCase(""))
                                    {
                                        txt_chemistry.setText("");
                                    }
                                    else
                                    {
                                        txt_chemistry.setText(jsonObject.getString("subject"));
                                    }
                                    if (jsonObject.getString("mjmS_ID")==null || jsonObject.getString("mjmS_ID").equalsIgnoreCase("null")||jsonObject.getString("mjmS_ID").equalsIgnoreCase(""))
                                    {
                                        txt_chemistry_id.setText("");
                                    }
                                    else
                                    {
                                        txt_chemistry_id.setText(String.valueOf(jsonObject.getString("mjmS_ID")));
                                    }
                                }
                                else if(i==5)
                                {
                                    if (jsonObject.getString("subject")==null || jsonObject.getString("subject").equalsIgnoreCase("null")||jsonObject.getString("subject").equalsIgnoreCase(""))
                                    {
                                        txt_botny.setText("");
                                    }
                                    else
                                    {
                                        txt_botny.setText(jsonObject.getString("subject"));
                                    }
                                    if (jsonObject.getString("mjmS_ID")==null || jsonObject.getString("mjmS_ID").equalsIgnoreCase("null")||jsonObject.getString("mjmS_ID").equalsIgnoreCase(""))
                                    {
                                        txt_botny_id.setText("");
                                    }
                                    else
                                    {
                                        txt_botny_id.setText(String.valueOf(jsonObject.getString("mjmS_ID")));
                                    }
                                }
                                else
                                {
                                }
                            }

                        }
                        else {
                            progressDialog.dismiss();
                            //Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(context, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }

}