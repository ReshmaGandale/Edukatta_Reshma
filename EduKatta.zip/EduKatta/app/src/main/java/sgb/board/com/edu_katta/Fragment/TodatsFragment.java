package sgb.board.com.edu_katta.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Activity.DashboardActivity;
import sgb.board.com.edu_katta.Adapter.TodaysAdapter;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.TodaysDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;


public class TodatsFragment extends Fragment {

    Context context;
    View view;

    private RecyclerView rv_list;
    private ArrayList<TodaysDAO> todaysDAOS;
    private TodaysAdapter todaysAdapter;
    TodaysDAO todaysDAO;

    private int index1 = 0,end = 10;
    private int count1=0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_todays, container, false);
        context = getActivity();

        rv_list = view.findViewById(R.id.rv_list);
        todaysDAOS = new ArrayList<>();
        //todaysAdapter = new TodaysAdapter(rv_list,todaysDAOS,context);

//        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(context);
//        rv_list.setLayoutManager(mLayoutManager);
//        rv_list.setItemAnimator(new DefaultItemAnimator());

        rv_list.setLayoutManager(new GridLayoutManager(context,1));
        rv_list.setItemAnimator(new DefaultItemAnimator());
        rv_list.setNestedScrollingEnabled(false);


        todaysAdapter = new TodaysAdapter(rv_list,todaysDAOS,context);
        todaysAdapter.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                todaysDAOS.add(null);
                todaysAdapter.notifyItemInserted(todaysDAOS.size() - 1);
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        index1 = todaysDAOS.size();
                        end = index1 + 10;
                        count1 = count1 + 1;
                        if (CheckConnection.haveNetworkConnection(context))
                        {
                            getData(count1);
                        }
                        else {
                            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });

        if (CheckConnection.haveNetworkConnection(context))
        {
            index1 = 0;
            count1=1;
            todaysDAOS.clear();
            todaysAdapter.notifyDataSetChanged();

            getData(count1);
        }
        else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }



        return view;
    }


    public void getData(int count) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", DashboardActivity.MobNo);
            jsonParams.put("SUBJECT",221);
            jsonParams.put("limit",10);
            jsonParams.put("page_no",count);
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(context,"",entity,"Data/todayslectures", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if (index1 != 0) {
                            todaysDAOS.remove(todaysDAOS.size() - 1);
                            todaysAdapter.notifyItemRemoved(todaysDAOS.size());
                        }

                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                todaysDAO = new TodaysDAO();

                                if (jsonObject.getString("teacheR_NAME")==null || jsonObject.getString("teacheR_NAME").equalsIgnoreCase("null")||jsonObject.getString("teacheR_NAME").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setTeacheR_NAME("");
                                }
                                else
                                {
                                    todaysDAO.setTeacheR_NAME(jsonObject.getString("teacheR_NAME"));
                                }
                                if (jsonObject.getString("subject")==null || jsonObject.getString("subject").equalsIgnoreCase("null")||jsonObject.getString("subject").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setSubject("");
                                }
                                else
                                {
                                    todaysDAO.setSubject(jsonObject.getString("subject"));
                                }
                                if (jsonObject.getString("schedule")==null || jsonObject.getString("schedule").equalsIgnoreCase("null")||jsonObject.getString("schedule").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setSchedule("");
                                }
                                else
                                {
                                    todaysDAO.setSchedule(jsonObject.getString("schedule"));
                                }
                                if (jsonObject.getString("discuessioN_ON_TOPIC")==null || jsonObject.getString("discuessioN_ON_TOPIC").equalsIgnoreCase("null")||jsonObject.getString("discuessioN_ON_TOPIC").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setDiscuessioN_ON_TOPIC("");
                                }
                                else
                                {
                                    todaysDAO.setDiscuessioN_ON_TOPIC(jsonObject.getString("discuessioN_ON_TOPIC"));
                                }
                                if (jsonObject.getString("marK_ATTENDENCE")==null || String.valueOf(jsonObject.getString("marK_ATTENDENCE")).equalsIgnoreCase("null")|| String.valueOf(jsonObject.getString("marK_ATTENDENCE")).equalsIgnoreCase(""))
                                {
                                    todaysDAO.setMarK_ATTENDENCE("");
                                }
                                else
                                {
                                    todaysDAO.setMarK_ATTENDENCE(String.valueOf(jsonObject.getString("marK_ATTENDENCE")));
                                }
                                if (jsonObject.getString("date")==null || String.valueOf(jsonObject.getString("date")).equalsIgnoreCase("null")|| String.valueOf(jsonObject.getString("date")).equalsIgnoreCase(""))
                                {
                                    todaysDAO.setDate("");
                                }
                                else
                                {
                                    todaysDAO.setDate(String.valueOf(jsonObject.getString("date")));
                                }
                                if (jsonObject.getString("scheduleFormat")==null || String.valueOf(jsonObject.getString("scheduleFormat")).equalsIgnoreCase("null")||String.valueOf(jsonObject.getString("scheduleFormat")).equalsIgnoreCase(""))
                                {
                                    todaysDAO.setScheduleFormat("");
                                }
                                else
                                {
                                    todaysDAO.setScheduleFormat(String.valueOf(jsonObject.getString("scheduleFormat")));
                                }
                                if (jsonObject.getString("teacheR_ID")==null || jsonObject.getString("teacheR_ID").equalsIgnoreCase("null")||jsonObject.getString("teacheR_ID").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setTeacheR_ID("");
                                }
                                else
                                {
                                    todaysDAO.setTeacheR_ID(jsonObject.getString("teacheR_ID"));
                                }
                                if (jsonObject.getString("tscH_DE_ID")==null || jsonObject.getString("tscH_DE_ID").equalsIgnoreCase("null")||jsonObject.getString("tscH_DE_ID").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setTscH_DE_ID("");
                                }
                                else
                                {
                                    todaysDAO.setTscH_DE_ID(jsonObject.getString("tscH_DE_ID"));
                                }
                                if (jsonObject.getString("studenT_ID")==null || jsonObject.getString("studenT_ID").equalsIgnoreCase("null")||jsonObject.getString("studenT_ID").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setStudenT_ID("");
                                }
                                else
                                {
                                    todaysDAO.setStudenT_ID(jsonObject.getString("studenT_ID"));
                                }

                                if (jsonObject.getString("duration")==null || jsonObject.getString("duration").equalsIgnoreCase("null")||jsonObject.getString("duration").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setDuration("");
                                }
                                else
                                {
                                    todaysDAO.setDuration(jsonObject.getString("duration"));
                                }
                                if (jsonObject.getString("from_time")==null || jsonObject.getString("from_time").equalsIgnoreCase("null")||jsonObject.getString("from_time").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setFrom_time("");
                                }
                                else
                                {
                                    todaysDAO.setFrom_time(jsonObject.getString("from_time"));
                                }
                                if (jsonObject.getString("to_time")==null || jsonObject.getString("to_time").equalsIgnoreCase("null")||jsonObject.getString("to_time").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setTo_time("");
                                }
                                else
                                {
                                    todaysDAO.setTo_time(jsonObject.getString("to_time"));
                                }
                                if (jsonObject.getString("image")==null || jsonObject.getString("image").equalsIgnoreCase("null")||jsonObject.getString("image").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setImage("");
                                }
                                else
                                {
                                    todaysDAO.setImage(jsonObject.getString("image"));
                                }

                                if (jsonObject.getString("live")==null || jsonObject.getString("live").equalsIgnoreCase("null")||jsonObject.getString("live").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setLive("");
                                }
                                else
                                {
                                    todaysDAO.setLive(jsonObject.getString("live"));
                                }

                                if (jsonObject.getString("chat")==null || jsonObject.getString("chat").equalsIgnoreCase("null")||jsonObject.getString("chat").equalsIgnoreCase(""))
                                {
                                    todaysDAO.setChat("");
                                }
                                else
                                {
                                    todaysDAO.setChat(jsonObject.getString("chat"));
                                }

                                todaysDAOS.add(todaysDAO);
                            }


                            if (index1 == 0 && end == 10)
                            {
                                rv_list.setAdapter(todaysAdapter);
                            }else{
                                Log.e("index and end",index1+","+end);
                            }
                            todaysAdapter.notifyDataSetChanged();
                            todaysAdapter.setLoaded();

                        }
                        else {
                            todaysAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                           // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(context, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
