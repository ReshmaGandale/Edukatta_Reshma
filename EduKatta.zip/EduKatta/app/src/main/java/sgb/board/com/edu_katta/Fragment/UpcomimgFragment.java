package sgb.board.com.edu_katta.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.ParseException;
import cz.msebera.android.httpclient.entity.StringEntity;
import sgb.board.com.edu_katta.Activity.DashboardActivity;
import sgb.board.com.edu_katta.Adapter.UpcomingAdapter;
import sgb.board.com.edu_katta.Custom.CheckConnection;
import sgb.board.com.edu_katta.Dao.UpcomingLectureDAO;
import sgb.board.com.edu_katta.Interface.OnLoadMoreListener;
import sgb.board.com.edu_katta.R;
import sgb.board.com.edu_katta.Server.Server;


public class UpcomimgFragment extends Fragment {

    View view;
    Context context;

    private RecyclerView rv_list;
    private ArrayList<UpcomingLectureDAO> upcomingLectureDAOS;
    private UpcomingAdapter upcomingAdapter;
    UpcomingLectureDAO upcomingLectureDAO;

    private int index1 = 0,end = 10;
    private int count1=0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_upcomimg, container, false);

        context = getActivity();

        rv_list = view.findViewById(R.id.rv_list);
        upcomingLectureDAOS = new ArrayList<>();


        rv_list.setLayoutManager(new GridLayoutManager(context,1));
        rv_list.setItemAnimator(new DefaultItemAnimator());
        rv_list.setNestedScrollingEnabled(false);

        upcomingAdapter = new UpcomingAdapter(rv_list,upcomingLectureDAOS,context);
        upcomingAdapter.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                upcomingLectureDAOS.add(null);
                upcomingAdapter.notifyItemInserted(upcomingLectureDAOS.size() - 1);
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        index1 = upcomingLectureDAOS.size();
                        end = index1 + 10;
                        count1 = count1 + 1;
                        if (CheckConnection.haveNetworkConnection(context))
                        {
                            getData(count1);
                        }
                        else {
                            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });

        if (CheckConnection.haveNetworkConnection(context))
        {
            index1 = 0;
            count1=1;
            upcomingLectureDAOS.clear();
            upcomingAdapter.notifyDataSetChanged();

            getData(count1);
        }
        else {
            Toast.makeText(context, "Network is not available", Toast.LENGTH_LONG).show();
        }

        return view;
    }

    public void getData(int count) {
        try {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Loading.....");
            progressDialog.setCancelable(true);
            JSONObject jsonParams = new JSONObject();
            jsonParams.put("MOBILE", DashboardActivity.MobNo);
            jsonParams.put("limit",10);
            jsonParams.put("page_no",count);
            jsonParams.put("type","thisweek");
            StringEntity entity = new StringEntity(jsonParams.toString());
            Log.e("para",entity.toString());
            Log.e("para....",jsonParams.toString());
            Server.post(context,"",entity,"Data/upcominglectures", new JsonHttpResponseHandler() {
                @Override
                public void onStart() {
                    super.onStart();
                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                    super.onSuccess(statusCode, headers, response);
                    Log.d("success", response.toString());
                    Log.e("lenth..",".."+response.length());

                    try
                    {
                        if (index1 != 0) {
                            upcomingLectureDAOS.remove(upcomingLectureDAOS.size() - 1);
                            upcomingAdapter.notifyItemRemoved(upcomingLectureDAOS.size());
                        }

                        if(response.length()>0)
                        {
                            progressDialog.dismiss();

                            for (int i = 0; i < response.length(); i++)
                            {
                                JSONObject jsonObject = response.getJSONObject(i);

                                upcomingLectureDAO = new UpcomingLectureDAO();

                                if (jsonObject.getString("firstname")==null || jsonObject.getString("firstname").equalsIgnoreCase("null")||jsonObject.getString("firstname").equalsIgnoreCase(""))
                                {
                                    upcomingLectureDAO.setFirstname("");
                                }
                                else
                                {
                                    upcomingLectureDAO.setFirstname(jsonObject.getString("firstname"));
                                }
                                if (jsonObject.getString("lastname")==null || jsonObject.getString("lastname").equalsIgnoreCase("null")||jsonObject.getString("lastname").equalsIgnoreCase(""))
                                {
                                    upcomingLectureDAO.setLastname("");
                                }
                                else
                                {
                                    upcomingLectureDAO.setLastname(jsonObject.getString("lastname"));
                                }
                                if (jsonObject.getString("subject")==null || jsonObject.getString("subject").equalsIgnoreCase("null")||jsonObject.getString("subject").equalsIgnoreCase(""))
                                {
                                    upcomingLectureDAO.setSubject("");
                                }
                                else
                                {
                                    upcomingLectureDAO.setSubject(jsonObject.getString("subject"));
                                }
                                if (jsonObject.getString("education")==null || jsonObject.getString("education").equalsIgnoreCase("null")||jsonObject.getString("education").equalsIgnoreCase(""))
                                {
                                    upcomingLectureDAO.setEducation("");
                                }
                                else
                                {
                                    upcomingLectureDAO.setEducation(jsonObject.getString("education"));
                                }
                                if (jsonObject.getString("duration")==null || jsonObject.getString("duration").equalsIgnoreCase("null")||jsonObject.getString("duration").equalsIgnoreCase(""))
                                {
                                    upcomingLectureDAO.setDuration("");
                                }
                                else
                                {
                                    upcomingLectureDAO.setDuration(jsonObject.getString("duration"));
                                }
                                if (jsonObject.getString("live")==null || jsonObject.getString("live").equalsIgnoreCase("null")||jsonObject.getString("live").equalsIgnoreCase(""))
                                {
                                    upcomingLectureDAO.setDate("");
                                    upcomingLectureDAO.setTime("");
                                }
                                else
                                {
                                    DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy");
                                    DateFormat timeFormat = new SimpleDateFormat("hh:mm a");
                                    DateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                                    Date date = outputFormat.parse(jsonObject.getString("live"));
                                    String a_date = inputFormat.format(date);
                                    String a_time = timeFormat.format(date);
                                    upcomingLectureDAO.setDate(a_date);
                                    upcomingLectureDAO.setTime(a_time);

                                }
                                if (jsonObject.getString("topic")==null || jsonObject.getString("topic").equalsIgnoreCase("null")||jsonObject.getString("topic").equalsIgnoreCase(""))
                                {
                                    upcomingLectureDAO.setTopic("");
                                }
                                else
                                {
                                    upcomingLectureDAO.setTopic(jsonObject.getString("topic"));
                                }
                                if (jsonObject.getString("image")==null || jsonObject.getString("image").equalsIgnoreCase("null")||jsonObject.getString("image").equalsIgnoreCase(""))
                                {
                                    upcomingLectureDAO.setImage("");
                                }
                                else
                                {
                                    upcomingLectureDAO.setImage(jsonObject.getString("image"));
                                }

                                upcomingLectureDAOS.add(upcomingLectureDAO);
                            }

                            if (index1 == 0 && end == 10)
                            {
                                rv_list.setAdapter(upcomingAdapter);
                            }else{
                                Log.e("index and end",index1+","+end);
                            }
                            upcomingAdapter.notifyDataSetChanged();
                            upcomingAdapter.setLoaded();

                        }
                        else {
                            upcomingAdapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                           // Toast.makeText(context, "Data Not Available", Toast.LENGTH_LONG).show();
                        }

                        upcomingAdapter.notifyDataSetChanged();
                    }
                    catch (ParseException p)
                    {
                        p.printStackTrace();
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    super.onFailure(statusCode, headers, responseString, throwable);
                    progressDialog.dismiss();
                    Log.e("error..is",".."+responseString.toString());
                    Toast.makeText(context, "Error occured",Toast.LENGTH_LONG).show();
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }

}
