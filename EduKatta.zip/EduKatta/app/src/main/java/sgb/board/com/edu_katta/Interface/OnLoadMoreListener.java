package sgb.board.com.edu_katta.Interface;

public interface OnLoadMoreListener {

    void onLoadMore();
}
