package sgb.board.com.edu_katta.Interface;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import sgb.board.com.edu_katta.Dao.LoginData;

public interface apiset {

    @FormUrlEncoded
    @POST("Data/studentlogin")
    Call<List<LoginData>> getLoginData(
            @Field("username") String username,
            @Field("password") String password
    );

    @FormUrlEncoded
    @POST("json_backend.php")
    Call<LoginData> setLoginData(

//            @Field("farmname") String fname,
//            @Field("deviceid") String deviceid,
//            @Field("action") String action,
//            @Field("empid") String empid,
//            @Field("hfarmname") String hfarmname,
//            @Field("farmaddress") String farmaddress,
//            @Field("sysloginid") String sysloginid,
//            @Field("lighttime") String lighttime
    );

}
