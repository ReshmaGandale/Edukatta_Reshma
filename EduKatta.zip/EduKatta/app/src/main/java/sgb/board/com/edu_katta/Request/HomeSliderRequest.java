package sgb.board.com.edu_katta.Request;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class HomeSliderRequest {

    @Expose
    @SerializedName("MOBILE")
    private String mobile;

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
