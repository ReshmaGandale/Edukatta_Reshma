package sgb.board.com.edu_katta.RxJavaRemote;

import retrofit2.http.Body;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import sgb.board.com.edu_katta.Models.HomePageContentModels;
import sgb.board.com.edu_katta.Models.HomeSliderModels;
import sgb.board.com.edu_katta.Request.HomeSliderRequest;

public interface APIService {

    @POST("/Prod/api/Data/dashboardsliderlist")
    Observable<HomeSliderModels> Slider(@Body HomeSliderRequest sliderRequest);

    @POST("/Prod/api/Data/dashboardcontentlist")
    Observable<HomePageContentModels> HomePageContent(@Body HomeSliderRequest sliderRequest);



}
