package sgb.board.com.edu_katta.RxJavaRemote;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

public class ApiUtils {
    public ApiUtils() {
    }
    public static final String BASE_URL_Main_Test = "https://7gdt5szac1.execute-api.ap-south-1.amazonaws.com";
    public static APIService getAPIService() {
        OkHttpClient.Builder okHttpClient = new OkHttpClient.Builder();
        okHttpClient.connectTimeout(1, TimeUnit.DAYS);
        okHttpClient.readTimeout(90, TimeUnit.SECONDS);
        okHttpClient.writeTimeout(90, TimeUnit.SECONDS);
        return RetrofitClient.getClient(BASE_URL_Main_Test).create(APIService.class);
    }
}
