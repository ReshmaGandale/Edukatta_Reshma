package sgb.board.com.edu_katta.Server;

import android.content.Context;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.entity.StringEntity;

public class Server {

    public static final String BASE_URL ="https://7gdt5szac1.execute-api.ap-south-1.amazonaws.com/Prod/api/";

    private static final String TAG = "server";
    private static AsyncHttpClient client = new AsyncHttpClient();


    public static void get(String jwttoken, RequestParams params, String action, AsyncHttpResponseHandler responseHandler) {
        if(!jwttoken.equalsIgnoreCase("")|| !jwttoken.equalsIgnoreCase("null")||jwttoken!=null)
        {
            setHeader(jwttoken);
        }
        client.setTimeout(25000);
        client.get(getAbsoluteUrl(action), params, responseHandler);
        Log.d(TAG, getAbsoluteUrl(action));
    }

    public static void post(Context context,String jwttoken,StringEntity params, String action, AsyncHttpResponseHandler responseHandler) {
        if(!jwttoken.equalsIgnoreCase("")|| !jwttoken.equalsIgnoreCase("null")||jwttoken!=null)
        {
            setHeader(jwttoken);
        }
        client.setTimeout(25000);
        client.post(context,getAbsoluteUrl(action), params,"application/json", responseHandler);
        Log.d(TAG, getAbsoluteUrl(action));
    }


    public static void put(Context context, HttpEntity params, String action, AsyncHttpResponseHandler responseHandler) {
//        if(!jwttoken.equalsIgnoreCase("")|| !jwttoken.equalsIgnoreCase("null")||jwttoken!=null)
//        {
//            setHeader(jwttoken);
//        }
        client.setTimeout(AsyncHttpClient.DEFAULT_MAX_CONNECTIONS);
        client.put(context,action, params,"application/json", responseHandler);
        Log.d(TAG, action);
    }

    public static String getAbsoluteUrl(String action) {
        return BASE_URL+action ;

    }

    public static void getPublic(String url, RequestParams params,String action, AsyncHttpResponseHandler responseHandler) {
        client.setTimeout(6000);
        client.get(url, params, responseHandler);

        Log.d(TAG, getAbsoluteUrl(action));
    }

    public static void setHeader(String header) {
        client.addHeader("Authorization", "Bearer "+header);
    }
//    public static void setHeader(String header) {
//        client.addHeader("X-API-KEY", header);
//    }

    public static void setContetntType() {
        client.addHeader("Content-Type", "application/x-www-form-urlencoded");
    }

}
