package sgb.board.com.edu_katta.Service;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import sgb.board.com.edu_katta.Interface.apiset;

public class apicontroller {

    private static final String url="https://7gdt5szac1.execute-api.ap-south-1.amazonaws.com/Prod/api/";
    private static apicontroller rescont;
    private static Retrofit retrofit;

    apicontroller()
    {
        retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    public static synchronized apicontroller getInstance()
    {
        if(rescont==null)
            rescont = new apicontroller();

        return rescont;
    }

    public apiset getapi()
    {
        return retrofit.create(apiset.class);
    }
}
