package sgb.board.com.edu_katta.Session;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import sgb.board.com.edu_katta.Activity.LoginActivity;
import sgb.board.com.edu_katta.Activity.StartActivity;


public class SessionManager {

    // Shared Preferences
    SharedPreferences pref;
    // Editor for Shared prefrences
    SharedPreferences.Editor editor;
    // Context
    Context _context;
    // Shared pref mode
    int PRIVATE_MODE = 0;
    // Sharedpref file name
    private static final String PREF_NAME = "liveon";
    // All Shared Preferences Keys
    private static final String IS_LOGIN = "IsLoggedIn";
    // User name (make variable public to access from outside)


    public static final String IS_ONLINE = "false";
    public static final String DEVICEID = "deviceid";
    public static final String ANDROID_ID = "android_id";


    public static final String JWT_TOKEN = "jwt_token";
    public static final String STUDENT_ID = "student_id";
    public static final String STU_NAME = "stu_name";
    public static final String STU_MID_NAME = "stu_mid_name";
    public static final String STU_SURNAME = "stu_surname";
    public static final String STU_MOBILENO = "stu_mobileno";
    public static final String STU_STATUS = "stu_status";
    public static final String STU_DEVICESTATUS = "stu_devicestatus";
    public static final String STU_STUPHOTO = "stu_stuphoto";
    public static final String STU_STUADDRESS = "stu_stuaddress";


    public void setStuStuaddress(String stuaddress){
        editor.putString(STU_STUADDRESS,stuaddress);
        editor.commit();
    }


    public void setStuStuphoto(String stuStuphoto){
        editor.putString(STU_STUPHOTO,stuStuphoto);
        editor.commit();
    }


    public void setAndroidId(String androidId){
        editor.putString(ANDROID_ID,androidId);
        editor.commit();
    }

    public void setStuDevicestatus(String stuDevicestatus){
        editor.putString(STU_DEVICESTATUS,stuDevicestatus);
        editor.commit();
    }

    public void setStudentId(String studentId){
        editor.putString(STUDENT_ID,studentId);
        editor.commit();
    }

    public void setJwtToken(String jwtToken){
        editor.putString(JWT_TOKEN,jwtToken);
        editor.commit();
    }

    public void setStuName(String stuName){
        editor.putString(STU_NAME,stuName);
        editor.commit();
    }

    public void setStuMidName(String stuMidName){
        editor.putString(STU_MID_NAME,stuMidName);
        editor.commit();
    }
    public void setStuSurname(String stuSurname){
        editor.putString(STU_SURNAME,stuSurname);
        editor.commit();
    }

    public void setStuMobileno(String stuMobileno){
        editor.putString(STU_MOBILENO,stuMobileno);
        editor.commit();
    }

    public void setStuStatus(String stuStatus){
        editor.putString(STU_STATUS,stuStatus);
        editor.commit();
    }

    public void setDeviceid(String deviceid) {
        editor.putString(DEVICEID, deviceid);
        editor.commit();
    }


    public String getStuStuaddress(){
        if (pref!=null){
            String stadd =pref.getString(STU_STUADDRESS,null);
            if (stadd!=null)
            {
                return stadd;
            }else{
                return null;
            }
        }
        return "";
    }

    public String getStuStuphoto(){
        if (pref!=null){
            String stp =pref.getString(STU_STUPHOTO,null);
            if (stp!=null)
            {
                return stp;
            }else{
                return null;
            }
        }
        return "";
    }


    public String getAndroidId(){
        if (pref!=null){
            String anid =pref.getString(ANDROID_ID,null);
            if (anid!=null)
            {
                return anid;
            }else{
                return null;
            }
        }
        return "";
    }

    public String getStuDevicestatus(){
        if (pref!=null){
            String studev =pref.getString(STU_DEVICESTATUS,null);
            if (studev!=null)
            {
                return studev;
            }else{
                return null;
            }
        }
        return "";
    }

    public String getStudentId(){
        if (pref!=null){
            String stuid =pref.getString(STUDENT_ID,null);
            if (stuid!=null)
            {
                return stuid;
            }else{
                return null;
            }
        }
        return "";
    }

    public String getJwtToken(){
        if (pref!=null){
            String jks =pref.getString(JWT_TOKEN,null);
            if (jks!=null)
            {
                return jks;
            }else{
                return null;
            }
        }
        return "";
    }

    public String getStuName(){
        if (pref!=null){
            String stunm =pref.getString(STU_NAME,null);
            if (stunm!=null)
            {
                return stunm;
            }else{
                return null;
            }
        }
        return "";
    }

    public String getStuMidName(){
        if (pref!=null){
            String stumid =pref.getString(STU_MID_NAME,null);
            if (stumid!=null)
            {
                return stumid;
            }else{
                return null;
            }
        }
        return "";
    }

    public String getStuSurname(){
        if (pref!=null){
            String stusur =pref.getString(STU_SURNAME,null);
            if (stusur!=null)
            {
                return stusur;
            }else{
                return null;
            }
        }
        return "";
    }

    public String getStuMobileno(){
        if (pref!=null){
            String stumnom =pref.getString(STU_MOBILENO,null);
            if (stumnom!=null)
            {
                return stumnom;
            }else{
                return null;
            }
        }
        return "";
    }

    public String getStuStatus(){
        if (pref!=null){
            String stust =pref.getString(STU_STATUS,null);
            if (stust!=null)
            {
                return stust;
            }else{
                return null;
            }
        }
        return "";
    }


    public String getDeviceid(){
        if (pref!=null){
            String devid=pref.getString(DEVICEID,null);
            if (devid!=null)
            {
                return devid;
            }else{
                return null;
            }
        }
        return "";
    }


    public void createLoginSession(String jwtToken,String student_id,String student_name,
                                   String student_midname,String student_surname,String student_mobno,String student_status,String student_photo,String student_address) {
        // Storing login value as TRUE
        editor.putBoolean(IS_LOGIN, true);

        // Storing name in pref
        editor.putString(JWT_TOKEN, jwtToken);
        editor.putString(STUDENT_ID, student_id);
        editor.putString(STU_NAME, student_name);
        editor.putString(STU_MID_NAME, student_midname);
        editor.putString(STU_SURNAME, student_surname);
        editor.putString(STU_MOBILENO, student_mobno);
        editor.putString(STU_STATUS, student_status);
        editor.putString(STU_STUPHOTO, student_photo);
        editor.putString(STU_STUADDRESS, student_address);
        // Storing email in pref
        // commit changes
        editor.commit();
    }


    public void Logout()
    {
        editor.putBoolean(IS_LOGIN, false);

        editor.putString(JWT_TOKEN, null);
        editor.putString(STUDENT_ID, null);
        editor.putString(STU_NAME, null);
        editor.putString(STU_MID_NAME, null);
        editor.putString(STU_SURNAME, null);
        editor.putString(STU_MOBILENO, null);
        editor.putString(STU_STATUS, null);
        editor.putString(STU_DEVICESTATUS, null);
        editor.putString(STU_STUPHOTO, null);
        editor.putString(STU_STUADDRESS, null);

        editor.commit();
        // After logout redirect user to Loing Activity
        Intent i = new Intent(_context, StartActivity.class);
        // Closing all the Activities
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        // Add new Flag to start new Activity
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        // Staring Login Activity
        _context.startActivity(i);
    }

    // Constructor
    public SessionManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    /**
     * Check login method wil setting user login status
     * If false it will redirect user to login page
     * Else won't do anything
     */
    public void checkLogin() {
        // Check login status
        if (!this.isLoggedIn()) {
            // user is not logged in redirect him to Login Activity
            Intent i = new Intent(_context, LoginActivity.class);
            // Closing all the Activities
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            // Add new Flag to start new Activity
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Staring Login Activity
            _context.startActivity(i);
        }

    }

    // Get Login State
    public boolean isLoggedIn() {
        return pref.getBoolean(IS_LOGIN, false);
    }
}
