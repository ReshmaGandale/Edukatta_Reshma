package sgb.board.com.edu_katta.Utils;

import android.view.View;

public interface RecycleViewClickListner {
    void onClick(View view,int position);
}
