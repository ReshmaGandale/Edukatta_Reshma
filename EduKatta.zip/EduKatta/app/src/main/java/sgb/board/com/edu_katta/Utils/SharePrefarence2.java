package sgb.board.com.edu_katta.Utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharePrefarence2 {

    private static SharePrefarence2 mInstance;
    private static Context mctx;
    private static final String SHARE_PRE_NAME = "EduKatta";
    public SharePrefarence2(Context context) {
        mctx = context;
    }
    public static SharePrefarence2 getmInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SharePrefarence2(context);
        }
        return mInstance;
    }

    private static final String ID = "id";
    private static final String MOBILE = "mobile";

    public boolean Saveid(String id) {
        SharedPreferences sharedPreferences = mctx.getSharedPreferences(SHARE_PRE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(ID, id);
        editor.apply();
        return true;
    }

    public String getId() {
        SharedPreferences sharedPreferences = mctx.getSharedPreferences(SHARE_PRE_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(ID, "");
    }
    public boolean SaveMobile(String mobile) {
        SharedPreferences sharedPreferences = mctx.getSharedPreferences(SHARE_PRE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(MOBILE, mobile);
        editor.apply();
        return true;
    }

    public String getMobile() {
        SharedPreferences sharedPreferences = mctx.getSharedPreferences(SHARE_PRE_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(MOBILE, "");
    }


}


