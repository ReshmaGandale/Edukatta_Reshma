package sgb.board.com.edu_katta.Utils;

import android.content.Context;
import android.view.Gravity;
import android.widget.Toast;

public class Utils {
    public static Toast customMessage(Context ctx, String message) {
        Toast toast = Toast.makeText(ctx, message, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
        return toast;

    }
}
